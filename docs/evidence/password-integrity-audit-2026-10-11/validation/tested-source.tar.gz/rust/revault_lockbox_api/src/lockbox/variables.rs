use std::collections::BTreeMap;
use std::collections::BTreeSet;
use std::sync::Arc;

use super::Lockbox;
use crate::free_slot::FreeSlot;
use crate::file_format::page_commitment::PageCommitment;
use crate::page::{PageObject, PageObjectKind};
use crate::page_cache::SecurePageAppend;
use crate::secret_vec::SecureVec;
use crate::security::{validate_variable_value, validate_variable_value_ref};
use crate::variable_btree::{
    decode_variable_node_secure, encode_variable_internal, encode_variable_leaf_secure,
    variable_child_groups, variable_entries_from_map, variable_leaf_groups, VariableChild,
    VariableInternal, VariableLeaf, VariableNode, VariableTreeNode, VariableValue,
};
use crate::{
    crypto::derive_page_content_key, Error, Result, SecretString, VariableName, VariableSensitivity,
};
use zeroize::Zeroize;

const LOCKBOX_DESCRIPTION_VARIABLE: &str = "/.revault/description";

/// Borrowed variable value yielded by `Lockbox::visit_variables`.
#[derive(Debug)]
pub enum VariableValueRef<'a> {
    /// Plain variable value.
    Normal(&'a str),
    /// Secret variable value; use `SecretString::with_str` for scoped plaintext access.
    Secret(&'a SecretString),
}

#[cfg(test)]
mod commitment_lifecycle_tests {
    use super::*;
    use crate::storage::StorageBackend;

    #[test]
    fn authenticated_variable_tree_persists_multiple_pages_and_secret_lifecycle() {
        let key = b"synthetic-variable-lifecycle-key";
        let mut archive = Lockbox::create_in_memory_with_options(crate::LockboxCreateOptions::new(
            crate::Encryption::Encrypted(crate::LockboxProtection::ContentKey(
                crate::SecretVec::try_from_slice(key).unwrap(),
            )),
            crate::Signing::None,
        )).unwrap();
        let initial = "initial-".repeat(128);
        for index in 0..256 {
            archive.set_variable(&VariableName::new(format!("VAR_{index:04}")).unwrap(), &initial).unwrap();
        }
        let secret_name = VariableName::new("SECRET").unwrap();
        archive.set_secret_variable(&secret_name, &SecretString::try_from_slice(b"first-secret").unwrap()).unwrap();
        archive.commit().unwrap();
        assert!(matches!(archive.variable_root, Some(VariableTreeNode::Internal(_))));
        let options = crate::LockboxOptions { cache_limit: crate::CacheLimit::Bytes(0), ..Default::default() };
        let mut reopened = Lockbox::open_storage(StorageBackend::memory(archive.to_bytes()), key, options.clone()).unwrap();
        for index in 0..256 {
            assert_eq!(reopened.get_variable(&VariableName::new(format!("VAR_{index:04}")).unwrap()).unwrap().as_deref(), Some(initial.as_str()));
        }
        reopened.set_variable(&VariableName::new("VAR_0000").unwrap(), "replacement").unwrap();
        for index in 1..256 {
            reopened.delete_variable(&VariableName::new(format!("VAR_{index:04}")).unwrap()).unwrap();
        }
        reopened.set_secret_variable(&secret_name, &SecretString::try_from_slice(b"second-secret").unwrap()).unwrap();
        reopened.commit().unwrap();
        let reopened = Lockbox::open_storage(StorageBackend::memory(reopened.to_bytes()), key, options).unwrap();
        assert_eq!(reopened.get_variable(&VariableName::new("VAR_0000").unwrap()).unwrap().as_deref(), Some("replacement"));
        for index in 1..256 {
            assert!(reopened.get_variable(&VariableName::new(format!("VAR_{index:04}")).unwrap()).unwrap().is_none());
        }
        let mut secret = None;
        reopened.visit_variables(|name, value| {
            if name == &secret_name {
                if let VariableValueRef::Secret(value) = value {
                    secret = Some(value.with_str(|value| value == "second-secret")?);
                }
            }
            Ok(())
        }).unwrap();
        assert_eq!(secret, Some(true));
    }
}

fn ensure_variable_name_available(
    variables: &BTreeMap<VariableName, VariableValue>,
    requested: &VariableName,
) -> Result<()> {
    if let Some(existing) = variables.keys().find(|existing| {
        *existing != requested && names_share_variable_and_directory(existing, requested)
    }) {
        return Err(Error::AlreadyExists(format!(
            "variable namespace conflict between {requested} and {existing}"
        )));
    }
    Ok(())
}

fn ensure_variable_namespace_is_unambiguous(names: &BTreeSet<VariableName>) -> Result<()> {
    let mut previous: Option<&VariableName> = None;
    for name in names {
        if let Some(previous) = previous {
            if is_variable_directory_of(previous, name) {
                return Err(Error::AlreadyExists(format!(
                    "variable namespace conflict between {previous} and {name}"
                )));
            }
        }
        previous = Some(name);
    }
    Ok(())
}

fn names_share_variable_and_directory(left: &VariableName, right: &VariableName) -> bool {
    is_variable_directory_of(left, right) || is_variable_directory_of(right, left)
}

fn is_variable_directory_of(parent: &VariableName, child: &VariableName) -> bool {
    child
        .as_str()
        .strip_prefix(parent.as_str())
        .is_some_and(|suffix| suffix.starts_with('/'))
}

impl<State> Lockbox<State> {
    /// Return the encrypted human-readable description of this lockbox.
    ///
    /// The description is stored as ordinary encrypted lockbox metadata at
    /// `/.revault/description`. It is unavailable until the lockbox has been
    /// opened. `Ok(None)` means no description has been assigned.
    ///
    /// # Example
    ///
    /// ```
    /// # use revault_lockbox_api::{Lockbox, LockboxProtection, OwnerSigningKeyPair, SecretString};
    /// # let password = SecretString::try_from_slice(b"correct horse")?;
    /// # let signing_key = OwnerSigningKeyPair::generate()?;
    /// # let lockbox = Lockbox::create_in_memory(LockboxProtection::Password(&password), &signing_key)?;
    /// if let Some(description) = lockbox.description()? {
    ///     println!("Lockbox purpose: {description}");
    /// }
    /// # Ok::<(), revault_lockbox_api::Error>(())
    /// ```
    pub fn description(&self) -> Result<Option<String>> {
        self.get_variable(&VariableName::new(LOCKBOX_DESCRIPTION_VARIABLE)?)
    }

    /// Store or replace this lockbox's encrypted human-readable description.
    ///
    /// `description` is UTF-8 text with the same validation and one-mebibyte
    /// size limit as a normal variable value. Call [`Lockbox::commit`] to
    /// authenticate and publish the change. Use [`Lockbox::clear_description`]
    /// to remove it.
    ///
    /// # Example
    ///
    /// ```
    /// # use revault_lockbox_api::{Lockbox, LockboxProtection, OwnerSigningKeyPair, SecretString};
    /// # let password = SecretString::try_from_slice(b"correct horse")?;
    /// # let signing_key = OwnerSigningKeyPair::generate()?;
    /// let mut lockbox = Lockbox::create_in_memory(
    ///     LockboxProtection::Password(&password),
    ///     &signing_key,
    /// )?;
    /// lockbox.set_description("Deployment credentials for Project Atlas")?;
    /// lockbox.commit()?;
    /// # Ok::<(), revault_lockbox_api::Error>(())
    /// ```
    pub fn set_description(&mut self, description: &str) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        self.set_variable(
            &VariableName::new(LOCKBOX_DESCRIPTION_VARIABLE)?,
            description,
        )
    }

    /// Remove this lockbox's encrypted description, if one is present.
    ///
    /// Call [`Lockbox::commit`] to authenticate and publish the change.
    /// Repeated calls are safe.
    ///
    /// # Example
    ///
    /// ```
    /// # use revault_lockbox_api::{Lockbox, LockboxProtection, OwnerSigningKeyPair, SecretString};
    /// # let password = SecretString::try_from_slice(b"correct horse")?;
    /// # let signing_key = OwnerSigningKeyPair::generate()?;
    /// # let mut lockbox = Lockbox::create_in_memory(LockboxProtection::Password(&password), &signing_key)?;
    /// lockbox.clear_description()?;
    /// lockbox.commit()?;
    /// # Ok::<(), revault_lockbox_api::Error>(())
    /// ```
    pub fn clear_description(&mut self) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        self.delete_variable(&VariableName::new(LOCKBOX_DESCRIPTION_VARIABLE)?)
    }

    /// Store or replace a non-secret variable.
    ///
    /// Returns `Error::InvalidInput` if the value contains unsupported
    /// characters, `Error::SecurityLimitExceeded` if the value exceeds the
    /// configured variable value size limit, `Error::InvalidOperation` when
    /// attempting to overwrite an existing secret variable as non-secret,
    /// `Error::AlreadyExists` if the name conflicts with an existing variable
    /// directory, and `Error::CorruptRecord` if stored variable metadata cannot
    /// be loaded.
    pub fn set_variable(&mut self, name: &VariableName, value: &str) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        let value = validate_variable_value(value)?;
        self.ensure_variables_loaded()?;
        let mut variables = self.staged.variables.borrow_mut();
        let variables = variables.as_mut().ok_or(Error::CorruptRecord)?;
        if matches!(variables.get(name), Some(VariableValue::Secret(_))) {
            return Err(Error::InvalidOperation(
                "variable is secret; delete and recreate to change sensitivity".to_string(),
            ));
        }
        ensure_variable_name_available(variables, name)?;
        variables.insert(name.clone(), VariableValue::Normal(value));
        self.staged.dirty_variables = true;
        Ok(())
    }

    /// Store or replace a secret variable.
    ///
    /// Secret values remain in secure storage. An existing normal variable is
    /// upgraded to secret sensitivity atomically. Secret variables cannot be
    /// downgraded through [`Lockbox::set_variable`]; delete and recreate them
    /// to make that sensitivity reduction explicit.
    ///
    /// Returns `Error::InvalidInput` if the secret plaintext contains
    /// unsupported characters, `Error::SecurityLimitExceeded` if the secret
    /// plaintext exceeds the configured variable value size limit,
    /// `Error::AlreadyExists` if the name conflicts with an existing variable
    /// directory, or `Error::CorruptRecord` if stored variable metadata cannot
    /// be loaded.
    pub fn set_secret_variable(&mut self, name: &VariableName, value: &SecretString) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        value.with_str(validate_variable_value_ref)??;
        self.ensure_variables_loaded()?;
        let mut variables = self.staged.variables.borrow_mut();
        let variables = variables.as_mut().ok_or(Error::CorruptRecord)?;
        ensure_variable_name_available(variables, name)?;
        variables.insert(
            name.clone(),
            VariableValue::Secret(Arc::new(value.try_clone()?)),
        );
        self.staged.dirty_variables = true;
        Ok(())
    }

    /// Return a non-secret variable by name.
    ///
    /// Returns `Ok(None)` when the variable is absent. Returns
    /// `Error::InvalidOperation` if the variable exists but is secret, and
    /// `Error::CorruptRecord` if stored variable metadata cannot be loaded.
    pub fn get_variable(&self, name: &VariableName) -> Result<Option<String>> {
        self.ensure_variables_loaded()?;
        match self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
            .get(name)
        {
            Some(VariableValue::Normal(value)) => Ok(Some(value.clone())),
            Some(VariableValue::Secret(_)) => Err(Error::InvalidOperation(
                "variable is secret; use secret access".to_string(),
            )),
            None => Ok(None),
        }
    }

    /// Access a secret variable within a callback.
    ///
    /// The callback receives the `SecretString` handle. Use
    /// `SecretString::with_str` inside the callback when plaintext access is
    /// required.
    ///
    /// Returns `Ok(None)` when the variable is absent. Returns
    /// `Error::InvalidOperation` if the variable exists but is non-secret,
    /// and `Error::CorruptRecord` if stored variable metadata cannot be
    /// loaded.
    pub fn with_secret_variable<R>(
        &self,
        name: &VariableName,
        f: impl FnOnce(&SecretString) -> R,
    ) -> Result<Option<R>> {
        self.ensure_variables_loaded()?;
        let variables = self.variables.borrow();
        match variables.as_ref().ok_or(Error::CorruptRecord)?.get(name) {
            Some(VariableValue::Secret(value)) => Ok(Some(f(value))),
            Some(VariableValue::Normal(_)) => Err(Error::InvalidOperation(
                "variable is not secret".to_string(),
            )),
            None => Ok(None),
        }
    }

    /// Return the sensitivity of a variable, if it exists.
    ///
    /// Returns `Error::CorruptRecord` if stored variable metadata cannot be
    /// loaded.
    pub fn variable_sensitivity(&self, name: &VariableName) -> Result<Option<VariableSensitivity>> {
        self.ensure_variables_loaded()?;
        Ok(self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
            .get(name)
            .map(VariableValue::sensitivity))
    }

    /// Delete a variable if it exists.
    ///
    /// Returns `Error::CorruptRecord` if stored variable metadata cannot be
    /// loaded.
    pub fn delete_variable(&mut self, name: &VariableName) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        self.ensure_variables_loaded()?;
        let removed = self
            .variables
            .borrow_mut()
            .as_mut()
            .ok_or(Error::CorruptRecord)?
            .remove(name)
            .is_some();
        if removed {
            self.staged.dirty_variables = true;
        }
        Ok(())
    }

    /// Move one or more variables without exposing or copying their plaintext.
    ///
    /// The operation is validated in full before any variable is changed.
    /// Sources must exist, destinations must be unique, and a destination may
    /// not replace a variable that is not itself being moved.
    pub fn move_variables(&mut self, moves: &[(VariableName, VariableName)]) -> Result<()>
    where
        State: crate::WritableLockboxState,
    {
        self.ensure_variables_loaded()?;
        let mut variables = self.staged.variables.borrow_mut();
        let variables = variables.as_mut().ok_or(Error::CorruptRecord)?;
        let sources = moves
            .iter()
            .map(|(source, _)| source.clone())
            .collect::<BTreeSet<_>>();
        if sources.len() != moves.len() {
            return Err(Error::InvalidInput(
                "a variable cannot be moved more than once".to_string(),
            ));
        }
        let mut destinations = BTreeSet::new();
        for (source, destination) in moves {
            if !variables.contains_key(source) {
                return Err(Error::NotFound(format!("variable {source}")));
            }
            if !destinations.insert(destination.clone()) {
                return Err(Error::AlreadyExists(destination.to_string()));
            }
            if source != destination
                && variables.contains_key(destination)
                && !sources.contains(destination)
            {
                return Err(Error::AlreadyExists(destination.to_string()));
            }
        }
        let final_names = variables
            .keys()
            .filter(|name| !sources.contains(*name))
            .cloned()
            .chain(destinations.iter().cloned())
            .collect::<BTreeSet<_>>();
        ensure_variable_namespace_is_unambiguous(&final_names)?;
        let moved = moves
            .iter()
            .filter(|(source, destination)| source != destination)
            .map(|(source, destination)| {
                let value = variables.remove(source).ok_or(Error::CorruptRecord)?;
                Ok((destination.clone(), value))
            })
            .collect::<Result<Vec<_>>>()?;
        if !moved.is_empty() {
            variables.extend(moved);
            self.staged.dirty_variables = true;
        }
        Ok(())
    }

    /// List variable names with their sensitivity.
    ///
    /// Returns `Error::CorruptRecord` if stored variable metadata cannot be
    /// loaded.
    pub fn list_variables(&self) -> Result<Vec<(VariableName, VariableSensitivity)>> {
        self.ensure_variables_loaded()?;
        Ok(self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
            .iter()
            .map(|(name, value)| (name.clone(), value.sensitivity()))
            .collect())
    }

    /// Visit every variable.
    ///
    /// Normal values are provided as borrowed strings. Secret values are
    /// provided as `SecretString` references so callers must explicitly use the
    /// secret type's scoped accessors.
    ///
    /// Returns `Error::CorruptRecord` if stored variable metadata cannot be
    /// loaded, or any error returned by the visitor callback.
    pub fn visit_variables(
        &self,
        mut f: impl FnMut(&VariableName, VariableValueRef<'_>) -> Result<()>,
    ) -> Result<()> {
        self.ensure_variables_loaded()?;
        for (name, value) in self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
        {
            match value {
                VariableValue::Normal(value) => {
                    f(name, VariableValueRef::Normal(value))?;
                }
                VariableValue::Secret(value) => {
                    f(name, VariableValueRef::Secret(value))?;
                }
            }
        }
        Ok(())
    }

    pub(crate) fn clone_all_variable_values(
        &self,
    ) -> Result<BTreeMap<VariableName, VariableValue>> {
        self.ensure_variables_loaded()?;
        Ok(self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
            .clone())
    }

    pub(crate) fn set_variable_value(
        &mut self,
        name: VariableName,
        value: VariableValue,
    ) -> Result<()> {
        value.with_plaintext(validate_variable_value_ref)??;
        self.ensure_variables_loaded()?;
        self.variables
            .borrow_mut()
            .as_mut()
            .ok_or(Error::CorruptRecord)?
            .insert(name, value);
        self.dirty_variables = true;
        Ok(())
    }

    pub(crate) fn commit_variable_tree(&mut self) -> Result<u64> {
        if !self.dirty_variables {
            return Ok(self.variable_root_offset);
        }
        self.ensure_variables_loaded()?;
        let variables = self
            .variables
            .borrow()
            .as_ref()
            .ok_or(Error::CorruptRecord)?
            .clone();
        if variables.is_empty() {
            self.variable_root = None;
            self.variable_root_commitment = PageCommitment::default();
            self.variable_leaves.clear();
            self.dirty_variables = false;
            return Ok(0);
        }

        let entries = variable_entries_from_map(&variables);
        let mut leaves = Vec::new();
        for chunk in variable_leaf_groups(&entries)? {
            let (offset, commitment) = self.write_variable_leaf(chunk)?;
            leaves.push(VariableLeaf {
                offset,
                commitment,
                entries: chunk.to_vec(),
            });
        }
        let root_node = self.write_variable_tree_for_leaves(&leaves)?;
        let root = root_node.offset();
        self.variable_root_commitment = root_node.commitment();
        self.variable_root = Some(root_node);
        self.variable_leaves = leaves;
        self.dirty_variables = false;
        Ok(root)
    }

    pub(crate) fn stage_variable_tree_redactions(&mut self) -> Result<()> {
        if !self.dirty_variables || self.variable_root_offset == 0 {
            return Ok(());
        }
        let mut redactions = Vec::new();
        self.collect_variable_tree_redactions(self.variable_root_offset, self.variable_root_commitment, 0, &mut redactions)?;
        for (offset, page_size) in redactions {
            // Retire the complete physical allocation without overwriting it
            // before publication; cleanup will erase the full original page.
            self.record_ref_counts.remove(&offset);
            self.redacted_free_slots.push(FreeSlot {
                offset,
                len: page_size,
            });
        }
        Ok(())
    }

    fn ensure_variables_loaded(&self) -> Result<()> {
        if self.variables.borrow().is_none() {
            let variables = if self.variable_root_offset == 0 {
                BTreeMap::new()
            } else {
                let (variables, _, _) = self.decode_variable_btree(self.variable_root_offset)?;
                variables
            };
            *self.variables.borrow_mut() = Some(variables);
        }
        Ok(())
    }

    fn decode_variable_btree(
        &self,
        root_offset: u64,
    ) -> Result<(
        BTreeMap<VariableName, VariableValue>,
        VariableTreeNode,
        Vec<VariableLeaf>,
    )> {
        let mut variables = BTreeMap::new();
        let root = self.decode_variable_node_into(root_offset, self.variable_root_commitment, &mut variables, 0)?;
        let mut leaves = Vec::new();
        root.collect_leaves(&mut leaves);
        leaves.sort_by(|left, right| {
            let left_name = left
                .entries
                .first()
                .map(|entry| entry.name.as_str())
                .unwrap_or("");
            let right_name = right
                .entries
                .first()
                .map(|entry| entry.name.as_str())
                .unwrap_or("");
            left_name.cmp(right_name)
        });
        Ok((variables, root, leaves))
    }

    fn decode_variable_node_into(
        &self,
        offset: u64,
        commitment: PageCommitment,
        variables: &mut BTreeMap<VariableName, VariableValue>,
        depth: usize,
    ) -> Result<VariableTreeNode> {
        if depth > 8 {
            return Err(Error::CorruptRecord);
        }
        match self.read_variable_node(offset, commitment)? {
            VariableNode::Leaf(entries) => {
                let leaf_entries = entries.clone();
                for entry in entries {
                    variables.insert(VariableName::new(entry.name)?, entry.value);
                }
                Ok(VariableTreeNode::Leaf(VariableLeaf {
                    offset,
                    commitment,
                    entries: leaf_entries,
                }))
            }
            VariableNode::Internal(children) => {
                let mut nodes = Vec::with_capacity(children.len());
                for child in children {
                    nodes.push(self.decode_variable_node_into(
                        child.offset,
                        child.commitment,
                        variables,
                        depth + 1,
                    )?);
                }
                Ok(VariableTreeNode::Internal(VariableInternal {
                    offset,
                    commitment,
                    children: nodes,
                }))
            }
        }
    }

    fn read_variable_node(&self, offset: u64, commitment: PageCommitment) -> Result<VariableNode> {
        let variable_object = self.read_variable_object_secure(offset, commitment)?;
        if !matches!(
            variable_object.kind,
            PageObjectKind::VariableLeaf | PageObjectKind::VariableInternal
        ) {
            return Err(Error::CorruptRecord);
        }
        let payload = variable_object
            .secure_payload()
            .ok_or(Error::CorruptRecord)?;
        decode_variable_node_secure(payload)
    }

    fn read_variable_object_secure(&self, offset: u64, commitment: PageCommitment) -> Result<PageObject> {
        self.with_authenticated_secure_page(offset, commitment, |page| {
            if page.objects.len() != 1 {
                return Err(Error::CorruptRecord);
            }
            Ok(page.objects[0].clone())
        })
    }

    fn collect_variable_tree_redactions(
        &self,
        offset: u64,
        commitment: PageCommitment,
        depth: usize,
        redactions: &mut Vec<(u64, u64)>,
    ) -> Result<()> {
        if depth > 8 {
            return Err(Error::CorruptRecord);
        }
        let variable_object = self.read_variable_object_secure(offset, commitment)?;
        if !matches!(
            variable_object.kind,
            PageObjectKind::VariableLeaf | PageObjectKind::VariableInternal
        ) {
            return Err(Error::CorruptRecord);
        }
        redactions.push((offset, commitment.physical_len));
        if variable_object.kind == PageObjectKind::VariableInternal {
            let payload = variable_object
                .secure_payload()
                .ok_or(Error::CorruptRecord)?;
            let VariableNode::Internal(children) = decode_variable_node_secure(payload)? else {
                return Err(Error::CorruptRecord);
            };
            for child in children {
                self.collect_variable_tree_redactions(child.offset, child.commitment, depth + 1, redactions)?;
            }
        }
        Ok(())
    }

    fn write_variable_tree_for_leaves(
        &mut self,
        leaves: &[VariableLeaf],
    ) -> Result<VariableTreeNode> {
        if leaves.len() == 1 {
            return Ok(VariableTreeNode::Leaf(leaves[0].clone()));
        }
        let mut level = leaves
            .iter()
            .cloned()
            .map(VariableTreeNode::Leaf)
            .collect::<Vec<_>>();

        while level.len() > 1 {
            let mut next_level = Vec::new();
            let mut child_cursor = 0usize;
            let children = level
                .iter()
                .map(|node| VariableChild {
                    first_name: node.first_name().to_string(),
                    offset: node.offset(),
                    commitment: node.commitment(),
                })
                .collect::<Vec<_>>();
            for chunk in variable_child_groups(&children)? {
                let (offset, commitment) = self.write_variable_internal(chunk)?;
                let start = child_cursor;
                let end = start + chunk.len();
                child_cursor = end;
                let child_nodes = level[start..end].to_vec();
                next_level.push(VariableTreeNode::Internal(VariableInternal {
                    offset,
                    commitment,
                    children: child_nodes,
                }));
            }
            level = next_level;
        }

        Ok(level.remove(0))
    }

    fn write_variable_leaf(
        &mut self,
        entries: &[crate::variable_btree::VariableEntry],
    ) -> Result<(u64, PageCommitment)> {
        let payload = encode_variable_leaf_secure(entries)?;
        self.sequence += 1;
        self.append_variable_page_secure(PageObjectKind::VariableLeaf, payload)
    }

    fn write_variable_internal(&mut self, children: &[VariableChild]) -> Result<(u64, PageCommitment)> {
        let payload = SecureVec::try_from_vec(encode_variable_internal(children)?)?;
        self.sequence += 1;
        self.append_variable_page_secure(PageObjectKind::VariableInternal, payload)
    }

    fn append_variable_page_secure(
        &mut self,
        kind: PageObjectKind,
        mut payload: SecureVec,
    ) -> Result<(u64, PageCommitment)> {
        let sequence = self.staged.sequence;
        // Keep reservation and secure encoder extents identical. Do not
        // serialize a secret into ordinary heap memory merely to size it.
        let page_size = crate::page::secure_page_size(payload.len(), self.format_mode)? as u64;
        let page_offset = self.allocate_page_offset(page_size)?;
        let commitment = PageCommitment::from_page(
            self.lockbox_id,
            self.format_mode,
            page_size,
            &crate::page::DecodedPage {
                page_id: page_offset,
                sequence,
                objects: vec![PageObject::new_secure(kind, sequence, payload.try_clone()?)],
            },
        )?;
        self.begin_preparation()?;
        let mut content_key = self.key.with_bytes(derive_page_content_key)?;
        let result = self
            .page_manager
            .borrow_mut()
            .write_secure_single_object_page_at(
                &mut self.storage,
                page_offset,
                SecurePageAppend {
                    lockbox_id: self.lockbox_id,
                    content_key: &content_key,
                    sequence,
                    kind,
                    object_id: sequence,
                    payload: &payload,
                },
            );
        content_key.zeroize();
        payload.zeroize()?;
        result.map(|offset| (offset, commitment))
    }
}
