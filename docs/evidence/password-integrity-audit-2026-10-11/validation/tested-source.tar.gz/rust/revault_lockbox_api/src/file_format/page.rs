use crate::checked::{array_12, read_u16_le, read_u32_le, read_u64_le};
use crate::compression::{decode_page_body_view, encode_page_body, COMPRESSION_NONE};
use crate::crypto::{
    derive_page_content_key, open_with_content_key_secure, open_with_nonce,
    seal_with_content_key_secure, seal_with_random_nonce, strong_checksum,
};
use crate::lockbox_id::LockboxId;
use crate::page_buffer::{zeroize_bytes, PageBuffer, ZeroizingBytes};
use crate::page_inspection::{PageInspection, PageObjectInspection};
#[cfg(test)]
use crate::record::{DecodedRecord, RecordHeader, RecordKind};
#[cfg(test)]
use crate::scan::Scan;
use crate::secret_vec::{secure_read_access, SecureVec};
use crate::{Error, Result};
use std::borrow::Cow;
use zeroize::Zeroize;

pub(crate) const PAGE_MAGIC: &[u8; 8] = b"LBX1PAG\0";
pub(crate) const PAGE_HEADER_LEN: usize = 96;
#[cfg(test)]
pub(crate) mod secure_storage;
pub(crate) use crate::constants::{
    DEFAULT_DATA_PAGE_BYTES, DEFAULT_METADATA_PAGE_BYTES, DEFAULT_PAGE_BYTES,
};

const PAGE_SIZE_GRANULARITY: usize = 1024;
const MIN_PAGE_BYTES: usize = PAGE_SIZE_GRANULARITY;
const PAGE_VERSION: u16 = 2;
const PAGE_BODY_VERSION: u8 = 1;
const COMPRESSION_NORMAL: u8 = 1;
const PAGE_FLAG_CLEAR_TEXT: u16 = 0x0001;
const PAGE_FLAG_UNPADDED: u16 = 0x0002;
const PAGE_UNCOMPRESSED_BODY_OVERHEAD: usize = 16 + 17 + 32;
const PAGE_CHECKSUM_START: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum PageObjectKind {
    CommitRoot = 1,
    TocLeaf = 2,
    TocInternal = 3,
    FileData = 4,
    PackedFileData = 5,
    Symlink = 6,
    VariableSet = 7,
    VariableDelete = 8,
    KeyDirectory = 9,
    FreeIndexLeaf = 10,
    FreeIndexInternal = 11,
    Delete = 12,
    VariableLeaf = 13,
    VariableInternal = 14,
    FormLeaf = 15,
    FormInternal = 16,
    CommitAuth = 17,
    RedactionManifest = 18,
}

pub(crate) fn page_size_for_objects(objects: &[PageObject]) -> usize {
    let max_page_size = max_page_size_for_objects(objects);
    let object_stream_len = encoded_object_stream_len(objects).unwrap_or(max_page_size);
    page_size_for_object_stream_len(object_stream_len, max_page_size).unwrap_or(max_page_size)
}

pub(crate) fn page_size_for_encoded_objects_with_format(
    objects: &[PageObject],
    mode: crate::creation_options::FormatMode,
) -> Result<usize> {
    if mode.0 != 0 {
        // Explicit raw bodies have a fixed header and object framing. Sizing
        // must not copy (and later wipe) whole file frames or read secret
        // payload bytes merely to count them. Compressed metadata still needs
        // its encoder to determine the stored length.
        let body_len = if !objects_allow_body_compression(objects, mode)
            || mode.options().compression == crate::Compression::None
        {
            16usize
                .checked_add(encoded_object_stream_len(objects)?)
                .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".into()))?
        } else {
            let mut body = encode_objects_body(objects, mode)?;
            let len = body.len();
            body.zeroize();
            len
        };
        let protection_len = if mode.plaintext() || page_objects_are_clear_text(objects)? {
            32
        } else {
            16
        };
        let len = body_len
            .checked_add(PAGE_HEADER_LEN + protection_len)
            .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".into()))?;
        return if mode.unpadded() {
            checked_unpadded_len(len, max_page_size_for_objects(objects))
        } else {
            page_size_for_stored_len(len, max_page_size_for_objects(objects))
        };
    }
    if objects.iter().any(|object| {
        matches!(
            object.kind,
            PageObjectKind::FileData | PageObjectKind::PackedFileData
        )
    }) {
        return Ok(page_size_for_objects(objects));
    }
    let max_page_size = max_page_size_for_objects(objects);
    let mut object_stream = encode_object_stream(objects)?;
    page_size_for_object_stream_len(object_stream.len(), max_page_size)?;
    let compress_body = objects_allow_body_compression(objects, mode);
    let body = encode_page_body_plaintext(&object_stream, compress_body);
    object_stream.zeroize();
    let stored_body_len = if page_objects_are_clear_text(objects)? {
        body.len()
            .checked_add(32)
            .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".to_string()))?
    } else {
        body.len()
            .checked_add(16)
            .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".to_string()))?
    };
    let stored_len = PAGE_HEADER_LEN
        .checked_add(stored_body_len)
        .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
    page_size_for_stored_len(stored_len, max_page_size)
}

fn max_page_size_for_objects(objects: &[PageObject]) -> usize {
    if objects.iter().any(|object| {
        matches!(
            object.kind,
            PageObjectKind::FileData | PageObjectKind::PackedFileData
        )
    }) {
        DEFAULT_DATA_PAGE_BYTES
    } else {
        DEFAULT_METADATA_PAGE_BYTES
    }
}

pub(crate) fn page_size_for_object_stream_len(
    object_stream_len: usize,
    max_page_size: usize,
) -> Result<usize> {
    let needed = PAGE_HEADER_LEN
        .checked_add(PAGE_UNCOMPRESSED_BODY_OVERHEAD)
        .and_then(|len| len.checked_add(object_stream_len))
        .ok_or_else(|| Error::SecurityLimitExceeded("page is too large".to_string()))?;
    page_size_for_stored_len(needed, max_page_size)
}

pub(crate) fn page_size_for_stored_len(stored_len: usize, max_page_size: usize) -> Result<usize> {
    let rounded = stored_len
        .checked_add(PAGE_SIZE_GRANULARITY - 1)
        .ok_or_else(|| Error::SecurityLimitExceeded("page is too large".to_string()))?
        / PAGE_SIZE_GRANULARITY
        * PAGE_SIZE_GRANULARITY;
    let page_size = rounded.max(MIN_PAGE_BYTES);
    if page_size > max_page_size {
        return Err(Error::SecurityLimitExceeded(
            "page body exceeds maximum page size".to_string(),
        ));
    }
    Ok(page_size)
}

pub(crate) fn is_canonical_control_kind(kind: PageObjectKind) -> bool {
    matches!(kind, PageObjectKind::CommitRoot | PageObjectKind::CommitAuth | PageObjectKind::KeyDirectory)
}

/// Fixed raw framing, with no compression or encoder-version dependency.
pub(crate) fn canonical_control_page_len(
    payload_len: usize, kind: PageObjectKind, mode: crate::creation_options::FormatMode,
) -> Result<u64> {
    if !is_canonical_control_kind(kind) { return Err(Error::CorruptRecord); }
    Ok(canonical_control_page_len_from_flags(
        payload_len, mode.unpadded(), mode.plaintext() || kind == PageObjectKind::KeyDirectory,
    )? as u64)
}

fn canonical_control_page_len_from_flags(payload_len: usize, unpadded: bool, clear: bool) -> Result<usize> {
    let len = payload_len.checked_add(PAGE_HEADER_LEN + 16 + 4 + 20 + if clear { 32 } else { 16 })
        .ok_or(Error::CorruptRecord)?;
    if unpadded { checked_unpadded_len(len, DEFAULT_METADATA_PAGE_BYTES) }
    else { page_size_for_stored_len(len, DEFAULT_METADATA_PAGE_BYTES) }
}

pub(crate) fn validate_control_model(page: &DecodedPage, offset: u64, kind: PageObjectKind) -> Result<()> {
    let [object] = page.objects.as_slice() else { return Err(Error::CorruptRecord); };
    if object.kind != kind || page.page_id != offset || object.id != page.sequence {
        return Err(Error::CorruptRecord);
    }
    let sequence = object.with_payload(|payload| match kind {
        PageObjectKind::CommitRoot => crate::commit_root::decode_commit_root(payload).map(|root| root.sequence),
        PageObjectKind::CommitAuth => crate::commit_auth::decode_commit_auth(payload).map(|auth| auth.sequence),
        _ => Err(Error::CorruptRecord),
    })??;
    if page.sequence != sequence { return Err(Error::CorruptRecord); }
    Ok(())
}

/// Recover only a damaged physical-length field using the retained header
/// checksum. The search is bounded by the format maximum and surviving bytes;
/// callers must still authenticate the page body and its owning publication.
pub(crate) fn recover_physical_length_header(bytes: &[u8]) -> Option<[u8; PAGE_HEADER_LEN]> {
    let mut header: [u8; PAGE_HEADER_LEN] = bytes.get(..PAGE_HEADER_LEN)?.try_into().ok()?;
    if &header[..8] != PAGE_MAGIC
        || read_u16_le(&header[8..10]).ok()? != PAGE_VERSION
        || read_u32_le(&header[12..16]).ok()? as usize != PAGE_HEADER_LEN
        || header[PAGE_CHECKSUM_START..] == strong_checksum(&header[..PAGE_CHECKSUM_START])
    {
        return None;
    }
    let stored_len = PAGE_HEADER_LEN.checked_add(read_u32_le(&header[44..48]).ok()? as usize)?;
    let flags = read_u16_le(&header[10..12]).ok()?;
    if flags & !(PAGE_FLAG_CLEAR_TEXT | PAGE_FLAG_UNPADDED) != 0 {
        return None;
    }
    let maximum = bytes.len().min(DEFAULT_DATA_PAGE_BYTES);
    let (first, step, last) = if flags & PAGE_FLAG_UNPADDED != 0 {
        (stored_len, 1, stored_len.min(maximum))
    } else {
        (
            page_size_for_stored_len(stored_len, maximum).ok()?,
            PAGE_SIZE_GRANULARITY,
            maximum,
        )
    };
    for physical_len in (first..=last).step_by(step) {
        header[48..56].copy_from_slice(&(physical_len as u64).to_le_bytes());
        if header[PAGE_CHECKSUM_START..] == strong_checksum(&header[..PAGE_CHECKSUM_START]) {
            physical_page_size_from_page_slice(&header).ok()?;
            return Some(header);
        }
    }
    None
}

pub(crate) fn physical_page_size_from_page_slice(page: &[u8]) -> Result<usize> {
    if page.len() < PAGE_HEADER_LEN || page.get(0..8) != Some(PAGE_MAGIC.as_slice()) {
        return Err(Error::CorruptRecord);
    }
    let header_len = read_u32_le(&page[12..16])? as usize;
    let stored_body_len = read_u32_le(&page[44..48])? as usize;
    let stored_len = header_len
        .checked_add(stored_body_len)
        .ok_or(Error::CorruptRecord)?;
    let physical_len = read_u64_le(&page[48..56])?;
    let flags = read_u16_le(&page[10..12])?;
    let unpadded = flags & PAGE_FLAG_UNPADDED != 0;
    if physical_len < stored_len as u64
        || physical_len > DEFAULT_DATA_PAGE_BYTES as u64
        || physical_len == 0
        || flags & !(PAGE_FLAG_CLEAR_TEXT | PAGE_FLAG_UNPADDED) != 0
        || if unpadded {
            physical_len != stored_len as u64
        } else {
            physical_len % PAGE_SIZE_GRANULARITY as u64 != 0
        }
    {
        return Err(Error::CorruptRecord);
    }
    Ok(physical_len as usize)
}

fn checked_unpadded_len(len: usize, maximum: usize) -> Result<usize> {
    if len > maximum {
        return Err(Error::SecurityLimitExceeded(
            "page body exceeds maximum page size".into(),
        ));
    }
    Ok(len)
}

/// Calculate a private tree page extent without exposing its secret payload.
pub(crate) fn secure_page_size(
    payload_len: usize,
    mode: crate::creation_options::FormatMode,
) -> Result<usize> {
    if !mode.unpadded() {
        return Ok(DEFAULT_METADATA_PAGE_BYTES);
    }
    // Object count + single object header + uncompressed body header + protection.
    let overhead = PAGE_HEADER_LEN + 4 + 20 + if mode.plaintext() { 16 + 32 } else { 33 + 16 };
    let len = payload_len
        .checked_add(overhead)
        .ok_or(Error::CorruptRecord)?;
    checked_unpadded_len(len, DEFAULT_METADATA_PAGE_BYTES)
}

fn validate_padding_flag(flags: u16, mode: crate::creation_options::FormatMode) -> Result<()> {
    if flags & !(PAGE_FLAG_CLEAR_TEXT | PAGE_FLAG_UNPADDED) != 0
        || (flags & PAGE_FLAG_UNPADDED != 0) != mode.unpadded()
    {
        return Err(Error::CorruptRecord);
    }
    Ok(())
}

impl PageObjectKind {
    fn from_u8(value: u8) -> Result<Self> {
        match value {
            1 => Ok(Self::CommitRoot),
            2 => Ok(Self::TocLeaf),
            3 => Ok(Self::TocInternal),
            4 => Ok(Self::FileData),
            5 => Ok(Self::PackedFileData),
            6 => Ok(Self::Symlink),
            7 => Ok(Self::VariableSet),
            8 => Ok(Self::VariableDelete),
            9 => Ok(Self::KeyDirectory),
            10 => Ok(Self::FreeIndexLeaf),
            11 => Ok(Self::FreeIndexInternal),
            12 => Ok(Self::Delete),
            13 => Ok(Self::VariableLeaf),
            14 => Ok(Self::VariableInternal),
            15 => Ok(Self::FormLeaf),
            16 => Ok(Self::FormInternal),
            17 => Ok(Self::CommitAuth),
            18 => Ok(Self::RedactionManifest),
            _ => Err(Error::CorruptRecord),
        }
    }

    fn is_clear_text_page_object(self) -> bool {
        matches!(self, Self::KeyDirectory)
    }
}

#[derive(Debug)]
pub(crate) enum PagePayload {
    Normal(Vec<u8>),
    Secure(SecureVec),
}

impl PagePayload {
    pub(crate) fn normal(payload: Vec<u8>) -> Self {
        Self::Normal(payload)
    }

    pub(crate) fn secure(payload: SecureVec) -> Self {
        Self::Secure(payload)
    }

    pub(crate) fn len(&self) -> usize {
        match self {
            Self::Normal(payload) => payload.len(),
            Self::Secure(payload) => payload.len(),
        }
    }

    pub(crate) fn with_bytes<R>(&self, f: impl FnOnce(&[u8]) -> R) -> Result<R> {
        match self {
            Self::Normal(payload) => Ok(f(payload)),
            Self::Secure(payload) => {
                secure_read_access(|access| payload.with_bytes_in(access, f)).map_err(Into::into)
            }
        }
    }

    pub(crate) fn try_clone(&self) -> Result<Self> {
        match self {
            Self::Normal(payload) => Ok(Self::Normal(payload.clone())),
            Self::Secure(payload) => Ok(Self::Secure(payload.try_clone()?)),
        }
    }

    pub(crate) fn as_secure(&self) -> Option<&SecureVec> {
        match self {
            Self::Normal(_) => None,
            Self::Secure(payload) => Some(payload),
        }
    }
}

impl Drop for PagePayload {
    fn drop(&mut self) {
        if let Self::Normal(payload) = self {
            zeroize_bytes(payload);
        }
    }
}

impl Clone for PagePayload {
    fn clone(&self) -> Self {
        match self.try_clone() {
            Ok(payload) => payload,
            Err(_) => std::process::abort(),
        }
    }
}

impl PartialEq for PagePayload {
    fn eq(&self, other: &Self) -> bool {
        self.with_bytes(|left| other.with_bytes(|right| left == right))
            .ok()
            .and_then(Result::ok)
            .unwrap_or(false)
    }
}

impl Eq for PagePayload {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct PageObject {
    pub(crate) kind: PageObjectKind,
    pub(crate) id: u64,
    pub(crate) payload: PagePayload,
}

impl PageObject {
    pub(crate) fn new(kind: PageObjectKind, id: u64, payload: Vec<u8>) -> Self {
        Self {
            kind,
            id,
            payload: PagePayload::normal(payload),
        }
    }

    pub(crate) fn new_secure(kind: PageObjectKind, id: u64, payload: SecureVec) -> Self {
        Self {
            kind,
            id,
            payload: PagePayload::secure(payload),
        }
    }

    pub(crate) fn payload_len(&self) -> usize {
        self.payload.len()
    }

    pub(crate) fn with_payload<R>(&self, f: impl FnOnce(&[u8]) -> R) -> Result<R> {
        self.payload.with_bytes(f)
    }

    pub(crate) fn secure_payload(&self) -> Option<&SecureVec> {
        self.payload.as_secure()
    }
}

pub(crate) fn encoded_object_stream_len(objects: &[PageObject]) -> Result<usize> {
    let mut len = 4usize;
    for object in objects {
        len = len
            .checked_add(encoded_object_len(object)?)
            .ok_or_else(|| Error::SecurityLimitExceeded("page is too large".to_string()))?;
    }
    Ok(len)
}

pub(crate) fn encoded_object_len(object: &PageObject) -> Result<usize> {
    20usize
        .checked_add(object.payload_len())
        .ok_or_else(|| Error::SecurityLimitExceeded("page object is too large".to_string()))
}

pub(crate) fn uncompressed_objects_fit(page_size: usize, object_stream_len: usize) -> bool {
    page_size_for_object_stream_len(object_stream_len, page_size)
        .is_ok_and(|needed| needed <= page_size)
}

#[derive(Debug, Clone)]
pub(crate) struct DecodedPage {
    pub(crate) page_id: u64,
    pub(crate) sequence: u64,
    pub(crate) objects: Vec<PageObject>,
}

pub(crate) struct SecureSingleObjectPage<'a> {
    pub(crate) format_mode: crate::creation_options::FormatMode,
    pub(crate) page_size: usize,
    pub(crate) lockbox_id: LockboxId,
    pub(crate) page_id: u64,
    pub(crate) sequence: u64,
    pub(crate) content_key: &'a [u8; 32],
    pub(crate) kind: PageObjectKind,
    pub(crate) id: u64,
    pub(crate) payload: &'a SecureVec,
}

// Raw page codecs used by PageCache. Production lockbox read/write paths should
// not call these directly; recovery and low-level format tests are the
// exceptions for raw page codecs in this module.
#[cfg(test)]
pub(crate) fn encode_page(
    page_size: usize,
    lockbox_id: LockboxId,
    page_id: u64,
    sequence: u64,
    key: &[u8],
    objects: &[PageObject],
) -> Result<Vec<u8>> {
    encode_page_with_format(
        page_size,
        lockbox_id,
        page_id,
        sequence,
        key,
        objects,
        Default::default(),
    )
}

fn objects_allow_body_compression(
    objects: &[PageObject],
    mode: crate::creation_options::FormatMode,
) -> bool {
    !objects.iter().any(|object| {
        matches!(
            object.kind,
            PageObjectKind::FileData | PageObjectKind::PackedFileData
                | PageObjectKind::CommitRoot | PageObjectKind::CommitAuth | PageObjectKind::KeyDirectory
        ) || (mode.0 != 0
            && matches!(
                object.kind,
                PageObjectKind::VariableLeaf
                    | PageObjectKind::VariableInternal
                    | PageObjectKind::FormLeaf
                    | PageObjectKind::FormInternal
            ))
    })
}

fn encode_objects_body(
    objects: &[PageObject],
    mode: crate::creation_options::FormatMode,
) -> Result<Vec<u8>> {
    let mut object_stream = encode_object_stream(objects)?;
    let compress_body = objects_allow_body_compression(objects, mode);
    let body = if mode.0 == 0
        || !compress_body
        || mode.options().compression == crate::Compression::None
    {
        encode_page_body_plaintext(
            &object_stream,
            compress_body
                && (mode.0 == 0 || mode.options().compression != crate::Compression::None),
        )
    } else {
        let (algorithm, stored) =
            crate::compression::encode_with_compression(&object_stream, mode.options().compression);
        let mut body = vec![PAGE_BODY_VERSION, COMPRESSION_NORMAL, 0, 0];
        body.extend_from_slice(&(object_stream.len() as u64).to_le_bytes());
        body.extend_from_slice(&0u32.to_le_bytes());
        body.extend_from_slice(&(object_stream.len() as u64).to_le_bytes());
        body.push(algorithm);
        body.extend_from_slice(&(stored.len() as u64).to_le_bytes());
        body.extend_from_slice(&stored);
        body
    };
    object_stream.zeroize();
    Ok(body)
}

pub(crate) fn encode_page_with_format(
    page_size: usize,
    lockbox_id: LockboxId,
    page_id: u64,
    sequence: u64,
    key: &[u8],
    objects: &[PageObject],
    mode: crate::creation_options::FormatMode,
) -> Result<Vec<u8>> {
    if page_size < PAGE_HEADER_LEN {
        return Err(Error::CorruptRecord);
    }
    let mut body = encode_objects_body(objects, mode)?;
    let clear_text = mode.plaintext() || page_objects_are_clear_text(objects)?;
    let flags = if clear_text { PAGE_FLAG_CLEAR_TEXT } else { 0 }
        | if mode.unpadded() {
            PAGE_FLAG_UNPADDED
        } else {
            0
        };
    let (nonce, mut stored_body) = if clear_text {
        let mut stored = Vec::with_capacity(32 + body.len());
        stored.extend_from_slice(&strong_checksum(&body));
        stored.extend_from_slice(&body);
        ([0; 12], stored)
    } else {
        let encrypted_len = body
            .len()
            .checked_add(16)
            .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
        let encrypted_len = u32::try_from(encrypted_len)
            .map_err(|_| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
        let aad = page_aad(
            lockbox_id,
            page_id,
            sequence,
            flags,
            encrypted_len,
            page_size as u64,
        );
        seal_with_random_nonce(&body, key, &aad)?
    };
    body.zeroize();
    let stored_body_len = u32::try_from(stored_body.len())
        .map_err(|_| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
    if PAGE_HEADER_LEN + stored_body.len() > page_size {
        return Err(Error::SecurityLimitExceeded(
            "page body exceeds physical page size".to_string(),
        ));
    }
    if mode.unpadded() && PAGE_HEADER_LEN + stored_body.len() != page_size {
        return Err(Error::CorruptRecord);
    }

    let mut page = vec![0; page_size];
    page[0..8].copy_from_slice(PAGE_MAGIC);
    page[8..10].copy_from_slice(&PAGE_VERSION.to_le_bytes());
    page[10..12].copy_from_slice(&flags.to_le_bytes());
    page[12..16].copy_from_slice(&(PAGE_HEADER_LEN as u32).to_le_bytes());
    page[16..24].copy_from_slice(&page_id.to_le_bytes());
    page[24..32].copy_from_slice(&sequence.to_le_bytes());
    page[32..44].copy_from_slice(&nonce);
    page[44..48].copy_from_slice(&stored_body_len.to_le_bytes());
    page[48..56].copy_from_slice(&(page_size as u64).to_le_bytes());
    let header_digest = strong_checksum(&page[0..PAGE_CHECKSUM_START]);
    page[PAGE_CHECKSUM_START..PAGE_HEADER_LEN].copy_from_slice(&header_digest);
    page[PAGE_HEADER_LEN..PAGE_HEADER_LEN + stored_body.len()].copy_from_slice(&stored_body);
    stored_body.zeroize();
    Ok(page)
}

pub(crate) fn decode_page(page: &[u8], lockbox_id: LockboxId, key: &[u8]) -> Result<DecodedPage> {
    decode_page_with_format(page, lockbox_id, key, Default::default())
}

pub(crate) fn decode_page_with_format(
    page: &[u8],
    lockbox_id: LockboxId,
    key: &[u8],
    mode: crate::creation_options::FormatMode,
) -> Result<DecodedPage> {
    if page.len() < PAGE_HEADER_LEN {
        return Err(Error::Truncated);
    }
    if &page[0..8] != PAGE_MAGIC {
        return Err(Error::CorruptRecord);
    }
    if read_u16_le(&page[8..10])? != PAGE_VERSION {
        return Err(Error::CorruptRecord);
    }
    let flags = read_u16_le(&page[10..12])?;
    if flags & !(PAGE_FLAG_CLEAR_TEXT | PAGE_FLAG_UNPADDED) != 0 {
        return Err(Error::CorruptRecord);
    }
    physical_page_size_from_page_slice(page)?;
    let header_len = read_u32_le(&page[12..16])? as usize;
    if header_len != PAGE_HEADER_LEN || header_len > page.len() {
        return Err(Error::CorruptRecord);
    }
    if page[56..PAGE_CHECKSUM_START].iter().any(|byte| *byte != 0) {
        return Err(Error::CorruptRecord);
    }
    let expected_digest = strong_checksum(&page[0..PAGE_CHECKSUM_START]);
    if page[PAGE_CHECKSUM_START..PAGE_HEADER_LEN] != expected_digest {
        return Err(Error::CorruptRecord);
    }

    let page_id = read_u64_le(&page[16..24])?;
    let sequence = read_u64_le(&page[24..32])?;
    let nonce = &page[32..44];
    let stored_body_len = read_u32_le(&page[44..48])? as usize;
    if header_len + stored_body_len > page.len() {
        return Err(Error::Truncated);
    }
    let stored_body = &page[header_len..header_len + stored_body_len];
    let decrypted;
    let body = if flags & PAGE_FLAG_CLEAR_TEXT != 0 {
        if nonce.iter().any(|byte| *byte != 0) || stored_body.len() < 32 {
            return Err(Error::CorruptRecord);
        }
        let (digest, body) = stored_body.split_at(32);
        if digest != strong_checksum(body) {
            return Err(Error::CorruptRecord);
        }
        body
    } else {
        let aad = page_aad(
            lockbox_id,
            page_id,
            sequence,
            flags,
            stored_body_len as u32,
            physical_page_size_from_page_slice(page)? as u64,
        );
        decrypted = ZeroizingBytes::new(open_with_nonce(stored_body, key, nonce, &aad)?);
        decrypted.as_slice()
    };
    if mode.0 != 0
        && mode.options().compression == crate::Compression::None
        && body.get(1) == Some(&COMPRESSION_NORMAL)
        && body.get(24) != Some(&COMPRESSION_NONE)
    {
        return Err(Error::CorruptRecord);
    }
    let objects = match decode_page_body_plaintext(body)? {
        Cow::Borrowed(bytes) => decode_object_stream(bytes)?,
        Cow::Owned(bytes) => decode_object_stream(&ZeroizingBytes::new(bytes))?,
    };
    if objects.iter().any(|object| is_canonical_control_kind(object.kind)) {
        let [object] = objects.as_slice() else { return Err(Error::CorruptRecord); };
        if body.get(1) != Some(&COMPRESSION_NONE)
            || body[2..4] != [0; 2] || body[12..16] != [0; 4]
            || object.id != sequence
            || physical_page_size_from_page_slice(page)? != canonical_control_page_len_from_flags(
                object.payload_len(), flags & PAGE_FLAG_UNPADDED != 0, flags & PAGE_FLAG_CLEAR_TEXT != 0,
            )? {
            return Err(Error::CorruptRecord);
        }
    }
    // Key-directory bootstrap/recovery can run before a trustworthy archive
    // header is available. Its public, self-describing page extent is checked
    // above; every private/content page must match the persisted archive policy.
    if !page_objects_are_clear_text(&objects)? {
        validate_padding_flag(flags, mode)?;
    }
    let clear_text = mode.plaintext() || page_objects_are_clear_text(&objects)?;
    if clear_text != (flags & PAGE_FLAG_CLEAR_TEXT != 0) {
        return Err(Error::CorruptRecord);
    }
    Ok(DecodedPage {
        page_id,
        sequence,
        objects,
    })
}

pub(crate) fn decode_single_object_page_secure_with_format(
    page: &mut SecureVec,
    lockbox_id: LockboxId,
    content_key: &[u8; 32],
    mode: crate::creation_options::FormatMode,
) -> Result<DecodedPage> {
    let (page_id, sequence) = decrypt_page_body_secure(page, lockbox_id, content_key, mode)?;
    decode_page_body_plaintext_in_place(page)?;
    let (kind, id, payload) = decode_single_object_stream_in_place(page)?;
    let object = PageObject::new_secure(kind, id, payload);
    Ok(DecodedPage {
        page_id,
        sequence,
        objects: vec![object],
    })
}

pub(crate) fn encode_single_object_page_secure(
    request: SecureSingleObjectPage<'_>,
) -> Result<Vec<u8>> {
    encode_single_object_page_secure_using(request, seal_with_content_key_secure)
}
fn encode_single_object_page_secure_using(
    request: SecureSingleObjectPage<'_>,
    seal: impl FnOnce(&mut SecureVec, &[u8; 32], &[u8]) -> Result<[u8; 12]>,
) -> Result<Vec<u8>> {
    if request.page_size < PAGE_HEADER_LEN {
        return Err(Error::SecurityLimitExceeded(
            "page is smaller than the header".to_string(),
        ));
    }
    if request.kind.is_clear_text_page_object() {
        return Err(Error::CorruptRecord);
    }

    let mut body = SecureVec::new();
    body.try_extend_from_slice(&1u32.to_le_bytes())?;
    body.try_extend_from_slice(&[request.kind as u8, 1])?;
    body.try_extend_from_slice(&0u16.to_le_bytes())?;
    body.try_extend_from_slice(&request.id.to_le_bytes())?;
    body.try_extend_from_slice(&(request.payload.len() as u64).to_le_bytes())?;
    body.try_extend_from_secure(request.payload)?;

    let object_stream_len = body.len();
    let mut page_body = SecureVec::new();
    page_body.try_extend_from_slice(&[PAGE_BODY_VERSION, COMPRESSION_NORMAL, 0, 0])?;
    page_body.try_extend_from_slice(&(object_stream_len as u64).to_le_bytes())?;
    page_body.try_extend_from_slice(&0u32.to_le_bytes())?;
    page_body.try_extend_from_slice(&(object_stream_len as u64).to_le_bytes())?;
    page_body.try_extend_from_slice(&[COMPRESSION_NONE])?;
    page_body.try_extend_from_slice(&(object_stream_len as u64).to_le_bytes())?;
    page_body.try_extend_from_secure(&body)?;
    body.zeroize()?;

    let encrypted_len = page_body
        .len()
        .checked_add(16)
        .ok_or_else(|| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
    let encrypted_len = u32::try_from(encrypted_len)
        .map_err(|_| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
    let flags = if request.format_mode.unpadded() {
        PAGE_FLAG_UNPADDED
    } else {
        0
    };
    let aad = page_aad(
        request.lockbox_id,
        request.page_id,
        request.sequence,
        flags,
        encrypted_len,
        request.page_size as u64,
    );
    let nonce = seal(&mut page_body, request.content_key, &aad)?;
    let stored_body_len = u32::try_from(page_body.len())
        .map_err(|_| Error::SecurityLimitExceeded("page body is too large".to_string()))?;
    if PAGE_HEADER_LEN + page_body.len() > request.page_size {
        return Err(Error::SecurityLimitExceeded(
            "page body exceeds physical page size".to_string(),
        ));
    }
    if request.format_mode.unpadded() && PAGE_HEADER_LEN + page_body.len() != request.page_size {
        return Err(Error::CorruptRecord);
    }

    let mut page = vec![0; request.page_size];
    page[0..8].copy_from_slice(PAGE_MAGIC);
    page[8..10].copy_from_slice(&PAGE_VERSION.to_le_bytes());
    page[10..12].copy_from_slice(&flags.to_le_bytes());
    page[12..16].copy_from_slice(&(PAGE_HEADER_LEN as u32).to_le_bytes());
    page[16..24].copy_from_slice(&request.page_id.to_le_bytes());
    page[24..32].copy_from_slice(&request.sequence.to_le_bytes());
    page[32..44].copy_from_slice(&nonce);
    page[44..48].copy_from_slice(&stored_body_len.to_le_bytes());
    page[48..56].copy_from_slice(&(request.page_size as u64).to_le_bytes());
    let header_digest = strong_checksum(&page[0..PAGE_CHECKSUM_START]);
    page[PAGE_CHECKSUM_START..PAGE_HEADER_LEN].copy_from_slice(&header_digest);
    secure_read_access(|access| {
        page_body.with_bytes_in(access, |encrypted| {
            page[PAGE_HEADER_LEN..PAGE_HEADER_LEN + encrypted.len()].copy_from_slice(encrypted);
        })
    })?;
    page_body.zeroize()?;
    Ok(page)
}

fn decrypt_page_body_secure(
    page: &mut SecureVec,
    lockbox_id: LockboxId,
    content_key: &[u8; 32],
    mode: crate::creation_options::FormatMode,
) -> Result<(u64, u64)> {
    let header: (u64, u64, [u8; 12], u16, usize, usize, u64) = {
        let parsed = secure_read_access(|access| {
            page.with_bytes_in(access, |page| {
                if page.len() < PAGE_HEADER_LEN {
                    return Err(Error::Truncated);
                }
                if &page[0..8] != PAGE_MAGIC {
                    return Err(Error::CorruptRecord);
                }
                if read_u16_le(&page[8..10])? != PAGE_VERSION {
                    return Err(Error::CorruptRecord);
                }
                let flags = read_u16_le(&page[10..12])?;
                validate_padding_flag(flags, mode)?;
                let header_len = read_u32_le(&page[12..16])? as usize;
                if header_len != PAGE_HEADER_LEN || header_len > page.len() {
                    return Err(Error::CorruptRecord);
                }
                if page[56..PAGE_CHECKSUM_START].iter().any(|byte| *byte != 0) {
                    return Err(Error::CorruptRecord);
                }
                let expected_digest = strong_checksum(&page[0..PAGE_CHECKSUM_START]);
                if page[PAGE_CHECKSUM_START..PAGE_HEADER_LEN] != expected_digest {
                    return Err(Error::CorruptRecord);
                }
                let stored_body_len = read_u32_le(&page[44..48])? as usize;
                if header_len + stored_body_len > page.len() {
                    return Err(Error::Truncated);
                }
                Ok((
                    read_u64_le(&page[16..24])?,
                    read_u64_le(&page[24..32])?,
                    array_12(&page[32..44])?,
                    flags,
                    header_len,
                    stored_body_len,
                    physical_page_size_from_page_slice(page)? as u64,
                ))
            })
        })?;
        parsed?
    };
    let (page_id, sequence, nonce, flags, header_len, stored_body_len, physical_len) = header;
    if (flags & PAGE_FLAG_CLEAR_TEXT != 0) != mode.plaintext() {
        return Err(Error::CorruptRecord);
    }
    if mode.plaintext() {
        if nonce != [0; 12] || stored_body_len < 32 {
            return Err(Error::CorruptRecord);
        }
        let valid = page.with_bytes(|bytes| {
            let stored = &bytes[header_len..header_len + stored_body_len];
            stored[..32] == strong_checksum(&stored[32..])
        })?;
        if !valid {
            return Err(Error::CorruptRecord);
        }
        page.with_mut_bytes(|bytes| {
            bytes.copy_within(header_len + 32..header_len + stored_body_len, 0)
        })?;
        page.truncate(stored_body_len - 32)?;
        return Ok((page_id, sequence));
    }
    page.with_mut_bytes(|bytes| {
        bytes.copy_within(header_len..header_len + stored_body_len, 0);
    })?;
    page.truncate(stored_body_len)?;
    let aad = page_aad(
        lockbox_id,
        page_id,
        sequence,
        flags,
        stored_body_len as u32,
        physical_len,
    );
    open_with_content_key_secure(page, content_key, &nonce, &aad)?;
    Ok((page_id, sequence))
}

fn decode_page_body_plaintext_in_place<B: PageBuffer>(body: &mut B) -> Result<()> {
    let (stored_offset, stored_len) = {
        let parsed = body.with_bytes(|body| {
            if body.len() >= 16 && body[0] == PAGE_BODY_VERSION && body[1] == COMPRESSION_NONE {
                let len = usize::try_from(read_u64_le(&body[4..12])?)
                    .map_err(|_| Error::CorruptRecord)?;
                if len != body.len() - 16 {
                    return Err(Error::CorruptRecord);
                }
                return Ok((16, len));
            }
            if body.len() < 33 {
                return Err(Error::CorruptRecord);
            }
            if body[0] != PAGE_BODY_VERSION || body[1] != COMPRESSION_NORMAL {
                return Err(Error::CorruptRecord);
            }
            let expected_len = read_u64_le(&body[4..12])? as usize;
            let compression = &body[16..];
            let real_len = read_u64_le(&compression[0..8])? as usize;
            let algorithm = compression[8];
            let stored_len = read_u64_le(&compression[9..17])? as usize;
            if algorithm != COMPRESSION_NONE {
                return Err(Error::CorruptRecord);
            }
            if expected_len != real_len || stored_len != real_len {
                return Err(Error::CorruptRecord);
            }
            let stored_offset = 16usize + 17;
            if stored_offset + stored_len > body.len() {
                return Err(Error::CorruptRecord);
            }
            Ok((stored_offset, stored_len))
        })?;
        parsed?
    };
    body.with_mut_bytes(|bytes| {
        bytes.copy_within(stored_offset..stored_offset + stored_len, 0);
    })?;
    body.truncate(stored_len)?;
    Ok(())
}

fn decode_single_object_stream_in_place<B: PageBuffer>(
    stream: &mut B,
) -> Result<(PageObjectKind, u64, B)> {
    let (kind, id, payload_offset, payload_len) = {
        let parsed = stream.with_bytes(|bytes| {
            if bytes.len() < 24 {
                return Err(Error::CorruptRecord);
            }
            let count = read_u32_le(&bytes[0..4])?;
            if count != 1 {
                return Err(Error::CorruptRecord);
            }
            let kind = PageObjectKind::from_u8(bytes[4])?;
            let version = bytes[5];
            let flags = read_u16_le(&bytes[6..8])?;
            if version != 1 || flags != 0 {
                return Err(Error::CorruptRecord);
            }
            let id = read_u64_le(&bytes[8..16])?;
            let payload_len = read_u64_le(&bytes[16..24])? as usize;
            let payload_offset = 24usize;
            if payload_offset + payload_len != bytes.len() {
                return Err(Error::CorruptRecord);
            }
            Ok((kind, id, payload_offset, payload_len))
        })?;
        parsed?
    };
    stream.with_mut_bytes(|bytes| {
        bytes.copy_within(payload_offset..payload_offset + payload_len, 0);
    })?;
    stream.truncate(payload_len)?;
    let payload = stream.try_clone_range(0, payload_len)?;
    Ok((kind, id, payload))
}

#[cfg(test)]
pub(crate) fn scan_page_records(bytes: &[u8], lockbox_id: LockboxId, key: &[u8]) -> Scan {
    #[cfg(any(test, feature = "native-block-layout"))]
    let mut native_pages = Vec::new();
    let mode = crate::file_format::current_header::read_header_for_scan(bytes)
        .map(|header| header.format_mode)
        .unwrap_or_default();
    let mut records = Vec::new();
    let mut corrupt_records = 0usize;
    let mut content_key = derive_page_content_key(key);
    let mut i = crate::constants::HEADER_LEN;
    while i + PAGE_HEADER_LEN <= bytes.len() {
        if &bytes[i..i + 8] == PAGE_MAGIC {
            #[cfg(any(test, feature = "native-block-layout"))]
            if crate::file_format::indexed_frame::block_page::is_native_header(&bytes[i..]) {
                match crate::file_format::indexed_frame::block_page::scan(
                    bytes, i, lockbox_id, mode, key,
                ) {
                    Ok(page) => {
                        i += page.physical_len;
                        native_pages.push(page);
                    }
                    Err(_) => {
                        corrupt_records += 1;
                        i += 1;
                    }
                }
                continue;
            }
            let Some(page_bytes) = page_decode_slice(bytes, i) else {
                corrupt_records += 1;
                break;
            };
            if decode_secure_variable_page_inspection(page_bytes, lockbox_id, &content_key, mode)
                .is_some()
            {
                i += physical_page_size_from_page_slice(page_bytes)
                    .unwrap_or(DEFAULT_METADATA_PAGE_BYTES);
                continue;
            }
            match decode_page_with_format(page_bytes, lockbox_id, key, mode) {
                Ok(page) => {
                    let page_size = physical_page_size_from_page_slice(page_bytes)
                        .unwrap_or_else(|_| page_size_for_objects(&page.objects));
                    for object in page.objects {
                        if let Some(kind) = record_kind_from_object_kind(object.kind) {
                            let Ok(payload) = object.with_payload(|payload| payload.to_vec())
                            else {
                                corrupt_records += 1;
                                continue;
                            };
                            records.push(DecodedRecord {
                                header: RecordHeader {
                                    kind,
                                    sequence: page.sequence,
                                    total_len: page_size as u64,
                                },
                                offset: i as u64,
                                object_id: object.id,
                                payload,
                            });
                        }
                    }
                    i += page_size;
                }
                Err(_) => {
                    corrupt_records += 1;
                    i += 1;
                }
            }
        } else {
            i += 1;
        }
    }
    content_key.zeroize();
    records.sort_by_key(|record| record.header.sequence);
    #[cfg(any(test, feature = "native-block-layout"))]
    native_pages.sort_by_key(|page| page.sequence);
    Scan {
        #[cfg(any(test, feature = "native-block-layout"))]
        native_pages,
        records,
        corrupt_records,
    }
}

pub(crate) fn inspect_pages(
    bytes: &[u8],
    lockbox_id: LockboxId,
    key: &[u8],
) -> Vec<PageInspection> {
    let mode = crate::file_format::current_header::read_header(bytes)
        .map(|header| header.format_mode)
        .unwrap_or_default();
    let mut pages = Vec::new();
    let mut content_key = derive_page_content_key(key);
    let mut i = crate::constants::HEADER_LEN;
    while i + PAGE_HEADER_LEN <= bytes.len() {
        if &bytes[i..i + 8] == PAGE_MAGIC {
            #[cfg(any(test, feature = "native-block-layout"))]
            if crate::file_format::indexed_frame::block_page::is_native_header(&bytes[i..]) {
                match crate::file_format::indexed_frame::block_page::scan(
                    bytes, i, lockbox_id, mode, key,
                ) {
                    Ok(page) => {
                        // scan validates the complete frame and its protected
                        // metadata before these diagnostic fields are exposed.
                        let stored_body_len = read_u32_le(&bytes[i + 44..i + 48])
                            .expect("scanned native header has a body length");
                        pages.push(PageInspection {
                            offset: i as u64,
                            page_id: page.page_id,
                            sequence: page.sequence,
                            page_size: page.physical_len as u32,
                            encrypted_body_len: stored_body_len,
                            unused_bytes: (page.physical_len
                                - PAGE_HEADER_LEN
                                - stored_body_len as usize)
                                as u32,
                            object_count: 1,
                            objects: vec![PageObjectInspection {
                                id: page.descriptor.frame_id,
                                kind: "file-data",
                                payload_len: page.descriptor.logical_len as usize,
                            }],
                        });
                        i += page.physical_len;
                    }
                    Err(_) => i += 1,
                }
                continue;
            }
            let Some(page_bytes) = page_decode_slice(bytes, i) else {
                break;
            };
            if let Some(inspection) =
                inspect_secure_variable_page(page_bytes, i as u64, lockbox_id, &content_key, mode)
            {
                pages.push(inspection);
                i += physical_page_size_from_page_slice(page_bytes)
                    .unwrap_or(DEFAULT_METADATA_PAGE_BYTES);
                continue;
            }
            if let Ok(decoded) = decode_page_with_format(page_bytes, lockbox_id, key, mode) {
                let page_size = physical_page_size_from_page_slice(page_bytes)
                    .unwrap_or_else(|_| page_size_for_objects(&decoded.objects));
                let Ok(encrypted_body_len) = read_u32_le(&page_bytes[44..48]) else {
                    i += DEFAULT_METADATA_PAGE_BYTES;
                    continue;
                };
                let objects = decoded
                    .objects
                    .iter()
                    .map(|object| PageObjectInspection {
                        id: object.id,
                        kind: page_object_kind_name(object.kind),
                        payload_len: object.payload_len(),
                    })
                    .collect::<Vec<_>>();
                pages.push(PageInspection {
                    offset: i as u64,
                    page_id: decoded.page_id,
                    sequence: decoded.sequence,
                    page_size: page_size as u32,
                    encrypted_body_len,
                    unused_bytes: page_size
                        .saturating_sub(PAGE_HEADER_LEN)
                        .saturating_sub(encrypted_body_len as usize)
                        as u32,
                    object_count: objects.len(),
                    objects,
                });
                i += page_size;
            } else {
                i += 1;
            }
        } else {
            i += 1;
        }
    }
    content_key.zeroize();
    pages
}

fn inspect_secure_variable_page(
    page_bytes: &[u8],
    offset: u64,
    lockbox_id: LockboxId,
    content_key: &[u8; 32],
    mode: crate::creation_options::FormatMode,
) -> Option<PageInspection> {
    let (page_id, sequence, stored_body_len) = public_page_header_metadata(page_bytes)?;
    let object = decode_secure_variable_page_inspection(page_bytes, lockbox_id, content_key, mode)?;
    let page_size = physical_page_size_from_page_slice(page_bytes).ok()?;
    Some(PageInspection {
        offset,
        page_id,
        sequence,
        page_size: page_size as u32,
        encrypted_body_len: stored_body_len as u32,
        unused_bytes: page_size
            .saturating_sub(PAGE_HEADER_LEN)
            .saturating_sub(stored_body_len) as u32,
        object_count: 1,
        objects: vec![object],
    })
}

fn decode_secure_variable_page_inspection(
    page_bytes: &[u8],
    lockbox_id: LockboxId,
    content_key: &[u8; 32],
    mode: crate::creation_options::FormatMode,
) -> Option<PageObjectInspection> {
    let mut page = SecureVec::try_from_slice(page_bytes).ok()?;
    let decoded =
        decode_single_object_page_secure_with_format(&mut page, lockbox_id, content_key, mode)
            .ok()?;
    let object = decoded.objects.first()?;
    if !matches!(
        object.kind,
        PageObjectKind::VariableLeaf
            | PageObjectKind::VariableInternal
            | PageObjectKind::FormLeaf
            | PageObjectKind::FormInternal
    ) {
        return None;
    }
    Some(PageObjectInspection {
        id: object.id,
        kind: page_object_kind_name(object.kind),
        payload_len: object.payload_len(),
    })
}

fn public_page_header_metadata(page: &[u8]) -> Option<(u64, u64, usize)> {
    if page.len() < PAGE_HEADER_LEN || &page[0..8] != PAGE_MAGIC {
        return None;
    }
    Some((
        u64::from_le_bytes(page[16..24].try_into().ok()?),
        u64::from_le_bytes(page[24..32].try_into().ok()?),
        u32::from_le_bytes(page[44..48].try_into().ok()?) as usize,
    ))
}

pub(crate) fn page_decode_slice(bytes: &[u8], offset: usize) -> Option<&[u8]> {
    if offset + PAGE_HEADER_LEN > bytes.len() || bytes.get(offset..offset + 8)? != PAGE_MAGIC {
        return None;
    }
    let header_len =
        u32::from_le_bytes(bytes.get(offset + 12..offset + 16)?.try_into().ok()?) as usize;
    let encrypted_len =
        u32::from_le_bytes(bytes.get(offset + 44..offset + 48)?.try_into().ok()?) as usize;
    let len = header_len.checked_add(encrypted_len)?;
    bytes.get(offset..offset.checked_add(len)?)
}

fn page_objects_are_clear_text(objects: &[PageObject]) -> Result<bool> {
    let clear_text = objects
        .iter()
        .any(|object| object.kind.is_clear_text_page_object());
    if clear_text
        && objects
            .iter()
            .any(|object| !object.kind.is_clear_text_page_object())
    {
        return Err(Error::CorruptRecord);
    }
    Ok(clear_text)
}

#[cfg(test)]
fn record_kind_from_object_kind(kind: PageObjectKind) -> Option<RecordKind> {
    match kind {
        PageObjectKind::PackedFileData | PageObjectKind::FileData => Some(RecordKind::FilePage),
        PageObjectKind::Symlink => Some(RecordKind::Symlink),
        PageObjectKind::VariableSet => Some(RecordKind::Variable),
        PageObjectKind::VariableDelete => Some(RecordKind::VariableDelete),
        PageObjectKind::Delete => Some(RecordKind::Delete),
        PageObjectKind::TocLeaf | PageObjectKind::TocInternal => Some(RecordKind::TocNode),
        PageObjectKind::CommitRoot => Some(RecordKind::CommitRoot),
        PageObjectKind::CommitAuth => Some(RecordKind::CommitAuth),
        PageObjectKind::FreeIndexLeaf | PageObjectKind::FreeIndexInternal => {
            Some(RecordKind::FreeIndex)
        }
        PageObjectKind::KeyDirectory
        | PageObjectKind::VariableLeaf
        | PageObjectKind::VariableInternal
        | PageObjectKind::FormLeaf
        | PageObjectKind::FormInternal
        | PageObjectKind::RedactionManifest => None,
    }
}

fn page_object_kind_name(kind: PageObjectKind) -> &'static str {
    match kind {
        PageObjectKind::CommitRoot => "commit-root",
        PageObjectKind::CommitAuth => "commit-auth",
        PageObjectKind::TocLeaf => "toc-leaf",
        PageObjectKind::TocInternal => "toc-internal",
        PageObjectKind::FileData => "file-data",
        PageObjectKind::PackedFileData => "packed-file-data",
        PageObjectKind::Symlink => "symlink",
        PageObjectKind::VariableSet => "variable-set",
        PageObjectKind::VariableDelete => "variable-delete",
        PageObjectKind::KeyDirectory => "key-directory",
        PageObjectKind::FreeIndexLeaf => "free-index-leaf",
        PageObjectKind::FreeIndexInternal => "free-index-internal",
        PageObjectKind::Delete => "delete",
        PageObjectKind::VariableLeaf => "variable-leaf",
        PageObjectKind::VariableInternal => "variable-internal",
        PageObjectKind::FormLeaf => "form-leaf",
        PageObjectKind::FormInternal => "form-internal",
        PageObjectKind::RedactionManifest => "redaction-manifest",
    }
}

fn encode_page_body_plaintext(object_stream: &[u8], compress: bool) -> Vec<u8> {
    let stored = if compress {
        encode_page_body(object_stream)
    } else {
        object_stream.to_vec()
    };
    let mut body = Vec::with_capacity(16 + stored.len());
    body.push(PAGE_BODY_VERSION);
    body.push(if compress {
        COMPRESSION_NORMAL
    } else {
        COMPRESSION_NONE
    });
    body.push(0);
    body.push(0);
    body.extend_from_slice(&(object_stream.len() as u64).to_le_bytes());
    body.extend_from_slice(&0u32.to_le_bytes());
    body.extend_from_slice(&stored);
    body
}

fn decode_page_body_plaintext(body: &[u8]) -> Result<Cow<'_, [u8]>> {
    if body.len() < 16 {
        return Err(Error::CorruptRecord);
    }
    if body[0] != PAGE_BODY_VERSION {
        return Err(Error::CorruptRecord);
    }
    let expected_len = read_u64_le(&body[4..12])?;
    let decoded = match body[1] {
        COMPRESSION_NONE => Cow::Borrowed(&body[16..]),
        COMPRESSION_NORMAL => decode_page_body_view(&body[16..])?,
        _ => return Err(Error::CorruptRecord),
    };
    if decoded.len() as u64 != expected_len {
        return Err(Error::CorruptRecord);
    }
    Ok(decoded)
}

fn encode_object_stream(objects: &[PageObject]) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    out.extend_from_slice(&(objects.len() as u32).to_le_bytes());
    for object in objects {
        out.push(object.kind as u8);
        out.push(1);
        out.extend_from_slice(&0u16.to_le_bytes());
        out.extend_from_slice(&object.id.to_le_bytes());
        out.extend_from_slice(&(object.payload_len() as u64).to_le_bytes());
        object.with_payload(|payload| out.extend_from_slice(payload))?;
    }
    Ok(out)
}

fn decode_object_stream(bytes: &[u8]) -> Result<Vec<PageObject>> {
    if bytes.len() < 4 {
        return Err(Error::CorruptRecord);
    }
    let count = read_u32_le(&bytes[0..4])? as usize;
    if count > (bytes.len() - 4) / 20 {
        return Err(Error::CorruptRecord);
    }
    let mut offset = 4usize;
    let mut objects = Vec::with_capacity(count);
    for _ in 0..count {
        if offset + 20 > bytes.len() {
            return Err(Error::CorruptRecord);
        }
        let kind = PageObjectKind::from_u8(bytes[offset])?;
        let version = bytes[offset + 1];
        let flags = read_u16_le(&bytes[offset + 2..offset + 4])?;
        if version != 1 || flags != 0 {
            return Err(Error::CorruptRecord);
        }
        let id = read_u64_le(&bytes[offset + 4..offset + 12])?;
        let payload_len = read_u64_le(&bytes[offset + 12..offset + 20])? as usize;
        offset += 20;
        if offset + payload_len > bytes.len() {
            return Err(Error::CorruptRecord);
        }
        objects.push(PageObject::new(
            kind,
            id,
            bytes[offset..offset + payload_len].to_vec(),
        ));
        offset += payload_len;
    }
    if offset != bytes.len() {
        return Err(Error::CorruptRecord);
    }
    Ok(objects)
}

fn page_aad(
    lockbox_id: LockboxId,
    page_id: u64,
    sequence: u64,
    flags: u16,
    encrypted_len: u32,
    physical_len: u64,
) -> Vec<u8> {
    let mut aad = Vec::with_capacity(8 + 2 + 16 + 8 + 8 + 2 + 4);
    aad.extend_from_slice(b"LBX1PAGE");
    aad.extend_from_slice(&PAGE_VERSION.to_le_bytes());
    aad.extend_from_slice(lockbox_id.as_bytes());
    aad.extend_from_slice(&page_id.to_le_bytes());
    aad.extend_from_slice(&sequence.to_le_bytes());
    aad.extend_from_slice(&flags.to_le_bytes());
    aad.extend_from_slice(&encrypted_len.to_le_bytes());
    aad.extend_from_slice(&physical_len.to_le_bytes());
    aad
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_control_extent_matches_writer_across_modes_and_boundaries() {
        use crate::{Compression, EncryptionMode, LockboxFormatOptions, SigningMode, SizePadding};
        let archive = LockboxId::from_bytes([31; 16]);
        let mut modes = vec![crate::creation_options::FormatMode::default()];
        for encryption in [EncryptionMode::None, EncryptionMode::ChaCha20Poly1305] {
            for size_padding in [SizePadding::Default, SizePadding::None] {
                for compression in [Compression::None, Compression::default()] {
                    modes.push(crate::creation_options::FormatMode::new(LockboxFormatOptions {
                        encryption, signing: SigningMode::Owner, compression, size_padding,
                    }));
                }
            }
        }
        for mode in modes {
            for kind in [PageObjectKind::CommitRoot, PageObjectKind::CommitAuth, PageObjectKind::KeyDirectory] {
                for payload_len in [0, 1, 850, 851, 856, 872, 1024, 4097, 8192] {
                    let objects = vec![PageObject::new(kind, 7, vec![37; payload_len])];
                    let actual = page_size_for_encoded_objects_with_format(&objects, mode).unwrap();
                    assert_eq!(canonical_control_page_len(payload_len, kind, mode).unwrap(), actual as u64);
                    let encoded = encode_page_with_format(actual, archive, 512, 7, b"controls", &objects, mode).unwrap();
                    assert_eq!(encoded.len(), actual);
                    assert!(decode_page_with_format(&encoded, archive, b"controls", mode).is_ok());
                    if !mode.unpadded() {
                        let noncanonical = encode_page_with_format(actual + 1024, archive, 512, 7, b"controls", &objects, mode).unwrap();
                        assert!(decode_page_with_format(&noncanonical, archive, b"controls", mode).is_err());
                    }
                }
            }
        }
    }

    #[test]
    fn canonical_control_decoder_requires_one_object_and_matching_identity() {
        let archive = LockboxId::from_bytes([41; 16]);
        for objects in [
            vec![PageObject::new(PageObjectKind::CommitRoot, 8, vec![1; 32])],
            vec![PageObject::new(PageObjectKind::CommitRoot, 7, vec![1; 32]), PageObject::new(PageObjectKind::CommitAuth, 7, vec![2; 32])],
        ] {
            let encoded = encode_page(1024, archive, 512, 7, b"controls", &objects).unwrap();
            assert!(decode_page(&encoded, archive, b"controls").is_err());
        }
    }

    #[test]
    fn arithmetic_page_sizes_match_serialized_bodies_in_every_explicit_mode() {
        use crate::creation_options::FormatMode;
        use crate::{
            Compression, EncryptionMode, LockboxFormatOptions, SigningMode, SizePadding, ZstdLevel,
        };
        for kind in [
            PageObjectKind::FileData,
            PageObjectKind::PackedFileData,
            PageObjectKind::VariableLeaf,
            PageObjectKind::FormInternal,
            PageObjectKind::TocLeaf,
            PageObjectKind::KeyDirectory,
        ] {
            for len in [0, 1, 855, 856, 857, 871, 872, 873, 4097] {
                let objects = [PageObject::new(kind, 19, vec![37; len])];
                for encryption in [EncryptionMode::None, EncryptionMode::ChaCha20Poly1305] {
                    for signing in [SigningMode::None, SigningMode::Owner] {
                        for size_padding in [SizePadding::Default, SizePadding::None] {
                            for compression in [
                                Compression::None,
                                Compression::default(),
                                Compression::Zstd {
                                    level: ZstdLevel::new(22).unwrap(),
                                },
                            ] {
                                let mode = FormatMode::new(LockboxFormatOptions {
                                    encryption,
                                    signing,
                                    size_padding,
                                    compression,
                                });
                                let body = encode_objects_body(&objects, mode).unwrap();
                                // Bind the codec decision as well as its length: file frames
                                // and private tree bodies must not acquire page compression.
                                let eligible = matches!(
                                    kind,
                                    PageObjectKind::TocLeaf
                                ) && compression != Compression::None;
                                assert_eq!(
                                    body[1],
                                    if eligible {
                                        COMPRESSION_NORMAL
                                    } else {
                                        COMPRESSION_NONE
                                    }
                                );
                                let stored = PAGE_HEADER_LEN
                                    + body.len()
                                    + if mode.plaintext() || kind == PageObjectKind::KeyDirectory {
                                        32
                                    } else {
                                        16
                                    };
                                let expected = if mode.unpadded() {
                                    stored
                                } else {
                                    page_size_for_stored_len(
                                        stored,
                                        max_page_size_for_objects(&objects),
                                    )
                                    .unwrap()
                                };
                                assert_eq!(
                                    page_size_for_encoded_objects_with_format(&objects, mode)
                                        .unwrap(),
                                    expected,
                                    "{kind:?}, {len}, {mode:?}"
                                );
                            }
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn arithmetic_sizing_handles_shared_secure_payloads_and_physical_limits() {
        use crate::creation_options::FormatMode;
        use crate::{Compression, EncryptionMode, LockboxFormatOptions, SigningMode, SizePadding};
        for encryption in [EncryptionMode::None, EncryptionMode::ChaCha20Poly1305] {
            for size_padding in [SizePadding::Default, SizePadding::None] {
                let mode = FormatMode::new(LockboxFormatOptions {
                    encryption,
                    signing: SigningMode::None,
                    size_padding,
                    compression: Compression::default(),
                });
                let objects = [
                    PageObject::new(PageObjectKind::FileData, 1, vec![3; 4 * 1024 * 1024]),
                    PageObject::new_secure(
                        PageObjectKind::PackedFileData,
                        2,
                        SecureVec::try_from_slice(&[5; 17]).unwrap(),
                    ),
                ];
                let body = encode_objects_body(&objects, mode).unwrap();
                let stored = PAGE_HEADER_LEN + body.len() + if mode.plaintext() { 32 } else { 16 };
                let expected = if mode.unpadded() {
                    stored
                } else {
                    page_size_for_stored_len(stored, DEFAULT_DATA_PAGE_BYTES).unwrap()
                };
                assert_eq!(
                    page_size_for_encoded_objects_with_format(&objects, mode).unwrap(),
                    expected
                );
                let oversized = [PageObject::new(
                    PageObjectKind::FileData,
                    1,
                    vec![0; DEFAULT_DATA_PAGE_BYTES],
                )];
                assert!(matches!(
                    page_size_for_encoded_objects_with_format(&oversized, mode),
                    Err(Error::SecurityLimitExceeded(_))
                ));
            }
        }
    }

    #[test]
    fn physical_length_recovery_preserves_checksum_and_rejects_other_damage() {
        use crate::creation_options::FormatMode;
        use crate::{Compression, EncryptionMode, LockboxFormatOptions, SigningMode, SizePadding};
        let id = LockboxId::new_random().unwrap();
        let objects = [PageObject::new(PageObjectKind::CommitRoot, 7, vec![7; 88])];
        for encryption in [EncryptionMode::None, EncryptionMode::ChaCha20Poly1305] {
            for size_padding in [SizePadding::Default, SizePadding::None] {
                let mode = FormatMode::new(LockboxFormatOptions {
                    encryption,
                    size_padding,
                    signing: SigningMode::Owner,
                    compression: Compression::None,
                });
                let size = canonical_control_page_len(
                    objects[0].payload_len(), PageObjectKind::CommitRoot, mode,
                ).unwrap() as usize;
                let page =
                    encode_page_with_format(size, id, 3, 7, b"secret", &objects, mode).unwrap();
                assert!(recover_physical_length_header(&page).is_none());
                for field_byte in 48..56 {
                    let mut damaged = page.clone();
                    damaged[field_byte] ^= 0x55;
                    let header = recover_physical_length_header(&damaged).unwrap();
                    assert_eq!(header, page[..PAGE_HEADER_LEN]);
                    assert!(recover_physical_length_header(&damaged[..size - 1]).is_none());
                    damaged[PAGE_CHECKSUM_START] ^= 1;
                    assert!(recover_physical_length_header(&damaged).is_none());
                    damaged[PAGE_CHECKSUM_START] ^= 1;
                    damaged[24] ^= 1;
                    assert!(recover_physical_length_header(&damaged).is_none());
                    damaged[24] ^= 1;
                    damaged[..PAGE_HEADER_LEN].copy_from_slice(&header);
                    assert_eq!(
                        decode_page_with_format(&damaged, id, b"secret", mode)
                            .unwrap()
                            .objects,
                        objects
                    );
                    damaged[PAGE_HEADER_LEN + 8] ^= 1;
                    assert!(decode_page_with_format(&damaged, id, b"secret", mode).is_err());
                }
            }
        }
    }

    #[test]
    fn page_round_trips_objects_and_has_fixed_size() {
        let lockbox_id = LockboxId::new_random().unwrap();
        let key = b"secret";
        let objects = vec![
            PageObject::new(PageObjectKind::TocLeaf, 10, b"toc".to_vec()),
            PageObject::new(PageObjectKind::PackedFileData, 11, b"file".to_vec()),
        ];

        let page = encode_page(128 * 1024, lockbox_id, 3, 7, key, &objects).unwrap();
        assert_eq!(page.len(), 128 * 1024);
        assert_eq!(&page[0..8], PAGE_MAGIC);

        let decoded = decode_page(&page, lockbox_id, key).unwrap();
        assert_eq!(decoded.page_id, 3);
        assert_eq!(decoded.sequence, 7);
        assert_eq!(decoded.objects, objects);
    }

    #[test]
    fn page_rejects_tampering() {
        let lockbox_id = LockboxId::new_random().unwrap();
        let key = b"secret";
        let objects = vec![PageObject::new(
            PageObjectKind::TocLeaf,
            10,
            b"toc".to_vec(),
        )];

        let mut page = encode_page(128 * 1024, lockbox_id, 3, 7, key, &objects).unwrap();
        page[PAGE_HEADER_LEN + 8] ^= 0x01;

        assert!(decode_page(&page, lockbox_id, key).is_err());
    }

    #[test]
    fn page_rejects_public_header_checksum_tampering() {
        let lockbox_id = LockboxId::new_random().unwrap();
        let key = b"secret";
        let objects = vec![PageObject::new(
            PageObjectKind::TocLeaf,
            10,
            b"toc".to_vec(),
        )];

        let mut page = encode_page(128 * 1024, lockbox_id, 3, 7, key, &objects).unwrap();
        page[16] ^= 0x01;

        assert!(decode_page(&page, lockbox_id, key).is_err());
    }

    #[test]
    fn clear_text_page_uses_page_checksum_for_body_integrity() {
        let lockbox_id = LockboxId::new_random().unwrap();
        let objects = vec![PageObject::new(
            PageObjectKind::KeyDirectory,
            7,
            b"keys".to_vec(),
        )];

        let size = canonical_control_page_len(
            objects[0].payload_len(), PageObjectKind::KeyDirectory,
            crate::creation_options::FormatMode::default(),
        ).unwrap() as usize;
        let mut page = encode_page(size, lockbox_id, 3, 7, b"", &objects).unwrap();
        assert_eq!(
            u16::from_le_bytes(page[10..12].try_into().unwrap()),
            PAGE_FLAG_CLEAR_TEXT
        );
        let decoded = decode_page(&page, LockboxId::from_bytes([0; 16]), b"").unwrap();
        assert_eq!(decoded.objects, objects);

        page[PAGE_HEADER_LEN + 40] ^= 0x01;
        assert!(decode_page(&page, LockboxId::from_bytes([0; 16]), b"").is_err());
    }

    #[test]
    fn secure_payload_can_be_read_only_through_scoped_access() {
        let payload = SecureVec::try_from_slice(b"secret").unwrap();
        let object = PageObject::new_secure(PageObjectKind::VariableLeaf, 10, payload);

        assert!(object.with_payload(|payload| payload == b"secret").unwrap());
    }
}
