use super::context::{
    cli_error, default_vault, open_default_vault_with_password, open_existing_read_only,
    remember_default_vault_password_with_warning, vault_password_without_open, Access, CliResult,
};
use crate::secret_prompt::prompt_secret;
use clap::ArgMatches;
use revault_lockbox_api::{
    probe_lockbox_format_version, OwnerSigningKeyPair, SecretString, SecretVec,
    LOCKBOX_FORMAT_VERSION,
};
use revault_migration::{
    export_archive, export_vault, import_archive, import_vault, upgrade_archive_artifact,
    upgrade_vault_artifact, verify_archive_artifact, verify_vault_artifact, ArtifactKind,
    MigrationJournal, MigrationPassphrase, MigrationStage,
};
use revault_vault_api::{default_vault_dir, VaultDirectory, CURRENT_VAULT_STRUCTURE_VERSION};
use sha2::{Digest, Sha256};
use std::env;
use std::fs::{self, File};
use std::io::{BufRead, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

pub(crate) fn run_matches(matches: &ArgMatches, access: &Access) -> CliResult<()> {
    match matches.subcommand() {
        Some(("vault", sub)) => vault_matches(sub),
        Some(("lockbox", sub)) => lockbox_matches(sub, access),
        Some((other, _)) => Err(cli_error(format!("unknown migration command: {other}"))),
        None => Err(cli_error("migrate requires vault or lockbox")),
    }
}

fn vault_matches(matches: &ArgMatches) -> CliResult<()> {
    match matches.subcommand() {
        Some(("export", sub)) => vault_export(sub),
        Some(("upgrade", sub)) => vault_upgrade(sub),
        Some(("import", sub)) => vault_import(sub),
        Some(("verify", sub)) => vault_verify(sub),
        Some((other, _)) => Err(cli_error(format!(
            "unknown vault migration command: {other}"
        ))),
        None => migrate_vault_direct(matches),
    }
}

fn lockbox_matches(matches: &ArgMatches, access: &Access) -> CliResult<()> {
    match matches.subcommand() {
        Some(("export", sub)) => archive_export(sub, access),
        Some(("upgrade", sub)) => archive_upgrade(sub),
        Some(("import", sub)) => archive_import(sub),
        Some(("verify", sub)) => archive_verify(sub),
        Some((other, _)) => Err(cli_error(format!(
            "unknown lockbox migration command: {other}"
        ))),
        None => migrate_archive_direct(matches, access),
    }
}

fn vault_export(matches: &ArgMatches) -> CliResult<()> {
    let output = required_path(matches, "output")?;
    let stdin_vault = matches.get_flag("vault-password-stdin");
    let stdin_artifact = matches.get_flag("migration-password-stdin");
    let mut stdin_secrets =
        read_secret_lines_stdin(usize::from(stdin_vault) + usize::from(stdin_artifact))?
            .into_iter();
    let vault_password = stdin_vault.then(|| stdin_secrets.next().expect("vault stdin secret"));
    let artifact_password = if stdin_artifact {
        stdin_secrets.next().expect("migration stdin secret")
    } else {
        migration_password()?
    };
    let vault = match vault_password {
        Some(password) => super::context::open_default_vault_with_password(&password)?,
        None => default_vault()?,
    };
    let operation_id = random_id()?;
    let count = export_vault(&vault, &output, &artifact_password, operation_id)?;
    println!(
        "Exported {count} vault migration records to {}",
        output.display()
    );
    Ok(())
}

fn vault_upgrade(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let output = required_path(matches, "output")?;
    let password = migration_password()?;
    let count = upgrade_vault_artifact(&input, &output, &password)?;
    println!(
        "Upgraded {count} vault migration records to {}",
        output.display()
    );
    Ok(())
}

fn vault_import(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let output = required_path(matches, "output")?;
    let artifact_password = migration_password()?;
    let vault_password = vault_password_without_open()?;
    let count = import_vault(&input, &artifact_password, &output, &vault_password)?;
    println!(
        "Imported {count} vault migration records into {}",
        output.display()
    );
    Ok(())
}

fn vault_verify(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let password = migration_password()?;
    let count = verify_vault_artifact(&input, &password)?;
    println!("Vault migration artifact is valid ({count} records).");
    Ok(())
}

fn archive_source(matches: &ArgMatches) -> CliResult<String> {
    match (
        super::command_lockbox(),
        matches.get_one::<String>("lockbox"),
    ) {
        (Some(_), Some(_)) => Err(cli_error(
            "pass the lockbox either before doctor or as the migration argument, not both",
        )),
        (Some(path), None) => Ok(path),
        (None, Some(value)) => {
            let (path, identity) = super::aliases::resolve(value)?;
            super::COMMAND_LOCKBOX_ID.with(|id| *id.borrow_mut() = identity);
            super::set_command_lockbox(Some(path.clone()));
            Ok(path)
        }
        (None, None) => Err(cli_error(
            "lockbox migration requires a lockbox path or a@alias",
        )),
    }
}

fn archive_export(matches: &ArgMatches, access: &Access) -> CliResult<()> {
    let source = archive_source(matches)?;
    let output = required_path(matches, "output")?;
    let artifact_password = if matches.get_flag("migration-password-stdin") {
        read_secret_lines_stdin(1)?.remove(0)
    } else {
        migration_password()?
    };
    let lockbox = open_existing_read_only(&source, access)?;
    let operation_id = random_id()?;
    let count = export_archive(&lockbox, &output, &artifact_password, operation_id)?;
    println!(
        "Exported {count} lockbox migration records to {}",
        output.display()
    );
    Ok(())
}

fn archive_import(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let output = PathBuf::from(super::aliases::resolve(&required_string(matches, "output")?)?.0);
    let password = migration_password()?;
    let signing = default_signing_key()?;
    let count = import_archive(&input, &password, &output, &signing)?;
    println!(
        "Imported {count} lockbox migration records into {}",
        output.display()
    );
    Ok(())
}

fn archive_upgrade(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let output = required_path(matches, "output")?;
    let password = migration_password()?;
    let count = upgrade_archive_artifact(&input, &output, &password)?;
    println!(
        "Upgraded {count} lockbox migration frames to {}",
        output.display()
    );
    Ok(())
}

fn archive_verify(matches: &ArgMatches) -> CliResult<()> {
    let input = required_path(matches, "artifact")?;
    let password = migration_password()?;
    let count = verify_archive_artifact(&input, &password)?;
    println!("Lockbox migration artifact is valid ({count} frames).");
    Ok(())
}

fn migrate_vault_direct(matches: &ArgMatches) -> CliResult<()> {
    let replace = matches.get_flag("replace");
    let requested_output = matches.get_one::<String>("output").map(PathBuf::from);
    require_destination(replace, requested_output.as_deref(), "vault")?;
    let source = default_vault_dir()?;
    let source_password = vault_password_without_open()?;
    if !source.exists()
        && recover_interrupted_replacement(&source, ArtifactKind::Vault, &source_password)?
    {
        remember_default_vault_password_with_warning(
            &source_password,
            "the interrupted vault replacement completed successfully",
        );
        println!("Completed the interrupted vault replacement.");
        return Ok(());
    }
    let source_container = probe_archive_path(&source.join("local-vault.lbox"))?;
    let experimental_export = source_container == 4 && matches.contains_id("exporter");
    // Only the explicitly selected frozen exporter may interpret an older
    // experimental v4 graph. The authenticated artifact validates structure 3.
    let source_version = if experimental_export { CURRENT_VAULT_STRUCTURE_VERSION }
        else { probe_vault_source_version(&source, &source_password)? };
    if replace && !experimental_export
        && source_version == CURRENT_VAULT_STRUCTURE_VERSION
        && source_container == u32::from(LOCKBOX_FORMAT_VERSION)
    {
        remember_default_vault_password_with_warning(
            &source_password,
            "the vault passphrase was verified successfully",
        );
        println!(
            "Vault already uses format version {CURRENT_VAULT_STRUCTURE_VERSION}. No migration needed."
        );
        return Ok(());
    }
    let fingerprint = fingerprint_path(&source.join("local-vault.lbox"))?;
    let operation_id = deterministic_operation_id(
        ArtifactKind::Vault,
        &source,
        requested_output.as_deref(),
        fingerprint,
    );
    let output =
        requested_output.unwrap_or_else(|| temporary_vault_destination(&source, operation_id));
    let work_dir = migration_work_dir(&source, operation_id)?;
    let artifact = work_dir.join("vault.source.migration");
    let upgraded = work_dir.join("vault.latest.migration");
    let journal_path = work_dir.join("vault.migration-state");
    fs::create_dir_all(&work_dir)?;
    reject_unowned_destination(&journal_path, &output)?;
    let initial_journal = new_journal(
        operation_id,
        ArtifactKind::Vault,
        source.clone(),
        source_version,
        CURRENT_VAULT_STRUCTURE_VERSION,
        fingerprint,
        vec![artifact.clone(), upgraded.clone(), output.clone()],
    )?;
    let mut journal = load_or_create_journal(&journal_path, &source_password, initial_journal)?;
    validate_resume(
        &journal,
        ArtifactKind::Vault,
        &source,
        source_version,
        fingerprint,
        &output,
    )?;
    ensure_artifact_key(&mut journal)?;
    let migration_key = journal.artifact_key.try_clone()?;

    if journal.current_stage == MigrationStage::Export {
        let complete =
            artifact.exists() && verify_vault_artifact(&artifact, &migration_key).is_ok();
        if !complete {
            remove_partial(&artifact)?;
            if !experimental_export && source_version == CURRENT_VAULT_STRUCTURE_VERSION
                && source_container == u32::from(LOCKBOX_FORMAT_VERSION)
            {
                let vault = VaultDirectory::open_or_create(&source, &source_password)?;
                export_vault(&vault, &artifact, &migration_key, operation_id)?;
            } else {
                let exporter = resolve_exporter(
                    ArtifactKind::Vault,
                    if experimental_export { 4 } else { source_version },
                    matches.get_one::<String>("exporter").map(PathBuf::from),
                )?;
                let artifact_password = SecretString::from_secure_vec(migration_key.try_clone()?);
                run_historical_vault_exporter(
                    &exporter,
                    &source,
                    &artifact,
                    &source_password,
                    &artifact_password,
                )?;
                journal.exporter_version = Some(exporter.display().to_string());
            }
        }
        journal.current_stage = MigrationStage::Upgrade;
        save_journal(&mut journal, &journal_path, &source_password)?;
    }
    if journal.current_stage == MigrationStage::Upgrade {
        let complete =
            upgraded.exists() && verify_vault_artifact(&upgraded, &migration_key).is_ok();
        if !complete {
            remove_partial(&upgraded)?;
            upgrade_vault_artifact(&artifact, &upgraded, &migration_key)?;
        }
        journal.current_stage = MigrationStage::Import;
        save_journal(&mut journal, &journal_path, &source_password)?;
    }
    if journal.current_stage == MigrationStage::Import {
        let complete = output.exists()
            && VaultDirectory::open_or_create(&output, &source_password)
                .and_then(|vault| vault.structure_version())
                .is_ok_and(|version| version == CURRENT_VAULT_STRUCTURE_VERSION);
        if !complete {
            remove_partial(&output)?;
            import_vault(&upgraded, &migration_key, &output, &source_password)?;
        }
        journal.current_stage = MigrationStage::Validate;
        save_journal(&mut journal, &journal_path, &source_password)?;
    }
    if journal.current_stage == MigrationStage::Validate {
        let imported = VaultDirectory::open_or_create(&output, &source_password)?;
        if imported.structure_version()? != CURRENT_VAULT_STRUCTURE_VERSION {
            return Err(cli_error("migrated vault validation failed"));
        }
        drop(imported);
        journal.current_stage = if replace {
            MigrationStage::Replace
        } else {
            MigrationStage::Complete
        };
        save_journal(&mut journal, &journal_path, &source_password)?;
    }
    if replace {
        if journal.current_stage != MigrationStage::Replace {
            return Err(cli_error(
                "vault migration journal has an invalid replacement stage",
            ));
        }
        let backup =
            versioned_backup_path(&source, source_version, CURRENT_VAULT_STRUCTURE_VERSION);
        if backup.exists() {
            return Err(cli_error(format!(
                "migration backup already exists: {}",
                backup.display()
            )));
        }
        fs::rename(&source, &backup)?;
        if let Err(err) = fs::rename(&output, &source) {
            let _ = fs::rename(&backup, &source);
            return Err(err.into());
        }
        println!("Vault migrated to format version {CURRENT_VAULT_STRUCTURE_VERSION}.");
        println!("Previous vault retained at {}", backup.display());
        remember_default_vault_password_with_warning(
            &source_password,
            "the vault migrated successfully",
        );
    } else {
        println!("Vault migrated to {}", output.display());
    }
    cleanup_work_dir(&work_dir);
    Ok(())
}

fn migrate_archive_direct(matches: &ArgMatches, access: &Access) -> CliResult<()> {
    let source = PathBuf::from(archive_source(matches)?);
    let replace = matches.get_flag("replace");
    let requested_output = matches
        .get_one::<String>("output")
        .map(|value| super::aliases::resolve(value).map(|(path, _)| PathBuf::from(path)))
        .transpose()?;
    require_destination(replace, requested_output.as_deref(), "lockbox")?;
    let vault_root = default_vault_dir()?;
    if !vault_root.join("local-vault.lbox").exists() {
        return Err(cli_error(
            "lockbox migration requires a current vault; run `lockbox vault init` first",
        ));
    }
    let vault_password = vault_password_without_open()?;
    let vault_version = probe_vault_source_version(&vault_root, &vault_password)?;
    let vault_container = probe_archive_path(&vault_root.join("local-vault.lbox"))?;
    if vault_version < CURRENT_VAULT_STRUCTURE_VERSION
        || vault_container < u32::from(LOCKBOX_FORMAT_VERSION)
    {
        return Err(cli_error(format!(
            "lockbox migration requires the vault to be migrated first; vault format version {vault_version} is older than the current version {CURRENT_VAULT_STRUCTURE_VERSION}. Run `lockbox doctor migrate vault --replace` or migrate it with `--output <directory>`"
        )));
    }
    if vault_version > CURRENT_VAULT_STRUCTURE_VERSION {
        return Err(cli_error(format!(
            "lockbox migration cannot run with a newer vault format version {vault_version}; this build supports version {CURRENT_VAULT_STRUCTURE_VERSION}. Install a newer reVault release"
        )));
    }
    if recover_interrupted_replacement(&source, ArtifactKind::Archive, &vault_password)? {
        println!("Completed the interrupted lockbox replacement.");
        return Ok(());
    }
    let source_version = probe_archive_path(&source)?;
    if replace && source_version == u32::from(LOCKBOX_FORMAT_VERSION)
        && !matches.contains_id("exporter") {
        // A format number alone does not identify the current authenticated graph.
        let _verified = open_existing_read_only(&source.to_string_lossy(), access)?;
        println!(
            "Lockbox already uses format version {LOCKBOX_FORMAT_VERSION}. No migration needed."
        );
        return Ok(());
    }
    let fingerprint = fingerprint_path(&source)?;
    let operation_id = deterministic_operation_id(
        ArtifactKind::Archive,
        &source,
        requested_output.as_deref(),
        fingerprint,
    );
    let output =
        requested_output.unwrap_or_else(|| temporary_archive_destination(&source, operation_id));
    let work_dir = migration_work_dir(&source, operation_id)?;
    fs::create_dir_all(&work_dir)?;
    let artifact = work_dir.join("archive.migration");
    let upgraded = work_dir.join("archive.latest.migration");
    let journal_path = work_dir.join("archive.migration-state");
    reject_unowned_destination(&journal_path, &output)?;
    let initial_journal = new_journal(
        operation_id,
        ArtifactKind::Archive,
        source.clone(),
        source_version,
        u32::from(LOCKBOX_FORMAT_VERSION),
        fingerprint,
        vec![artifact.clone(), upgraded.clone(), output.clone()],
    )?;
    let mut journal = load_or_create_journal(&journal_path, &vault_password, initial_journal)?;
    validate_resume(
        &journal,
        ArtifactKind::Archive,
        &source,
        source_version,
        fingerprint,
        &output,
    )?;
    ensure_artifact_key(&mut journal)?;
    let migration_key = journal.artifact_key.try_clone()?;
    if journal.current_stage == MigrationStage::Export {
        let complete =
            artifact.exists() && verify_archive_artifact(&artifact, &migration_key).is_ok();
        if !complete {
            remove_partial(&artifact)?;
            if source_version == u32::from(LOCKBOX_FORMAT_VERSION)
                && !matches.contains_id("exporter") {
                let lockbox = open_existing_read_only(&source.to_string_lossy(), access)?;
                export_archive(&lockbox, &artifact, &migration_key, operation_id)?;
            } else {
                let exporter = resolve_exporter(
                    ArtifactKind::Archive,
                    source_version,
                    matches.get_one::<String>("exporter").map(PathBuf::from),
                )?;
                let artifact_password = SecretString::from_secure_vec(migration_key.try_clone()?);
                let vault = open_default_vault_with_password(&vault_password)?;
                run_historical_archive_exporter(
                    &exporter,
                    &source,
                    &artifact,
                    &vault,
                    &vault_password,
                    &artifact_password,
                )?;
                journal.exporter_version = Some(exporter.display().to_string());
            }
        }
        journal.current_stage = MigrationStage::Upgrade;
        save_journal(&mut journal, &journal_path, &vault_password)?;
    }
    if journal.current_stage == MigrationStage::Upgrade {
        let complete =
            upgraded.exists() && verify_archive_artifact(&upgraded, &migration_key).is_ok();
        if !complete {
            remove_partial(&upgraded)?;
            upgrade_archive_artifact(&artifact, &upgraded, &migration_key)?;
        }
        journal.current_stage = MigrationStage::Import;
        save_journal(&mut journal, &journal_path, &vault_password)?;
    }
    if journal.current_stage == MigrationStage::Import {
        let complete = output.exists()
            && revault_migration::verify_imported_archive(&upgraded, &migration_key, &output)
                .is_ok();
        if !complete {
            remove_partial(&output)?;
            let vault = open_default_vault_with_password(&vault_password)?;
            let signing =
                match revault_migration::archive_owner_fingerprint(&upgraded, &migration_key)? {
                    Some(fingerprint) => {
                        vault.find_owner_signing_key(&fingerprint)?.ok_or_else(|| {
                            cli_error("the established archive owner's signing key is unavailable")
                        })?
                    }
                    None => vault.load_owner_signing_key(VaultDirectory::DEFAULT_KEY_NAME)?,
                };
            import_archive(&upgraded, &migration_key, &output, &signing)?;
        }
        journal.current_stage = MigrationStage::Validate;
        save_journal(&mut journal, &journal_path, &vault_password)?;
    }
    if journal.current_stage == MigrationStage::Validate {
        revault_migration::verify_imported_archive(&upgraded, &migration_key, &output)?;
        println!(
            "Verified all migrated contents and access metadata: {} -> {} bytes.",
            fs::metadata(&source)?.len(),
            fs::metadata(&output)?.len()
        );
        journal.current_stage = if replace {
            MigrationStage::Replace
        } else {
            MigrationStage::Complete
        };
        save_journal(&mut journal, &journal_path, &vault_password)?;
    }
    if replace {
        let backup =
            versioned_backup_path(&source, source_version, u32::from(LOCKBOX_FORMAT_VERSION));
        if backup.exists() {
            return Err(cli_error(format!(
                "migration backup already exists: {}",
                backup.display()
            )));
        }
        fs::rename(&source, &backup)?;
        if let Err(err) = fs::rename(&output, &source) {
            let _ = fs::rename(&backup, &source);
            return Err(err.into());
        }
        println!("Lockbox migrated to format version {LOCKBOX_FORMAT_VERSION}.");
        println!("Previous lockbox retained at {}", backup.display());
    } else {
        println!("Lockbox migrated to {}", output.display());
    }
    cleanup_work_dir(&work_dir);
    Ok(())
}

fn resolve_exporter(
    kind: ArtifactKind,
    source_version: u32,
    explicit: Option<PathBuf>,
) -> CliResult<PathBuf> {
    if source_version == 4 {
        let path = explicit.ok_or_else(|| cli_error(
            "experimental format-4 migration requires an isolated checkpoint exporter; build tools/build_experimental_v4_exporter.dart and pass --exporter <path>"
        ))?;
        validate_exporter_capabilities(&path, experimental_v4_exporter(kind)?)?;
        return Ok(path);
    }
    let release = exporter_release(kind, source_version).ok_or_else(|| {
        cli_error(format!(
            "no crates.io exporter is registered for {kind:?} format version {source_version}"
        ))
    })?;
    if let Some(path) = explicit {
        validate_exporter_capabilities(&path, release)?;
        return Ok(path);
    }
    let binary_name = if cfg!(windows) {
        format!("{}.exe", release.binary)
    } else {
        release.binary.to_string()
    };
    if env::var_os("LOCKBOX_TEST_IGNORE_INSTALLED_EXPORTER").is_none() {
        if let Some(binary) = installed_exporter(&binary_name) {
            validate_exporter_capabilities(&binary, release)?;
            return Ok(binary);
        }
    }
    let root = exporter_cache_root()?.join(format!("{}-{}", release.package, release.version));
    let binary = root.join("bin").join(binary_name);
    if binary.exists() {
        validate_exporter_capabilities(&binary, release)?;
        return Ok(binary);
    }
    eprintln!(
        "Installing historical reVault exporter {} {} from crates.io...",
        release.package, release.version
    );
    let install = Command::new(env::var_os("CARGO").unwrap_or_else(|| "cargo".into()))
        .args([
            "install",
            "--quiet",
            release.package,
            "--version",
            release.version,
            "--bin",
            release.binary,
            "--locked",
            "--root",
        ])
        .arg(&root)
        .stdout(Stdio::null())
        .stderr(Stdio::piped())
        .output()?;
    if !install.status.success() || !binary.exists() {
        let detail = String::from_utf8_lossy(&install.stderr);
        let detail = detail.trim();
        let detail = if detail.is_empty() {
            String::new()
        } else {
            format!("\nCargo reported:\n{detail}")
        };
        return Err(cli_error(format!(
            "failed to install {} {} from crates.io; install it manually and pass --exporter <path>{detail}",
            release.package, release.version,
        )));
    }
    eprintln!(
        "Historical reVault exporter {} {} is ready.",
        release.package, release.version
    );
    validate_exporter_capabilities(&binary, release)?;
    Ok(binary)
}

fn installed_exporter(binary_name: &str) -> Option<PathBuf> {
    let binary = env::current_exe().ok()?.parent()?.join(binary_name);
    binary.is_file().then_some(binary)
}

#[derive(Clone, Copy)]
struct ExporterRelease {
    package: &'static str,
    version: &'static str,
    binary: &'static str,
    protocol: u64,
    artifact: &'static str,
    native_version: u32,
    migration_schema: u32,
}

fn experimental_v4_exporter(kind: ArtifactKind) -> CliResult<ExporterRelease> {
    Ok(ExporterRelease {
        package: "revault_experimental_v4_exporter",
        version: "0.0.0",
        binary: match kind {
            ArtifactKind::Archive => "revault-migrate-archive-experimental-v4",
            ArtifactKind::Vault => "revault-migrate-vault-experimental-v4",
            ArtifactKind::Journal => return Err(cli_error("journals are not historical source archives")),
        },
        protocol: 3,
        artifact: if kind == ArtifactKind::Archive { "archive" } else { "vault" },
        native_version: 4,
        migration_schema: 3,
    })
}

fn exporter_release(kind: ArtifactKind, source_version: u32) -> Option<ExporterRelease> {
    match (kind, source_version) {
        (ArtifactKind::Vault, 3) => Some(ExporterRelease {
            package: "revault_migrate_archive_v3",
            version: "0.0.1",
            binary: "revault-migrate-vault-v3",
            protocol: 3,
            artifact: "vault",
            native_version: 3,
            migration_schema: 3,
        }),
        (ArtifactKind::Archive, 2 | 3) => Some(ExporterRelease {
            package: "revault_migrate_archive_v3",
            version: "0.0.1",
            binary: "revault-migrate-archive-v3",
            protocol: 3,
            artifact: "archive",
            native_version: 3,
            migration_schema: 3,
        }),
        (ArtifactKind::Vault, 2) => Some(ExporterRelease {
            package: "revault_migrate_vault_v2",
            version: "0.0.1",
            binary: "revault-migrate-vault-v2",
            protocol: 2,
            artifact: "vault",
            native_version: 2,
            migration_schema: 2,
        }),
        (ArtifactKind::Vault, 1) => Some(ExporterRelease {
            package: "revault_migrate_vault_v1",
            version: "0.0.4",
            binary: "revault-migrate-vault-v1",
            protocol: 2,
            artifact: "vault",
            native_version: 1,
            migration_schema: 2,
        }),
        (ArtifactKind::Archive, 1) => Some(ExporterRelease {
            package: "revault_migrate_archive_v1",
            version: "0.0.5",
            binary: "revault-migrate-archive-v1",
            protocol: 3,
            artifact: "archive",
            native_version: 1,
            migration_schema: 2,
        }),
        _ => None,
    }
}

fn validate_exporter_capabilities(path: &Path, release: ExporterRelease) -> CliResult<()> {
    let output = Command::new(path).arg("capabilities").output()?;
    if !output.status.success() {
        return Err(cli_error("historical exporter capability check failed"));
    }
    if !capabilities_match(&output.stdout, release) {
        return Err(cli_error(
            "historical exporter capabilities do not match the registered format",
        ));
    }
    Ok(())
}

fn capabilities_match(bytes: &[u8], release: ExporterRelease) -> bool {
    let Ok(value) = serde_json::from_slice::<serde_json::Value>(bytes) else {
        return false;
    };
    let valid = value.get("protocol").and_then(|value| value.as_u64()) == Some(release.protocol)
        && value.get("artifact").and_then(|value| value.as_str()) == Some(release.artifact)
        && value.get("native_version").and_then(|value| value.as_u64())
            == Some(u64::from(release.native_version))
        && value
            .get("migration_schema")
            .and_then(|value| value.as_u64())
            == Some(u64::from(release.migration_schema));
    if !valid || release.artifact != "vault" || release.protocol < 2 {
        return valid;
    }
    if release.native_version == 4 {
        return value.get("container_version").and_then(|value| value.as_u64()) == Some(4)
            && json_u64_array(&value, "structure_versions") == [3]
            && json_u64_array(&value, "migration_schemas") == [3];
    }
    if release.native_version == 3 {
        return value
            .get("container_version")
            .and_then(|value| value.as_u64())
            == Some(3)
            && json_u64_array(&value, "structure_versions") == [3]
            && json_u64_array(&value, "migration_schemas") == [3];
    }
    if release.native_version == 2 {
        return value
            .get("container_version")
            .and_then(|value| value.as_u64())
            == Some(2)
            && json_u64_array(&value, "structure_versions") == [2]
            && json_u64_array(&value, "migration_schemas") == [2];
    }
    value
        .get("container_version")
        .and_then(|value| value.as_u64())
        == Some(1)
        && json_u64_array(&value, "structure_versions") == [1, 2]
        && json_u64_array(&value, "migration_schemas") == [1, 2]
}

fn json_u64_array(value: &serde_json::Value, field: &str) -> Vec<u64> {
    value
        .get(field)
        .and_then(|value| value.as_array())
        .map(|values| {
            values
                .iter()
                .filter_map(serde_json::Value::as_u64)
                .collect()
        })
        .unwrap_or_default()
}

fn run_historical_vault_exporter(
    exporter: &Path,
    source: &Path,
    output: &Path,
    vault_password: &SecretString,
    artifact_password: &SecretString,
) -> CliResult<()> {
    let mut child = Command::new(exporter)
        .args(["migrate", "vault", "export", "--output"])
        .arg(output)
        .arg("--source")
        .arg(source)
        .stdin(Stdio::piped())
        .spawn()?;
    write_subprocess_secrets(&mut child, &[vault_password, artifact_password], &[])?;
    let status = child.wait()?;
    if !status.success() {
        return Err(cli_error(format!(
            "historical vault exporter exited with {status}"
        )));
    }
    Ok(())
}

fn run_historical_archive_exporter(
    exporter: &Path,
    source: &Path,
    output: &Path,
    vault: &VaultDirectory,
    vault_password: &SecretString,
    artifact_password: &SecretString,
) -> CliResult<()> {
    let contact_keys = migration_contact_keys(vault)?;
    let mut child = Command::new(exporter)
        .args(["migrate", "archive", "export"])
        .arg(source)
        .arg("--output")
        .arg(output)
        .stdin(Stdio::piped())
        .spawn()?;
    write_subprocess_secrets(
        &mut child,
        &[vault_password, artifact_password],
        &contact_keys,
    )?;
    let status = child.wait()?;
    if !status.success() {
        return Err(cli_error(format!(
            "historical lockbox exporter exited with {status}"
        )));
    }
    Ok(())
}

fn write_subprocess_secrets(
    child: &mut std::process::Child,
    secrets: &[&SecretString],
    binary_secrets: &[SecretVec],
) -> CliResult<()> {
    let mut stdin = child
        .stdin
        .take()
        .ok_or_else(|| cli_error("exporter stdin unavailable"))?;
    stdin.write_all(b"LBXMIPC1")?;
    stdin.write_all(
        &u32::try_from(secrets.len() + binary_secrets.len())
            .map_err(|_| cli_error("too many migration secrets"))?
            .to_le_bytes(),
    )?;
    for secret in secrets {
        secret.with_bytes(|bytes| -> std::io::Result<()> {
            let len = u32::try_from(bytes.len()).map_err(|_| {
                std::io::Error::new(
                    std::io::ErrorKind::InvalidInput,
                    "migration secret too long",
                )
            })?;
            stdin.write_all(&len.to_le_bytes())?;
            stdin.write_all(bytes)
        })??;
    }
    for secret in binary_secrets {
        secret.with_bytes(|bytes| -> std::io::Result<()> {
            let len = u32::try_from(bytes.len()).map_err(|_| {
                std::io::Error::new(
                    std::io::ErrorKind::InvalidInput,
                    "migration secret too long",
                )
            })?;
            stdin.write_all(&len.to_le_bytes())?;
            stdin.write_all(bytes)
        })??;
    }
    drop(stdin);
    Ok(())
}

fn migration_contact_keys(vault: &VaultDirectory) -> CliResult<Vec<SecretVec>> {
    let mut records = Vec::new();
    for profile in vault.list_private_keys()? {
        let active = vault.load_private_key(&profile)?;
        records.push(active.private_key_record()?);
        if let Ok(history) = vault.list_profile_generations(&profile) {
            for generation in history.generations {
                if generation.index == history.active_generation {
                    continue;
                }
                let key = vault.load_private_key_generation(&profile, generation.index)?;
                records.push(key.private_key_record()?);
            }
        }
    }
    Ok(records)
}

fn migration_password() -> CliResult<SecretString> {
    if let Some(value) = SecretString::try_from_env("LOCKBOX_MIGRATION_PASSWORD")? {
        return Ok(value);
    }
    prompt_secret("Migration artifact pass phrase: ").map_err(Into::into)
}

fn default_signing_key() -> CliResult<OwnerSigningKeyPair> {
    Ok(default_vault()?.load_owner_signing_key(VaultDirectory::DEFAULT_KEY_NAME)?)
}

fn random_id() -> CliResult<[u8; 16]> {
    let mut id = [0u8; 16];
    getrandom::fill(&mut id)?;
    Ok(id)
}

fn generated_migration_key() -> CliResult<SecretVec> {
    let mut key = SecretVec::new();
    key.resize_zeroed(32)?;
    key.with_mut_bytes(getrandom::fill)??;
    Ok(key)
}

fn probe_archive_path(path: &Path) -> CliResult<u32> {
    let mut file = File::open(path)?;
    let mut magic = [0u8; 8];
    file.read_exact(&mut magic)?;
    let header_len = if &magic == b"LBX1HDR\0" {
        96
    } else if &magic == b"LBX4HDR\0" {
        384
    } else {
        320
    };
    let mut header = vec![0u8; header_len];
    header[..magic.len()].copy_from_slice(&magic);
    file.read_exact(&mut header[magic.len()..])?;
    Ok(u32::from(probe_lockbox_format_version(&header)?))
}

fn probe_vault_source_version(root: &Path, password: &SecretString) -> CliResult<u32> {
    match VaultDirectory::probe_structure_version(root, password) {
        Ok(version) => Ok(version),
        Err(revault_lockbox_api::Error::UnsupportedFormatVersion {
            artifact: revault_lockbox_api::ArtifactKind::Lockbox,
            found: version @ 1..=3,
            ..
        }) => Ok(version),
        Err(error) => Err(error.into()),
    }
}

fn deterministic_operation_id(
    kind: ArtifactKind,
    source: &Path,
    output: Option<&Path>,
    fingerprint: [u8; 32],
) -> [u8; 16] {
    let mut digest = Sha256::new();
    digest.update(match kind {
        ArtifactKind::Vault => b"vault".as_slice(),
        ArtifactKind::Archive => b"archive".as_slice(),
        ArtifactKind::Journal => b"journal".as_slice(),
    });
    digest.update(source.as_os_str().as_encoded_bytes());
    if let Some(output) = output {
        digest.update([0]);
        digest.update(output.as_os_str().as_encoded_bytes());
    }
    digest.update(fingerprint);
    let value = digest.finalize();
    let mut id = [0u8; 16];
    id.copy_from_slice(&value[..16]);
    id
}

fn load_or_create_journal<P: MigrationPassphrase + ?Sized>(
    path: &Path,
    passphrase: &P,
    initial: MigrationJournal,
) -> revault_migration::Result<MigrationJournal> {
    if path.exists() {
        MigrationJournal::load(path, passphrase)
    } else {
        initial.save(path, passphrase)?;
        Ok(initial)
    }
}

fn validate_resume(
    journal: &MigrationJournal,
    kind: ArtifactKind,
    source: &Path,
    source_version: u32,
    fingerprint: [u8; 32],
    output: &Path,
) -> CliResult<()> {
    if journal.artifact_kind != kind
        || journal.source_path != source
        || journal.source_format_version != source_version
        || journal.source_fingerprint != fingerprint
    {
        return Err(cli_error(
            "the saved migration does not match the current source; the source may have changed",
        ));
    }
    if journal.current_stage == MigrationStage::Export && output.exists() {
        return Err(cli_error(format!(
            "migration destination already exists without a completed import: {}",
            output.display()
        )));
    }
    Ok(())
}

fn ensure_artifact_key(journal: &mut MigrationJournal) -> CliResult<()> {
    if !journal.artifact_key.is_empty() {
        return Ok(());
    }
    if journal.current_stage != MigrationStage::Export {
        return Err(cli_error(
            "the saved migration state predates generated migration keys; remove the incomplete migration state and retry",
        ));
    }
    journal.artifact_key = generated_migration_key()?;
    Ok(())
}

fn save_journal<P: MigrationPassphrase + ?Sized>(
    journal: &mut MigrationJournal,
    path: &Path,
    journal_password: &P,
) -> CliResult<()> {
    journal.save(path, journal_password)?;
    Ok(())
}

fn reject_unowned_destination(journal_path: &Path, output: &Path) -> CliResult<()> {
    if !journal_path.exists() && output.exists() {
        return Err(cli_error(format!(
            "migration destination already exists: {}",
            output.display()
        )));
    }
    Ok(())
}

fn recover_interrupted_replacement<P: MigrationPassphrase + ?Sized>(
    source: &Path,
    kind: ArtifactKind,
    passphrase: &P,
) -> revault_migration::Result<bool> {
    let Some(parent) = source.parent() else {
        return Ok(false);
    };
    let entries = match fs::read_dir(parent) {
        Ok(entries) => entries,
        Err(_) => return Ok(false),
    };
    for entry in entries.flatten() {
        let work_dir = entry.path();
        if !work_dir
            .file_name()
            .is_some_and(|name| name.to_string_lossy().starts_with(".revault-migration-"))
        {
            continue;
        }
        let journal_path = work_dir.join(match kind {
            ArtifactKind::Vault => "vault.migration-state",
            ArtifactKind::Archive => "archive.migration-state",
            ArtifactKind::Journal => continue,
        });
        let Ok(journal) = MigrationJournal::load(&journal_path, passphrase) else {
            continue;
        };
        if journal.artifact_kind != kind
            || journal.source_path != source
            || journal.current_stage != MigrationStage::Replace
        {
            continue;
        }
        let Some(output) = journal.temporary_paths.last() else {
            continue;
        };
        let backup = versioned_backup_path(
            source,
            journal.source_format_version,
            journal.target_format_version,
        );
        if !backup.exists() || (source.exists() && output.exists()) {
            continue;
        }
        let fingerprint_source = if kind == ArtifactKind::Vault {
            backup.join("local-vault.lbox")
        } else {
            backup.clone()
        };
        if fingerprint_path(&fingerprint_source)
            .map_err(|e| revault_migration::MigrationError::Io(e.to_string()))?
            != journal.source_fingerprint
        {
            return Err(revault_migration::MigrationError::InvalidHeader(
                "migration backup fingerprint changed".into(),
            ));
        }
        if kind == ArtifactKind::Archive {
            let artifact = journal.temporary_paths.iter().rev().nth(1).ok_or_else(|| {
                revault_migration::MigrationError::InvalidHeader(
                    "migration journal has no verification artifact".into(),
                )
            })?;
            revault_migration::verify_imported_archive(
                artifact,
                &journal.artifact_key,
                if source.exists() { source } else { output },
            )?;
        }
        if !source.exists() {
            fs::rename(output, source).map_err(|err| {
                revault_migration::MigrationError::Io(format!(
                    "failed to finish interrupted replacement: {err}"
                ))
            })?;
        }
        #[cfg(unix)]
        fs::File::open(parent)
            .and_then(|file| file.sync_all())
            .map_err(|err| revault_migration::MigrationError::Io(err.to_string()))?;
        cleanup_work_dir(&work_dir);
        return Ok(true);
    }
    Ok(false)
}

fn remove_partial(path: &Path) -> CliResult<()> {
    if !path.exists() {
        return Ok(());
    }
    if path.is_dir() {
        fs::remove_dir_all(path)?;
    } else {
        fs::remove_file(path)?;
    }
    Ok(())
}

fn fingerprint_path(path: &Path) -> CliResult<[u8; 32]> {
    let mut file = File::open(path)?;
    let mut digest = Sha256::new();
    // Windows CLI stacks cannot accommodate a 1 MiB local array.
    let mut buffer = vec![0u8; 1024 * 1024];
    loop {
        let read = file.read(&mut buffer)?;
        if read == 0 {
            break;
        }
        digest.update(&buffer[..read]);
    }
    Ok(digest.finalize().into())
}

fn new_journal(
    operation_id: [u8; 16],
    artifact_kind: ArtifactKind,
    source_path: PathBuf,
    source_format_version: u32,
    target_format_version: u32,
    source_fingerprint: [u8; 32],
    temporary_paths: Vec<PathBuf>,
) -> CliResult<MigrationJournal> {
    let journal = MigrationJournal {
        operation_id,
        artifact_kind,
        source_path,
        source_format_version,
        source_fingerprint,
        target_format_version,
        current_stage: MigrationStage::Export,
        temporary_paths,
        exporter_version: None,
        artifact_key: generated_migration_key()?,
    };
    Ok(journal)
}

fn require_destination(replace: bool, output: Option<&Path>, kind: &str) -> CliResult<()> {
    if !replace && output.is_none() {
        return Err(cli_error(format!(
            "{kind} migration requires --output <path>, or pass --replace to retain a backup and replace the source"
        )));
    }
    Ok(())
}

fn migration_work_dir(source: &Path, operation_id: [u8; 16]) -> CliResult<PathBuf> {
    let parent = source
        .parent()
        .ok_or_else(|| cli_error("migration source has no parent"))?;
    Ok(parent.join(format!(".revault-migration-{}", hex_id(operation_id))))
}

fn temporary_vault_destination(source: &Path, id: [u8; 16]) -> PathBuf {
    source.with_file_name(format!(".vault-migrated-{}", hex_id(id)))
}

fn temporary_archive_destination(source: &Path, id: [u8; 16]) -> PathBuf {
    source.with_file_name(format!(".archive-migrated-{}.lbox", hex_id(id)))
}

fn versioned_backup_path(source: &Path, source_version: u32, target_version: u32) -> PathBuf {
    let name = source
        .file_name()
        .map(|value| value.to_string_lossy().into_owned())
        .unwrap_or_else(|| "artifact".to_string());
    source.with_file_name(format!(
        "{name}.v{source_version}-v{target_version}.pre-migration"
    ))
}

fn exporter_cache_root() -> CliResult<PathBuf> {
    let home = env::var_os("HOME")
        .or_else(|| env::var_os("USERPROFILE"))
        .ok_or_else(|| cli_error("home directory is unavailable"))?;
    Ok(PathBuf::from(home).join(".cache/revault/exporters"))
}

fn cleanup_work_dir(path: &Path) {
    let _ = fs::remove_dir_all(path);
}

fn hex_id(id: [u8; 16]) -> String {
    id.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn required_string(matches: &ArgMatches, name: &str) -> CliResult<String> {
    matches
        .get_one::<String>(name)
        .cloned()
        .ok_or_else(|| cli_error(format!("missing {name}")))
}

fn required_path(matches: &ArgMatches, name: &str) -> CliResult<PathBuf> {
    required_string(matches, name).map(PathBuf::from)
}

fn read_secret_lines_stdin(count: usize) -> CliResult<Vec<SecretString>> {
    let stdin = std::io::stdin();
    let mut stdin = stdin.lock();
    let mut values = Vec::with_capacity(count);
    for _ in 0..count {
        let mut bytes = Vec::new();
        stdin.read_until(b'\n', &mut bytes)?;
        while bytes
            .last()
            .is_some_and(|byte| matches!(byte, b'\n' | b'\r'))
        {
            bytes.pop();
        }
        values.push(SecretString::try_from_bytes(bytes)?);
    }
    Ok(values)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn direct_migration_identity_is_stable_and_destination_specific() {
        let fingerprint = [9; 32];
        let first = deterministic_operation_id(
            ArtifactKind::Archive,
            Path::new("/tmp/source.lbox"),
            Some(Path::new("/tmp/output.lbox")),
            fingerprint,
        );
        assert_eq!(
            first,
            deterministic_operation_id(
                ArtifactKind::Archive,
                Path::new("/tmp/source.lbox"),
                Some(Path::new("/tmp/output.lbox")),
                fingerprint,
            )
        );
        assert_ne!(
            first,
            deterministic_operation_id(
                ArtifactKind::Archive,
                Path::new("/tmp/source.lbox"),
                Some(Path::new("/tmp/other.lbox")),
                fingerprint,
            )
        );
    }

    #[test]
    fn direct_migration_key_is_random_and_zeroizing() {
        let first = generated_migration_key().unwrap();
        let second = generated_migration_key().unwrap();
        assert_eq!(first.len(), 32);
        assert_eq!(second.len(), 32);
        assert!(first
            .with_bytes(|first| second.with_bytes(|second| first != second).unwrap())
            .unwrap());
    }

    #[test]
    fn resume_rejects_a_changed_source() {
        let journal = new_journal(
            [1; 16],
            ArtifactKind::Archive,
            PathBuf::from("source.lbox"),
            1,
            2,
            [2; 32],
            Vec::new(),
        )
        .unwrap();
        let error = validate_resume(
            &journal,
            ArtifactKind::Archive,
            Path::new("source.lbox"),
            1,
            [3; 32],
            Path::new("output.lbox"),
        )
        .unwrap_err();
        assert!(error.to_string().contains("source may have changed"));
    }

    #[test]
    fn interrupted_replace_is_finished_from_the_encrypted_journal() {
        let temp = tempfile::tempdir().unwrap();
        let source = temp.path().join("secrets.lbox");
        let backup = versioned_backup_path(&source, 1, 4);
        let output = temp.path().join("migrated.lbox");
        fs::write(&backup, b"old").unwrap();
        let work = temp.path().join(".revault-migration-test");
        fs::create_dir(&work).unwrap();
        let mut journal = new_journal(
            [4; 16],
            ArtifactKind::Archive,
            source.clone(),
            1,
            4,
            fingerprint_path(&backup).unwrap(),
            vec![work.join("archive.migration"), output.clone()],
        )
        .unwrap();
        ensure_artifact_key(&mut journal).unwrap();
        let signer = OwnerSigningKeyPair::generate().unwrap();
        let mut original = revault_lockbox_api::Lockbox::create_in_memory(
            revault_lockbox_api::LockboxProtection::ContentKey(
                SecretVec::try_from_slice(b"resume fixture key").unwrap(),
            ),
            &signer,
        )
        .unwrap();
        original
            .add_file(
                &revault_lockbox_api::LockboxPath::new("/keep").unwrap(),
                b"verified content",
                false,
            )
            .unwrap();
        original.commit().unwrap();
        let artifact = work.join("archive.migration");
        export_archive(&original, &artifact, &journal.artifact_key, [4; 16]).unwrap();
        import_archive(&artifact, &journal.artifact_key, &output, &signer).unwrap();
        let expected = fs::read(&output).unwrap();
        // A damaged destination must never be installed solely because the
        // authenticated journal says the previous validation had completed.
        fs::write(&output, b"damaged output").unwrap();
        journal.current_stage = MigrationStage::Replace;
        journal
            .save(&work.join("archive.migration-state"), b"resume password")
            .unwrap();

        assert!(recover_interrupted_replacement(
            &source,
            ArtifactKind::Archive,
            b"resume password"
        )
        .is_err());
        assert!(!source.exists());
        assert_eq!(fs::read(&backup).unwrap(), b"old");
        fs::write(&output, &expected).unwrap();

        assert!(recover_interrupted_replacement(
            &source,
            ArtifactKind::Archive,
            b"resume password"
        )
        .unwrap());
        assert_eq!(fs::read(&source).unwrap(), expected);
        assert_eq!(fs::read(&backup).unwrap(), b"old");
        assert!(!work.exists());
    }

    #[test]
    fn exporter_registry_and_capability_contract_are_exact() {
        let vault_v2 = exporter_release(ArtifactKind::Vault, 2).unwrap();
        assert_eq!(vault_v2.package, "revault_migrate_vault_v2");
        assert!(capabilities_match(
            br#"{"protocol":2,"artifact":"vault","native_version":2,"migration_schema":2,"container_version":2,"structure_versions":[2],"migration_schemas":[2]}"#,
            vault_v2
        ));
        assert!(!capabilities_match(
            br#"{"protocol":2,"artifact":"vault","native_version":2,"migration_schema":2,"container_version":1,"structure_versions":[2],"migration_schemas":[2]}"#,
            vault_v2
        ));
        let vault = exporter_release(ArtifactKind::Vault, 1).unwrap();
        assert_eq!(vault.package, "revault_migrate_vault_v1");
        assert_eq!(vault.binary, "revault-migrate-vault-v1");
        assert_eq!(vault.version, "0.0.4");
        assert!(capabilities_match(
            br#"{"protocol":2,"artifact":"vault","native_version":1,"migration_schema":2,"container_version":1,"structure_versions":[1,2],"migration_schemas":[1,2]}"#,
            vault
        ));
        assert!(!capabilities_match(
            br#"{"protocol":1,"artifact":"archive","native_version":1,"migration_schema":1}"#,
            vault
        ));

        let archive = exporter_release(ArtifactKind::Archive, 1).unwrap();
        assert_eq!(archive.package, "revault_migrate_archive_v1");
        assert_eq!(archive.binary, "revault-migrate-archive-v1");
        assert_eq!(archive.version, "0.0.5");
        assert!(capabilities_match(
            br#"{"protocol":3,"artifact":"archive","native_version":1,"migration_schema":2}"#,
            archive
        ));
        assert!(!capabilities_match(
            br#"{"protocol":1,"artifact":"archive","native_version":1,"migration_schema":1}"#,
            archive
        ));
    }
}
