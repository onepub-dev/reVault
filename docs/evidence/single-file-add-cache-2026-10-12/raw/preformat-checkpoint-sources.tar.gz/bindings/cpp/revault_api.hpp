#pragma once

/**
 * @file revault_api.hpp
 * @brief RAII C++ API for encrypted reVault Lockboxes and persistent Vaults.
 *
 * Use the functions and classes in `revault` to create or open lockboxes,
 * manage cryptographic keys, and open the local metadata vault. Objects that
 * retain sensitive state release it when destroyed; secret values are exposed
 * only to callback-scoped byte spans.
 *
 * See the [repository README](https://github.com/onepub-dev/reVault#readme)
 * for installation, the security model, and complete examples.
 */

#include <algorithm>
#include <cstdint>
#include <string>
#include <string_view>
#include <stdexcept>
#include <optional>
#include <functional>
#include <span>
#include <vector>

#include <revault_api.h>
#include "domain_models.hpp"

/** High-level, ownership-safe wrappers around the stable reVault C ABI. */
namespace revault {

class Vault;
class ReadOnlyVault;
class AgentSession;
class WrappedContactKey;

namespace detail {

// BEGIN generated file operation route

inline void* file_handle(const std::string& path, const std::string& mode,
 const std::string& credential, const std::vector<std::uint8_t>& secret,
 const void* contact, const void* signer, const std::string& cache_mode,
 std::uint64_t cache_bytes, const std::string& workload, const std::string& worker, std::size_t jobs) {
 auto* handle = lockbox_file(path.data(), path.size(), mode.data(), mode.size(), credential.data(), credential.size(), secret.data(), secret.size(), contact, signer, cache_mode.data(), cache_mode.size(), cache_bytes, workload.data(), workload.size(), worker.data(), worker.size(), jobs);
 if (!handle) throw std::runtime_error(buffer_last_error());
 return handle;
}
// END generated file operation route
inline void require_compatible_abi() {
  if (api_abi_version() != 3)
    throw std::runtime_error("revault-api native ABI mismatch; expected 3");
}

class Buffer {
 public:
  /** Returns the buffer. */
  Buffer() = default;
  /** Returns the buffer. */
  explicit Buffer(RevaultBuffer value) : value_(value) {}
  /** Returns the buffer. */
  Buffer(const Buffer&) = delete;
  /** Returns the operator. */
  Buffer& operator=(const Buffer&) = delete;
  /** Returns the buffer. */
  Buffer(Buffer&& other) noexcept : value_(other.value_) { other.value_ = {}; }
  /** Returns the operator. */
  Buffer& operator=(Buffer&& other) noexcept {
    if (this != &other) { reset(); value_ = other.value_; other.value_ = {}; }
    return *this;
  }
  /** Returns the buffer. */
  ~Buffer() { reset(); }
  /** Returns the first byte in the owned native buffer. */
  const std::uint8_t* data() const { return value_.ptr; }
  /** Returns the number of bytes in the owned native buffer. */
  std::size_t size() const { return value_.len; }
  /** Returns the bytes. */
  std::vector<std::uint8_t> bytes() const { return {data(), data() + size()}; }
  /** Returns the operator bool. */
  explicit operator bool() const { return value_.ptr != nullptr; }
 private:
  void reset() { if (value_.ptr) buffer_free(value_); value_ = {}; }
  RevaultBuffer value_{};
};

inline std::vector<std::uint8_t> take_bytes(RevaultBuffer result) {
  if (!result.ptr) throw std::runtime_error(buffer_last_error());
  Buffer owned(result);
  return owned.bytes();
}

inline std::string take_string(RevaultBuffer result) {
  const auto bytes = take_bytes(result);
  return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
}

/**
 * Invokes `callback` with a temporary plaintext span, then wipes the transfer
 * buffer and releases the native secret handle. The callback must not retain
 * the span.
 */
inline bool with_secret_handle(
    void* handle,
    const std::function<void(std::span<const std::uint8_t>)>& callback) {
  if (!handle) return false;
  try {
    std::size_t length{};
    if (!secret_len(handle, &length)) throw std::runtime_error(buffer_last_error());
    std::vector<std::uint8_t> bytes(length);
    if (!secret_copy(handle, bytes.data(), bytes.size()))
      throw std::runtime_error(buffer_last_error());
    try { callback(bytes); }
    catch (...) {
      std::fill(bytes.begin(), bytes.end(), std::uint8_t{0});
      throw;
    }
    std::fill(bytes.begin(), bytes.end(), std::uint8_t{0});
    secret_free(handle);
    return true;
  } catch (...) {
    secret_free(handle);
    throw;
  }
}

template <typename Message>
Message take_message(RevaultBuffer result) {
  if (!result.ptr) throw std::runtime_error(buffer_last_error());
  Buffer owned(result);
  return decode<Message>({owned.data(), owned.size()});
}

inline bindings::ErrorDetails last_error_details() {
  return take_message<bindings::ErrorDetails>(buffer_last_error_details());
}

/** Private carrier for the vault-integrated lockbox calls. It is deliberately
 * not a public domain object; callers use Lockbox factories and AgentSession. */
class VaultIntegrationHandle {
 public:
  VaultIntegrationHandle() : handle_(vault_local()) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  VaultIntegrationHandle(const VaultIntegrationHandle&) = delete;
  VaultIntegrationHandle& operator=(const VaultIntegrationHandle&) = delete;
  ~VaultIntegrationHandle() { if (handle_) vault_free(handle_); }
  const void* get() const { return handle_; }
 private:
  void* handle_{};
};

}  // namespace detail

/** Linked native runtime entry point. Loading validates the ABI and does not
 * open a Vault or start the optional AgentSession. */
class Revault {
 public:
  /** Validates that the linked carrier implements this facade's ABI. */
  static Revault load() {
    detail::require_compatible_abi();
    return Revault();
  }
 private:
  Revault() = default;
};

/** Throws when the loaded native library does not implement this facade's ABI. */
inline void require_compatible_abi() { detail::require_compatible_abi(); }

/** Returns structured details for the most recent failed native call. */
inline bindings::ErrorDetails last_error_details() {
  return detail::last_error_details();
}

/** A recipient's shareable encryption identity, used when granting that
 * recipient lockbox access and containing no private key material. */
class ContactPublicKey {
 public:
  /** Returns the contact public key. */
  explicit ContactPublicKey(const std::vector<std::uint8_t>& bytes)
      : handle_(key_contact_public_from_bytes(bytes.data(), bytes.size())) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the contact public key. */
  ContactPublicKey(const ContactPublicKey&) = delete;
  /** Returns the operator. */
  ContactPublicKey& operator=(const ContactPublicKey&) = delete;
  /** Returns the contact public key. */
  ContactPublicKey(ContactPublicKey&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the contact public key. */
  ~ContactPublicKey() { if (handle_) key_contact_public_free(handle_); }
  /** Imports import. */
  static ContactPublicKey import(const std::vector<std::uint8_t>& bytes) {
    return ContactPublicKey(vault_key_import_public(bytes.data(), bytes.size()));
  }
  /** Exports as. */
  std::vector<std::uint8_t> export_as(const std::string& format) const {
    return detail::take_bytes(vault_key_export_public(handle_, format.data(), format.size()));
  }
  /** Returns the stable fingerprint of this key. */
  std::vector<std::uint8_t> fingerprint() const {
    return detail::take_bytes(vault_key_fingerprint(handle_));
  }
  /** Encrypts a content key for the selected contact. */
  WrappedContactKey encrypt(const std::vector<std::uint8_t>& content_key) const;
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }
 private:
  friend class Vault;
  explicit ContactPublicKey(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** A content key encrypted for one contact, stored with an access record and
 * recoverable only by the matching ContactKeyPair. */
class WrappedContactKey {
 public:
  /** Returns the wrapped contact key. */
  WrappedContactKey(const WrappedContactKey&) = delete;
  /** Returns the operator. */
  WrappedContactKey& operator=(const WrappedContactKey&) = delete;
  /** Returns the wrapped contact key. */
  WrappedContactKey(WrappedContactKey&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the wrapped contact key. */
  ~WrappedContactKey() { if (handle_) key_contact_wrapped_free(handle_); }
  /** Returns the public bytes. */
  std::vector<std::uint8_t> public_bytes() const { return detail::take_bytes(key_contact_wrapped_public(handle_)); }
  /** Returns the encrypted content key bytes. */
  std::vector<std::uint8_t> ciphertext() const { return detail::take_bytes(key_contact_wrapped_ciphertext(handle_)); }
  /** Returns the encrypted bytes. */
  std::vector<std::uint8_t> encrypted_bytes() const { return detail::take_bytes(key_contact_wrapped_encrypted(handle_)); }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }
 private:
  friend class ContactKeyPair;
  friend class ContactPublicKey;
  explicit WrappedContactKey(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

inline WrappedContactKey ContactPublicKey::encrypt(
    const std::vector<std::uint8_t>& content_key) const {
  return WrappedContactKey(key_contact_encrypt(
      handle_, content_key.data(), content_key.size()));
}

/** A profile's contact-encryption identity; distribute its public half and
 * retain the private half to decrypt content keys addressed to the profile. */
class ContactKeyPair {
 public:
  /** Returns the contact key pair. */
  ContactKeyPair() : handle_(key_contact_generate()) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the from private record. */
  static ContactKeyPair from_private_record(const std::vector<std::uint8_t>& bytes) {
    return ContactKeyPair(key_contact_from_private(bytes.data(), bytes.size()));
  }
  /** Imports import. */
  static ContactKeyPair import(const std::vector<std::uint8_t>& bytes) {
    return ContactKeyPair(vault_key_import_private(bytes.data(), bytes.size()));
  }
  /** Returns the contact key pair. */
  ContactKeyPair(const ContactKeyPair&) = delete;
  /** Returns the operator. */
  ContactKeyPair& operator=(const ContactKeyPair&) = delete;
  /** Returns the contact key pair. */
  ContactKeyPair(ContactKeyPair&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the contact key pair. */
  ~ContactKeyPair() { if (handle_) key_contact_free(handle_); }
  /** Returns the public bytes. */
  std::vector<std::uint8_t> public_bytes() const { return detail::take_bytes(key_contact_public(handle_)); }
  /** Returns the private record. */
  std::vector<std::uint8_t> private_record() const { return detail::take_bytes(key_contact_private(handle_)); }
  /** Returns the public key. */
  ContactPublicKey public_key() const { return ContactPublicKey(public_bytes()); }
  /** Exports as. */
  std::vector<std::uint8_t> export_as(const std::string& format) const {
    return detail::take_bytes(vault_key_export_private(handle_, format.data(), format.size()));
  }
  /** Decrypts a wrapped content key for this contact. */
  std::vector<std::uint8_t> decrypt(const WrappedContactKey& wrapped) const {
    return detail::take_bytes(key_contact_decrypt(handle_, wrapped.native_handle()));
  }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }
 private:
  friend class Vault;
  explicit ContactKeyPair(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** The shareable half of a lockbox owner's signing identity, used by readers to
 * verify owner-authorized revisions. */
class ProfileSigningPublicKey {
 public:
  /** Returns the signing public key. */
  explicit ProfileSigningPublicKey(const std::vector<std::uint8_t>& bytes)
      : handle_(key_signing_public_from_bytes(bytes.data(), bytes.size())) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the signing public key. */
  ProfileSigningPublicKey(const ProfileSigningPublicKey&) = delete;
  /** Returns the operator. */
  ProfileSigningPublicKey& operator=(const ProfileSigningPublicKey&) = delete;
  /** Returns the signing public key. */
  ProfileSigningPublicKey(ProfileSigningPublicKey&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the signing public key. */
  ~ProfileSigningPublicKey() { if (handle_) key_signing_public_free(handle_); }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }
 private:
  friend class Vault;
  explicit ProfileSigningPublicKey(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** A lockbox owner's signing identity, supplied when creating or committing a
 * mutable lockbox so readers can authenticate its revisions. */
class ProfileSigningKeyPair {
 public:
  /** Returns the signing key pair. */
  ProfileSigningKeyPair() : handle_(key_signing_generate()) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the from private record. */
  static ProfileSigningKeyPair from_private_record(const std::vector<std::uint8_t>& bytes) {
    return ProfileSigningKeyPair(key_signing_from_private(bytes.data(), bytes.size()));
  }
  /** Returns the signing key pair. */
  ProfileSigningKeyPair(const ProfileSigningKeyPair&) = delete;
  /** Returns the operator. */
  ProfileSigningKeyPair& operator=(const ProfileSigningKeyPair&) = delete;
  /** Returns the signing key pair. */
  ProfileSigningKeyPair(ProfileSigningKeyPair&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the signing key pair. */
  ~ProfileSigningKeyPair() { if (handle_) key_signing_free(handle_); }
  /** Returns the public bytes. */
  std::vector<std::uint8_t> public_bytes() const { return detail::take_bytes(key_signing_public(handle_)); }
  /** Returns the private record. */
  std::vector<std::uint8_t> private_record() const { return detail::take_bytes(key_signing_private(handle_)); }
  /** Returns the public key. */
  ProfileSigningPublicKey public_key() const { return ProfileSigningPublicKey(public_bytes()); }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }
 private:
  friend class Vault;
  friend class AgentSession;
  explicit ProfileSigningKeyPair(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** Memory and CPU settings applied when creating or opening a Lockbox; the
 * defaults suit interactive applications. */
struct LockboxOptions {
  /** Cache strategy, such as `bytes`. */
  std::string cache_mode{"bytes"};
  /** Maximum cache capacity in bytes. */
  std::uint64_t cache_bytes{64 * 1024 * 1024};
  /** Workload profile, such as `interactive`. */
  std::string workload{"interactive"};
  /** Worker-selection policy, such as `auto`. */
  std::string worker{"auto"};
  /** Worker count; zero lets the library select it. */
  std::size_t jobs{0};
};

/** An open encrypted archive containing files, variables, secrets, and forms;
 * commit mutations and release the object when finished with decrypted data. */
class Lockbox {
 public:
  /** Returns the supported lockbox format version. */
  static std::uint16_t format_version() { return lockbox_format_version(); }
  /** Determines format version without fully opening it. */
  static std::uint16_t probe_format_version(const std::vector<std::uint8_t>& bytes) {
    const auto value = lockbox_probe_format_version(bytes.data(), bytes.size());
    if (!value) throw std::runtime_error(buffer_last_error());
    return value;
  }
  /** Returns the lockbox. */
  explicit Lockbox(const std::vector<std::uint8_t>& key) : handle_(lockbox_create(key.data(), key.size())) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the lockbox. */
  Lockbox(const Lockbox&) = delete;
  /** Returns the operator. */
  Lockbox& operator=(const Lockbox&) = delete;
  /** Returns the lockbox. */
  Lockbox(Lockbox&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the operator. */
  Lockbox& operator=(Lockbox&& other) noexcept {
    if (this != &other) {
      if (handle_) lockbox_free(handle_);
      handle_ = other.handle_;
      other.handle_ = nullptr;
    }
    return *this;
  }
  /** Returns the lockbox. */
  ~Lockbox() { if (handle_) lockbox_free(handle_); }

  /** Creates with password. */
  static Lockbox create_with_password(const std::string& password) {
    return adopt(lockbox_create_password(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Creates with password and establishes the supplied owner signing key. */
  static Lockbox create_with_password_and_signing_key(
      const std::string& password,
      const ProfileSigningKeyPair& signing_key) {
    return adopt(lockbox_create_password_with_signing_key(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size(),
        signing_key.native_handle()));
  }
  /** Creates with options. */
  static Lockbox create_with_options(const std::vector<std::uint8_t>& key,
                                     const LockboxOptions& options) {
    return adopt(lockbox_create_with_options(
        key.data(), key.size(), options.cache_mode.data(), options.cache_mode.size(),
        options.cache_bytes, options.workload.data(), options.workload.size(),
        options.worker.data(), options.worker.size(), options.jobs));
  }
  /** Creates for contact. */
  static Lockbox create_for_contact(const ContactPublicKey& contact) {
    return adopt(lockbox_create_contact(contact.native_handle()));
  }
  /** Creates for contact and establishes the supplied owner signing key. */
  static Lockbox create_for_contact_with_signing_key(
      const ContactPublicKey& contact,
      const ProfileSigningKeyPair& signing_key) {
    return adopt(lockbox_create_contact_with_signing_key(
        contact.native_handle(), signing_key.native_handle()));
  }
  /** Creates signed. */
  static Lockbox create_signed(const std::vector<std::uint8_t>& key,
                               const ProfileSigningKeyPair& signing_key) {
    return adopt(lockbox_create_with_signing_key(
        key.data(), key.size(), signing_key.native_handle()));
  }
// BEGIN generated file operation facade
  /** Creates and exclusively locks a native file. overwrite requires explicit replacement.
   * Example: { auto box = Lockbox::create_file(path, key, signer); box.add_file("/hello", payload); box.commit(); }
   */
  static Lockbox create_file(const std::string& path, const std::vector<std::uint8_t>& content_key, const ProfileSigningKeyPair& signer, bool overwrite = false) {
    return adopt(detail::file_handle(path, overwrite ? "replace" : "create", "content-key", content_key, nullptr, signer.native_handle(), "bytes", 64ULL << 20, "interactive", "auto", 0));
  }
  /** Opens a native file with a shared lock; supply signer for exclusive write access.
   * Close all readers before opening a writer. No Session Agent is used.
   * Example: { auto box = Lockbox::open_file(path, key); auto payload = box.get_file("/hello"); }
   */
  static Lockbox open_file(const std::string& path, const std::vector<std::uint8_t>& content_key, const ProfileSigningKeyPair* signer = nullptr, std::optional<bool> writable = std::nullopt) {
    return adopt(detail::file_handle(path, writable ? (*writable ? "write" : "read") : "open", "content-key", content_key, nullptr, signer ? signer->native_handle() : nullptr, "bytes", 64ULL << 20, "interactive", "auto", 0));
  }

// END generated file operation facade
  /** Opens an existing lockbox. */
  static Lockbox open(const std::vector<std::uint8_t>& archive,
                      const std::vector<std::uint8_t>& key) {
    return adopt(lockbox_open(archive.data(), archive.size(), key.data(), key.size()));
  }
  /** Opens with password. */
  static Lockbox open_with_password(const std::vector<std::uint8_t>& archive,
                                    const std::string& password) {
    return adopt(lockbox_open_password(
        archive.data(), archive.size(),
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Opens with options. */
  static Lockbox open_with_options(const std::vector<std::uint8_t>& archive,
                                   const std::vector<std::uint8_t>& key,
                                   const LockboxOptions& options) {
    return adopt(lockbox_open_with_options(
        archive.data(), archive.size(), key.data(), key.size(),
        options.cache_mode.data(), options.cache_mode.size(), options.cache_bytes,
        options.workload.data(), options.workload.size(), options.worker.data(),
        options.worker.size(), options.jobs));
  }
  /** Opens with contact. */
  static Lockbox open_with_contact(const std::vector<std::uint8_t>& archive,
                                   const ContactKeyPair& contact) {
    return adopt(lockbox_open_contact(archive.data(), archive.size(), contact.native_handle()));
  }

  /** Creates a password-protected lockbox at a host path through the
   * persistent Vault integration. The returned Lockbox owns the process-local
   * content key; it does not retain the integration handle. */
  static Lockbox create_path_with_password(const std::string& path,
                                           const std::string& lockbox_password) {
    detail::VaultIntegrationHandle vault;
    return adopt(vault_create_lockbox_password(
        vault.get(), path.data(), path.size(),
        reinterpret_cast<const std::uint8_t*>(lockbox_password.data()),
        lockbox_password.size()));
  }
  /** Opens a password-protected lockbox from a host path. */
  static Lockbox open_path_with_password(const std::string& path,
                                         const std::string& lockbox_password) {
    detail::VaultIntegrationHandle vault;
    return adopt(vault_open_lockbox_password(
        vault.get(), path.data(), path.size(),
        reinterpret_cast<const std::uint8_t*>(lockbox_password.data()),
        lockbox_password.size()));
  }
  /** Creates a content-key lockbox at a host path. */
  static Lockbox create_path_with_content_key(
      const std::string& path, const std::vector<std::uint8_t>& content_key,
      const ProfileSigningKeyPair& signing_key) {
    detail::VaultIntegrationHandle vault;
    return adopt(vault_create_lockbox_content_key(
        vault.get(), path.data(), path.size(), content_key.data(),
        content_key.size(), signing_key.native_handle()));
  }
  /** Opens a content-key lockbox from a host path. */
  static Lockbox open_path_with_content_key(
      const std::string& path, const std::vector<std::uint8_t>& content_key,
      const ProfileSigningKeyPair& signing_key) {
    detail::VaultIntegrationHandle vault;
    return adopt(vault_open_lockbox_content_key(
        vault.get(), path.data(), path.size(), content_key.data(),
        content_key.size(), signing_key.native_handle()));
  }
  /** Creates a contact-protected lockbox at a host path. */
  static Lockbox create_path_for_contact(
      const std::string& path, const ContactPublicKey& contact,
      const std::string& contact_name, const ProfileSigningKeyPair& signing_key) {
    detail::VaultIntegrationHandle vault;
    return adopt(vault_create_lockbox_contact(
        vault.get(), path.data(), path.size(), contact.native_handle(),
        contact_name.data(), contact_name.size(), signing_key.native_handle()));
  }

  /** Stages a file at the Lockbox path; replace controls an existing entry. */
  void add_file(const std::string& path, const std::vector<std::uint8_t>& data, bool replace = false) {
    if (!lockbox_add_file(handle_, path.data(), path.size(), data.data(), data.size(), replace))
      throw std::runtime_error(buffer_last_error());
  }
  /** Authenticates and publishes the staged changes. */
  void commit() {
    if (!lockbox_commit(handle_)) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the storage length. */
  std::uint64_t storage_length() const { return lockbox_storage_len(handle_); }
  /** Returns the stable public identifier stored in the Lockbox header. */
  std::vector<std::uint8_t> id() const { return detail::take_bytes(lockbox_id(handle_)); }
  /** Inspects file. */
  static bindings::FileInspection inspect_file(const std::string& path) {
    return detail::take_message<bindings::FileInspection>(
        lockbox_inspect_file(path.data(), path.size()));
  }
  /** Returns the render recovery report. */
  std::string render_recovery_report(bool verbose = false,
                                     std::size_t max_entries = 100) const {
    return detail::take_string(lockbox_recovery_report_render(handle_, verbose, max_entries));
  }
  /** Scans path. */
  static bindings::RecoveryReport scan_path(const std::string& path,
                                            const std::vector<std::uint8_t>& key) {
    return detail::take_message<bindings::RecoveryReport>(lockbox_recovery_scan_path(
        path.data(), path.size(), key.data(), key.size()));
  }
  /** Scans scan. */
  static bindings::RecoveryReport scan(const std::vector<std::uint8_t>& archive,
                                       const std::vector<std::uint8_t>& key) {
    return detail::take_message<bindings::RecoveryReport>(lockbox_recovery_scan(
        archive.data(), archive.size(), key.data(), key.size()));
  }
  /** Salvages salvage. */
  static Lockbox salvage(const std::vector<std::uint8_t>& archive,
                         const std::vector<std::uint8_t>& key,
                         const ProfileSigningKeyPair* signing_key = nullptr) {
    return adopt(lockbox_recovery_salvage(
        archive.data(), archive.size(), key.data(), key.size(),
        signing_key ? signing_key->native_handle() : nullptr));
  }
  /** Reads the complete file stored at the Lockbox path. */
  std::vector<std::uint8_t> get_file(const std::string& path) const {
    auto result = lockbox_get_file(handle_, path.data(), path.size());
    if (!result.ptr) throw std::runtime_error(buffer_last_error());
    std::vector<std::uint8_t> value(result.ptr, result.ptr + result.len);
    buffer_free(result);
    return value;
  }
  /** Stages a file and its portable Unix permission bits. */
  void add_file_with_permissions(const std::string& path, const std::vector<std::uint8_t>& data,
                                 std::uint32_t permissions, bool replace = false) {
    if (!lockbox_add_file_with_permissions(handle_, path.data(), path.size(), data.data(), data.size(), permissions, replace))
      throw std::runtime_error(buffer_last_error());
  }
  /** Stages a directory entry and optionally creates missing parents. */
  void create_dir(const std::string& path, bool create_parents = true) {
    if (!lockbox_create_dir(handle_, path.data(), path.size(), create_parents)) throw std::runtime_error(buffer_last_error());
  }
  /** Stages every missing parent directory for path. */
  void create_parent_dirs(const std::string& path) {
    if (!lockbox_create_parent_dirs(handle_, path.data(), path.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Writes one Lockbox file to the host filesystem. */
  void extract_file(const std::string& source, const std::string& destination,
                    bool replace = false) const {
    if (!lockbox_extract_file(handle_, source.data(), source.size(), destination.data(),
                              destination.size(), replace))
      throw std::runtime_error(buffer_last_error());
  }
  /** Extracts the Lockbox with explicit size, count, link, and permission limits. */
  void extract_directory(const std::string& destination, std::uint64_t max_file_bytes,
                         std::uint64_t max_total_bytes, std::size_t max_files,
                         bool restore_symlinks, bool restore_permissions,
                         bool overwrite) const {
    if (!lockbox_extract_directory(handle_, destination.data(), destination.size(),
                                   max_file_bytes, max_total_bytes, max_files,
                                   restore_symlinks, restore_permissions, overwrite))
      throw std::runtime_error(buffer_last_error());
  }
  /** Stages removal of a directory, optionally including its descendants. */
  void remove_dir(const std::string& path, bool recursive = false) {
    if (!lockbox_remove_dir(handle_, path.data(), path.size(), recursive)) throw std::runtime_error(buffer_last_error());
  }
  /** Removes remove. */
  void remove(const std::string& path) {
    if (!lockbox_delete(handle_, path.data(), path.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Stages an atomic move from one Lockbox path to another. */
  void rename(const std::string& from, const std::string& to) {
    if (!lockbox_rename(handle_, from.data(), from.size(), to.data(), to.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Stages a symbolic link with its stored target text. */
  void add_symlink(const std::string& path, const std::string& target, bool replace = false) {
    if (!lockbox_add_symlink(handle_, path.data(), path.size(), target.data(), target.size(), replace)) throw std::runtime_error(buffer_last_error());
  }
  /** Returns the symlink target. */
  std::vector<std::uint8_t> symlink_target(const std::string& path) const {
    return detail::take_bytes(lockbox_get_symlink_target(handle_, path.data(), path.size()));
  }
  /** Reads the requested byte range from a stored file. */
  std::vector<std::uint8_t> read_range(const std::string& path, std::uint64_t offset, std::uint64_t length) const {
    return detail::take_bytes(lockbox_read_range(handle_, path.data(), path.size(), offset, length));
  }
  /** Lists entries below path, optionally including descendants. */
  bindings::LockboxEntryList list(const std::string& path = "/", bool recursive = false) const {
    return decoded<bindings::LockboxEntryList>(lockbox_list(handle_, path.data(), path.size(), recursive));
  }
  /** Returns metadata for the selected lockbox entry. */
  bindings::OptionalLockboxEntry stat(const std::string& path) const {
    return decoded<bindings::OptionalLockboxEntry>(lockbox_stat(handle_, path.data(), path.size()));
  }
  /** Lists entries using glob, type, recursion, and result limit filters. */
  bindings::LockboxEntryList list_with_options(
      const std::string& path, const std::string& glob, bool recursive,
      bool include_files, bool include_symlinks, bool include_directories,
      std::size_t limit) const {
    return decoded<bindings::LockboxEntryList>(lockbox_list_with_options(
        handle_, path.data(), path.size(), glob.data(), glob.size(), recursive,
        include_files, include_symlinks, include_directories, limit));
  }
  /** Reports whether an entry exists at path. */
  bool exists(const std::string& path) const { return lockbox_exists(handle_, path.data(), path.size()); }
  /** Reports whether path names a directory entry. */
  bool is_dir(const std::string& path) const { return lockbox_is_dir(handle_, path.data(), path.size()); }
  /** Returns the portable Unix permission bits stored for path. */
  std::uint32_t permissions(const std::string& path) const { return lockbox_permissions(handle_, path.data(), path.size()); }
  /** Stages portable Unix permission bits for path. */
  void set_permissions(const std::string& path, std::uint32_t value) {
    if (!lockbox_set_permissions(handle_, path.data(), path.size(), value)) throw std::runtime_error(buffer_last_error());
  }
  /** Stages a plain text variable; commit to publish the change. */
  void set_variable(const std::string& name, const std::string& value) {
    if (!lockbox_set_variable(handle_, name.data(), name.size(), value.data(), value.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Sets secret variable. */
  void set_secret_variable(const std::string& name, std::span<const std::uint8_t> value) {
    if (!lockbox_set_secret_variable(handle_, name.data(), name.size(), value.data(), value.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Returns a plain variable when it is present. */
  std::optional<std::string> get_variable(const std::string& name) const {
    return decoded<bindings::OptionalString>(
        lockbox_get_variable(handle_, name.data(), name.size()));
  }
  /** Returns the encrypted lockbox description, or no value when unset.
   * Example lifecycle: set "Production credentials", commit the box, then
   * print the returned description. */
  std::optional<std::string> description() const {
    return get_variable("/.revault/description");
  }
  /** Stages an encrypted lockbox description; call commit to publish it.
   * Example lifecycle: set "Production credentials", then commit the box. */
  void set_description(const std::string& description) {
    set_variable("/.revault/description", description);
  }
  /** Stages removal of the encrypted lockbox description; call commit.
   * Example lifecycle: clear the description, then commit the box. */
  void clear_description() {
    delete_variable("/.revault/description");
  }
  /** Invokes a callback with temporary secret variable bytes, then clears them. */
  bool with_secret_variable(const std::string& name,
      const std::function<void(std::span<const std::uint8_t>)>& callback) const {
    void* secret{};
    if (!lockbox_get_secret_variable(handle_, name.data(), name.size(), &secret))
      throw std::runtime_error(buffer_last_error());
    return detail::with_secret_handle(secret, callback);
  }
  /** Stages removal of a variable. */
  void delete_variable(const std::string& name) {
    if (!lockbox_delete_variable(handle_, name.data(), name.size())) throw std::runtime_error(buffer_last_error());
  }
  /** Updates variables. */
  void move_variables(const bindings::PathMoveList& moves) {
    const auto encoded = detail::encode_moves(moves);
    if (!lockbox_move_variables(handle_, reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Lists variable names and metadata without exposing secret values. */
  bindings::VariableList list_variables() const { return decoded<bindings::VariableList>(lockbox_list_variables(handle_)); }
  /** Returns whether a variable is plain or secret. */
  bindings::OptionalString variable_sensitivity(const std::string& name) const {
    return decoded<bindings::OptionalString>(
        lockbox_variable_sensitivity(handle_, name.data(), name.size()));
  }
  /** Updates import stats. */
  void reset_import_stats() const {
    if (!lockbox_reset_import_stats(handle_)) throw std::runtime_error(buffer_last_error());
  }
  /** Returns cache statistics for this lockbox. */
  bindings::CacheStats cache_stats() const { return decoded<bindings::CacheStats>(lockbox_cache_stats(handle_)); }
  /** Returns import statistics for this lockbox. */
  bindings::ImportStats import_stats() const { return decoded<bindings::ImportStats>(lockbox_import_stats(handle_)); }
  /** Lists public access slot metadata without returning credentials. */
  bindings::KeySlotList list_key_slots() const { return decoded<bindings::KeySlotList>(lockbox_list_key_slots(handle_)); }
  /** Adds a password access slot and returns its slot identifier. */
  std::uint64_t add_password(const std::string& password) {
    auto id = lockbox_add_password(handle_, reinterpret_cast<const std::uint8_t*>(password.data()), password.size());
    if (id == UINT64_MAX) throw std::runtime_error(buffer_last_error());
    return id;
  }
  /** Grants a named contact access and returns the new slot identifier. */
  std::uint64_t add_contact(const ContactPublicKey& contact, const std::string& name) {
    auto id = lockbox_add_contact(handle_, contact.native_handle(), name.data(), name.size());
    if (id == UINT64_MAX) throw std::runtime_error(buffer_last_error());
    return id;
  }
  /** Removes an access slot; at least one usable slot must remain. */
  void delete_key(std::uint64_t id) {
    if (!lockbox_delete_key(handle_, id)) throw std::runtime_error(buffer_last_error());
  }
  /** Returns public signing and ownership metadata for the current revision. */
  bindings::OwnerInspection owner_inspection() const { return decoded<bindings::OwnerInspection>(lockbox_owner_inspection(handle_)); }
  /** Assigns a profile signing key to the Lockbox owner role. */
  void set_owner_signing_key(const ProfileSigningKeyPair& key) {
    if (!lockbox_set_owner_signing_key(handle_, key.native_handle()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Lists logical or physical content chunks for streaming diagnostics. */
  bindings::StreamChunkList stream_content(bool physical = false) const { return decoded<bindings::StreamChunkList>(lockbox_stream_content(handle_, physical)); }
  /** Returns page metadata for diagnostics without exposing plaintext secrets. */
  bindings::PageInspectionList page_inspection() const { return decoded<bindings::PageInspectionList>(lockbox_page_inspection(handle_)); }
  /** Scans the open archive and returns its structured recovery report. */
  bindings::RecoveryReport recovery_report() const { return decoded<bindings::RecoveryReport>(lockbox_recovery_report(handle_)); }
  /** Returns the cache, workload, and worker settings used by this Lockbox. */
  bindings::RuntimeOptions runtime_options() const { return decoded<bindings::RuntimeOptions>(lockbox_runtime_options(handle_)); }
  /** Serializes the current Lockbox, including committed changes. */
  std::vector<std::uint8_t> to_bytes() const { return detail::take_bytes(lockbox_to_bytes(handle_)); }

  /** Defines and stores a reusable versioned form. */
  bindings::FormDefinition define_form(const std::string& alias,
                                       const std::string& name,
                                       const std::string& description,
                                       const bindings::FormFieldList& fields) {
    const std::string encoded = detail::encode_fields(fields);
    return decoded<bindings::FormDefinition>(lockbox_define_form(
        handle_, alias.data(), alias.size(), name.data(), name.size(),
        description.data(), description.size(),
        reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()));
  }
  /** Lists the form definitions stored in this Lockbox. */
  bindings::FormDefinitionList list_form_definitions() const {
    return decoded<bindings::FormDefinitionList>(lockbox_list_form_definitions(handle_));
  }
  /** Resolves a form alias, type identifier, or revision. */
  bindings::FormDefinition resolve_form(const std::string& reference) const {
    return decoded<bindings::FormDefinition>(
        lockbox_resolve_form(handle_, reference.data(), reference.size()));
  }
  /** Lists every stored revision for a form type identifier. */
  bindings::FormDefinitionList list_form_revisions(const std::string& type_id) const {
    return decoded<bindings::FormDefinitionList>(
        lockbox_list_form_revisions(handle_, type_id.data(), type_id.size()));
  }
  /** Stages a form record at path using the referenced definition. */
  bindings::FormRecord create_form_record(const std::string& path,
                                          const std::string& type_reference,
                                          const std::string& name) {
    return decoded<bindings::FormRecord>(lockbox_create_form_record(
        handle_, path.data(), path.size(), type_reference.data(), type_reference.size(),
        name.data(), name.size()));
  }
  /** Stages a plain field value in a form record. */
  void set_form_field(const std::string& path, const std::string& field,
                      const std::string& value) {
    if (!lockbox_set_form_field(handle_, path.data(), path.size(), field.data(), field.size(),
                                value.data(), value.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Sets secret form field. */
  void set_secret_form_field(const std::string& path, const std::string& field,
                             std::span<const std::uint8_t> value) {
    if (!lockbox_set_secret_form_field(handle_, path.data(), path.size(), field.data(), field.size(),
                                       value.data(), value.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Lists form records without exposing secret field values. */
  bindings::FormRecordList list_form_records() const {
    return decoded<bindings::FormRecordList>(lockbox_list_form_records(handle_));
  }
  /** Returns the form record at path when present. */
  bindings::OptionalFormRecord get_form_record(const std::string& path) const {
    return decoded<bindings::OptionalFormRecord>(
        lockbox_get_form_record(handle_, path.data(), path.size()));
  }
  /** Stages removal of a form record. */
  void delete_form_record(const std::string& path) {
    if (!lockbox_delete_form_record(handle_, path.data(), path.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Updates form records. */
  void move_form_records(const bindings::PathMoveList& moves) {
    const auto encoded = detail::encode_moves(moves);
    if (!lockbox_move_form_records(handle_, reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Returns a plain form field when it exists. */
  bindings::OptionalFormValue get_form_field(const std::string& path,
                                             const std::string& field) const {
    return decoded<bindings::OptionalFormValue>(lockbox_get_form_field(
        handle_, path.data(), path.size(), field.data(), field.size()));
  }
  /** Invokes a callback with temporary secret field bytes, then clears them. */
  bool with_secret_form_field(const std::string& path, const std::string& field,
      const std::function<void(std::span<const std::uint8_t>)>& callback) const {
    void* secret{};
    if (!lockbox_get_secret_form_field(handle_, path.data(), path.size(), field.data(), field.size(), &secret))
      throw std::runtime_error(buffer_last_error());
    return detail::with_secret_handle(secret, callback);
  }
  /** Sets workload profile. */
  void set_workload_profile(const std::string& profile) {
    if (!lockbox_set_workload_profile(handle_, profile.data(), profile.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Sets a soft cache limit (auto, disabled, or bytes). */
  void set_cache_limit(const std::string& mode, std::uint64_t bytes = 0) {
    if (!lockbox_set_cache_limit(handle_, mode.data(), mode.size(), bytes))
      throw std::runtime_error(buffer_last_error());
  }
  /** Sets worker policy. */
  void set_worker_policy(const std::string& mode, std::size_t jobs = 0) {
    if (!lockbox_set_worker_policy(handle_, mode.data(), mode.size(), jobs))
      throw std::runtime_error(buffer_last_error());
  }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }

 private:
  explicit Lockbox(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  static Lockbox adopt(void* handle) { return Lockbox(handle); }
  static detail::Buffer checked(RevaultBuffer result) {
    if (!result.ptr) throw std::runtime_error(buffer_last_error());
    return detail::Buffer(result);
  }
  template <typename Message>
  static Message decoded(RevaultBuffer result) {
    detail::Buffer owned = checked(result);
    return detail::decode<Message>({owned.data(), owned.size()});
  }
  void* handle_;
};

/** A writable, password-protected store for Profile keys, contacts, forms,
 * backups, and remembered lockbox paths; lockbox contents remain separate. */
class Vault {
 public:
  /** Returns the current structure version. */
  static std::uint32_t current_structure_version() { return vault_structure_version_current(); }
  /** Determines structure version without fully opening it. */
  static std::uint32_t probe_structure_version(const std::string& root, const std::string& password) {
    const auto value = vault_directory_probe_structure_version(
        root.data(), root.size(), reinterpret_cast<const std::uint8_t*>(password.data()), password.size());
    if (!value) throw std::runtime_error(buffer_last_error());
    return value;
  }
  /** Opens an existing lockbox. */
  static Vault open(const std::string& root, const std::string& password) {
    return adopt(vault_directory_open(
        root.data(), root.size(), reinterpret_cast<const std::uint8_t*>(password.data()),
        password.size()));
  }
  /** Opens or create. */
  static Vault open_or_create(const std::string& root,
                                       const std::string& password) {
    return adopt(vault_directory_open_or_create(
        root.data(), root.size(), reinterpret_cast<const std::uint8_t*>(password.data()),
        password.size()));
  }
  /** Updates replace. */
  static Vault replace(const std::string& root, const std::string& password) {
    return adopt(vault_directory_replace(
        root.data(), root.size(), reinterpret_cast<const std::uint8_t*>(password.data()),
        password.size()));
  }
  /** Opens or create default. */
  static Vault open_or_create_default(const std::string& password) {
    return adopt(vault_directory_open_or_create_default(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Updates default. */
  static Vault replace_default(const std::string& password) {
    return adopt(vault_directory_replace_default(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Updates password. */
  static void change_password(const std::string& root, const std::string& old_password,
                              const std::string& new_password) {
    if (!vault_directory_change_password(
            root.data(), root.size(),
            reinterpret_cast<const std::uint8_t*>(old_password.data()), old_password.size(),
            reinterpret_cast<const std::uint8_t*>(new_password.data()), new_password.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Updates default password. */
  static void change_default_password(const std::string& old_password,
                                      const std::string& new_password) {
    if (!vault_directory_change_default_password(
            reinterpret_cast<const std::uint8_t*>(old_password.data()), old_password.size(),
            reinterpret_cast<const std::uint8_t*>(new_password.data()), new_password.size()))
      throw std::runtime_error(buffer_last_error());
  }
  /** Returns the default directory. */
  static std::string default_directory() { return detail::take_string(vault_default_directory()); }
  /** Returns the default path. */
  static std::string default_path() { return detail::take_string(vault_default_path()); }
  /** Returns the backup default. */
  static bindings::VaultBackupManifest backup_default(const std::string& path,
                                                       bool overwrite = false) {
    return detail::take_message<bindings::VaultBackupManifest>(
        vault_backup_default(path.data(), path.size(), overwrite));
  }
  /** Returns the restore default. */
  static bindings::VaultBackupManifest restore_default(const std::string& path,
                                                        bool overwrite = false) {
    return detail::take_message<bindings::VaultBackupManifest>(
        vault_restore_default(path.data(), path.size(), overwrite));
  }

  /** Returns the vault directory. */
  Vault(const Vault&) = delete;
  /** Returns the operator. */
  Vault& operator=(const Vault&) = delete;
  /** Returns the vault directory. */
  Vault(Vault&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the operator. */
  Vault& operator=(Vault&& other) noexcept {
    if (this != &other) {
      if (handle_) vault_directory_free(handle_);
      handle_ = other.handle_;
      other.handle_ = nullptr;
    }
    return *this;
  }
  /** Returns the vault directory. */
  ~Vault() { if (handle_) vault_directory_free(handle_); }

  /** Returns the canonical root directory of this Vault. */
  std::string root() const { return detail::take_string(vault_directory_root(handle_)); }
  /** Returns the persistent structure version of this Vault. */
  std::uint32_t structure_version() const { return vault_directory_structure_version(handle_); }
  /** Lists private keys. */
  bindings::StringList list_private_keys() const {
    return detail::take_message<bindings::StringList>(vault_directory_list_private_keys(handle_));
  }
  /** Lists private key names. */
  bindings::StringList list_private_key_names() const {
    return detail::take_message<bindings::StringList>(vault_directory_list_private_key_names(handle_));
  }
  /** Lists contact names. */
  bindings::StringList list_contact_names() const {
    return detail::take_message<bindings::StringList>(vault_directory_list_contact_names(handle_));
  }
  /** Lists form aliases. */
  bindings::StringList list_form_aliases() const {
    return detail::take_message<bindings::StringList>(vault_directory_list_form_aliases(handle_));
  }
  /** Reports whether the named profile private key exists. */
  bool private_key_exists(const std::string& name) const {
    return vault_directory_private_key_exists(handle_, name.data(), name.size());
  }
  /** Removes private key. */
  void delete_private_key(const std::string& name) const {
    checked(vault_directory_delete_private_key(handle_, name.data(), name.size()));
  }
  /** Stores private key. */
  void store_private_key(const std::string& name, const ContactKeyPair& key) const {
    checked(vault_directory_store_private_key(
        handle_, name.data(), name.size(), key.native_handle()));
  }
  /** Loads private key. */
  ContactKeyPair load_private_key(const std::string& name) const {
    return ContactKeyPair(vault_directory_load_private_key(handle_, name.data(), name.size()));
  }
  /** Loads private key generation. */
  ContactKeyPair load_private_key_generation(const std::string& name,
                                             std::uint16_t index) const {
    return ContactKeyPair(vault_directory_load_private_key_generation(
        handle_, name.data(), name.size(), index));
  }
  /** Stores contact. */
  void store_contact(const std::string& name, const ContactPublicKey& key) const {
    checked(vault_directory_store_contact(
        handle_, name.data(), name.size(), key.native_handle()));
  }
  /** Loads contact. */
  ContactPublicKey load_contact(const std::string& name) const {
    return ContactPublicKey(vault_directory_load_contact(handle_, name.data(), name.size()));
  }
  /** Reports whether the named contact exists. */
  bool contact_exists(const std::string& name) const {
    return vault_directory_contact_exists(handle_, name.data(), name.size());
  }
  /** Removes contact. */
  void delete_contact(const std::string& name) const {
    checked(vault_directory_delete_contact(handle_, name.data(), name.size()));
  }
  /** Lists contacts. */
  bindings::ContactList list_contacts() const {
    return detail::take_message<bindings::ContactList>(vault_directory_list_contacts(handle_));
  }
  /** Stores profile email. */
  void store_profile_email(const std::string& name, const std::string& email) const {
    checked(vault_directory_store_profile_email(
        handle_, name.data(), name.size(), email.data(), email.size()));
  }
  /** Returns the email recorded for a profile, when present. */
  bindings::OptionalString profile_email(const std::string& name) const {
    return detail::take_message<bindings::OptionalString>(
        vault_directory_profile_email(handle_, name.data(), name.size()));
  }
  /** Stores backup. */
  void store_backup(const std::vector<std::uint8_t>& id,
                    const std::vector<std::uint8_t>& bytes) const {
    checked(vault_directory_store_backup(
        handle_, id.data(), id.size(), bytes.data(), bytes.size()));
  }
  /** Loads backup. */
  std::vector<std::uint8_t> load_backup(const std::vector<std::uint8_t>& id) const {
    return detail::take_bytes(vault_directory_load_backup(handle_, id.data(), id.size()));
  }
  /** Returns the number of stored key recovery backups. */
  std::uint64_t backup_count() const { return vault_directory_backup_count(handle_); }
  /** Restores a profile private key and signing key from recovery material. */
  void restore_private_key(const std::string& name, const ContactKeyPair& key,
                           const ProfileSigningKeyPair& signing_key, bool overwrite = false) const {
    checked(vault_directory_restore_private_key(
        handle_, name.data(), name.size(), key.native_handle(),
        signing_key.native_handle(), overwrite));
  }
  /** Loads the current signing identity for a profile. */
  ProfileSigningKeyPair load_profile_signing_key(const std::string& name) const {
    return ProfileSigningKeyPair(vault_directory_load_owner_signing_key(
        handle_, name.data(), name.size()));
  }
  /** Loads a historical signing-key generation for a profile. */
  ProfileSigningKeyPair load_profile_signing_key_generation(
      const std::string& name, std::uint16_t index) const {
    return ProfileSigningKeyPair(vault_directory_load_owner_signing_key_generation(
        handle_, name.data(), name.size(), index));
  }
  /** Stores contact signing key. */
  void store_contact_signing_key(const std::string& name,
                                 const ProfileSigningPublicKey& key) const {
    checked(vault_directory_store_contact_signing_key(
        handle_, name.data(), name.size(), key.native_handle()));
  }
  /** Loads contact signing key. */
  ProfileSigningPublicKey load_contact_signing_key(const std::string& name) const {
    return ProfileSigningPublicKey(vault_directory_load_contact_signing_key(
        handle_, name.data(), name.size()));
  }
  /** Lists profile generations. */
  bindings::ProfileHistory list_profile_generations(const std::string& name) const {
    return detail::take_message<bindings::ProfileHistory>(
        vault_directory_list_profile_generations(handle_, name.data(), name.size()));
  }
  /** Updates private key. */
  bindings::ProfileHistory rotate_private_key(const std::string& name) const {
    return detail::take_message<bindings::ProfileHistory>(
        vault_directory_rotate_private_key(handle_, name.data(), name.size()));
  }
  /** Stores lockbox. */
  void remember_lockbox(const std::vector<std::uint8_t>& id,
                        const std::string& path) const {
    checked(vault_directory_remember_lockbox(
        handle_, id.data(), id.size(), path.data(), path.size()));
  }
  /** Lists known lockboxes. */
  bindings::KnownLockboxList list_known_lockboxes() const {
    return detail::take_message<bindings::KnownLockboxList>(
        vault_directory_list_known_lockboxes(handle_));
  }
  /** Removes lockbox. */
  void forget_lockbox(const std::string& path) const {
    checked(vault_directory_forget_lockbox(handle_, path.data(), path.size()));
  }
  /** Stores access slot label. */
  void remember_access_slot_label(const std::vector<std::uint8_t>& id,
                             std::uint64_t slot_id, const std::string& name) const {
    checked(vault_directory_remember_access_slot_label(
        handle_, id.data(), id.size(), slot_id, name.data(), name.size()));
  }
  /** Lists access slot labels. */
  bindings::AccessSlotLabelList list_access_slot_labels(
      const std::vector<std::uint8_t>& id) const {
    return detail::take_message<bindings::AccessSlotLabelList>(
        vault_directory_list_access_slot_labels(handle_, id.data(), id.size()));
  }
  /** Finds access slot labels with the supplied name for one Lockbox. */
  bindings::AccessSlotLabelList find_access_slot_labels(
      const std::vector<std::uint8_t>& id, const std::string& name) const {
    return detail::take_message<bindings::AccessSlotLabelList>(vault_directory_find_access_slot_labels(
        handle_, id.data(), id.size(), name.data(), name.size()));
  }
  /** Removes access slot label. */
  void forget_access_slot_label(const std::vector<std::uint8_t>& id,
                           std::uint64_t slot_id) const {
    checked(vault_directory_forget_access_slot_label(handle_, id.data(), id.size(), slot_id));
  }
  /** Defines and stores a reusable versioned form. */
  bindings::FormDefinition define_form(const std::string& alias,
                                       const std::string& name,
                                       const std::string& description,
                                       const bindings::FormFieldList& fields) const {
    const std::string encoded = detail::encode_fields(fields);
    return detail::take_message<bindings::FormDefinition>(vault_directory_define_form(
        handle_, alias.data(), alias.size(), name.data(), name.size(),
        description.data(), description.size(),
        reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()));
  }
  /** Resolves a form alias, type identifier, or revision. */
  bindings::FormDefinition resolve_form(const std::string& reference) const {
    return detail::take_message<bindings::FormDefinition>(
        vault_directory_resolve_form(handle_, reference.data(), reference.size()));
  }
  /** Lists forms. */
  bindings::FormDefinitionList list_forms() const {
    return detail::take_message<bindings::FormDefinitionList>(vault_directory_list_forms(handle_));
  }
  /** Lists every stored revision for a form type identifier. */
  bindings::FormDefinitionList list_form_revisions(const std::string& type_id) const {
    return detail::take_message<bindings::FormDefinitionList>(
        vault_directory_list_form_revisions(handle_, type_id.data(), type_id.size()));
  }
  /** Adds missing standard form definitions and returns the number added. */
  std::size_t seed_forms() const { return vault_directory_seed_forms(handle_); }
  /** Stores password. */
  void remember_password(const std::vector<std::uint8_t>& id,
                         const std::string& password) const {
    checked(vault_directory_remember_password(
        handle_, id.data(), id.size(),
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Returns the Lockbox password encrypted inside this Vault. */
  std::vector<std::uint8_t> remembered_password(
      const std::vector<std::uint8_t>& id) const {
    return detail::take_bytes(vault_directory_remembered_password(handle_, id.data(), id.size()));
  }
  /** Returns the native handle. */
  void* native_handle() const { return handle_; }

 private:
  explicit Vault(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  static Vault adopt(void* handle) { return Vault(handle); }
  static void checked(bool result) {
    if (!result) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** A restricted metadata view for discovery or diagnostics without loading an
 * owner signing key or exposing mutation operations. */
class ReadOnlyVault {
 public:
  /** Returns only vault directory. */
  ReadOnlyVault(const std::string& root, const std::string& password)
      : handle_(vault_read_only_open(root.data(), root.size(),
          reinterpret_cast<const std::uint8_t*>(password.data()), password.size())) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  /** Opens default. */
  static ReadOnlyVault open_default(const std::string& password) {
    return ReadOnlyVault(vault_read_only_open_default(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Returns only vault directory. */
  ReadOnlyVault(const ReadOnlyVault&) = delete;
  /** Returns only vault directory. */
  ReadOnlyVault(ReadOnlyVault&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns only vault directory. */
  ~ReadOnlyVault() { if (handle_) vault_read_only_free(handle_); }
  /** Lists profile names. */
  bindings::StringList list_profile_names() const { return detail::take_message<bindings::StringList>(vault_read_only_list_profile_names(handle_)); }
  /** Lists contact names. */
  bindings::StringList list_contact_names() const { return detail::take_message<bindings::StringList>(vault_read_only_list_contact_names(handle_)); }
  /** Lists form aliases. */
  bindings::StringList list_form_aliases() const { return detail::take_message<bindings::StringList>(vault_read_only_list_form_aliases(handle_)); }
  /** Lists known lockboxes. */
  bindings::KnownLockboxList list_known_lockboxes() const { return detail::take_message<bindings::KnownLockboxList>(vault_read_only_list_known_lockboxes(handle_)); }
 private:
  explicit ReadOnlyVault(void* handle) : handle_(handle) { if (!handle_) throw std::runtime_error(buffer_last_error()); }
  void* handle_{};
};

/** Canonical formatting and parsing helpers for public key material. */
class KeyFormat {
 public:
  /** Returns the stable fingerprint of this key. */
  static std::vector<std::uint8_t> fingerprint(const ContactPublicKey& key) {
    return key.fingerprint();
  }
  /** Returns the hex. */
  static std::string hex(const std::vector<std::uint8_t>& bytes) {
    return detail::take_string(vault_key_format_hex(bytes.data(), bytes.size()));
  }
  /** Decodes hex. */
  static std::vector<std::uint8_t> decode_hex(const std::string& text) {
    return detail::take_bytes(vault_key_decode_hex(text.data(), text.size()));
  }
  /** Returns the crockford. */
  static std::string crockford(const std::vector<std::uint8_t>& bytes) {
    return detail::take_string(vault_key_format_crockford(bytes.data(), bytes.size()));
  }
  /** Returns the crockford reading. */
  static std::string crockford_reading(const std::string& code) {
    return detail::take_string(vault_key_format_crockford_reading(code.data(), code.size()));
  }
  /** Decodes crockford. */
  static std::vector<std::uint8_t> decode_crockford(const std::string& code) {
    return detail::take_bytes(vault_key_decode_crockford(code.data(), code.size()));
  }
  /** Returns the hex encode. */
  static std::string hex_encode(const std::vector<std::uint8_t>& bytes) {
    return detail::take_string(vault_key_hex_encode(bytes.data(), bytes.size()));
  }
  /** Returns the hex decode. */
  static std::vector<std::uint8_t> hex_decode(const std::string& text) {
    return detail::take_bytes(vault_key_hex_decode(text.data(), text.size()));
  }
};

/** A lifetime token kept alive while an operation needs cached secrets; destroy
 * it afterward so the Session Agent can expire unused secrets. */
class AgentActivity {
 public:
  /** Returns the agent activity. */
  AgentActivity(const AgentActivity&) = delete;
  /** Returns the operator. */
  AgentActivity& operator=(const AgentActivity&) = delete;
  /** Returns the agent activity. */
  AgentActivity(AgentActivity&& other) noexcept : handle_(other.handle_) { other.handle_ = nullptr; }
  /** Returns the agent activity. */
  ~AgentActivity() { if (handle_) vault_agent_end_activity(handle_); }
  /** Stops end. */
  void end() {
    if (handle_) {
      vault_agent_end_activity(handle_);
      handle_ = nullptr;
    }
  }
 private:
  friend class AgentSession;
  explicit AgentActivity(void* handle) : handle_(handle) {
    if (!handle_) throw std::runtime_error(buffer_last_error());
  }
  void* handle_{};
};

/** Explicit client for the session service that temporarily caches vault
 * unlock keys and selected profile signing keys across operations. */
class AgentSession {
 public:
  /** Starts start. */
  static void start() { checked(vault_agent_start()); }
  /** Reports whether running. */
  static bool is_running() { return vault_is_running(); }
  /** Runs the session agent server until it is stopped. */
  static void serve() { checked(vault_agent_serve()); }
  /** Verifies transport. */
  static void verify_transport() { checked(vault_agent_verify_transport()); }
  /** Removes all. */
  static void forget_all() { checked(vault_forget_all()); }
  /** Stops stop. */
  static void stop() { checked(vault_agent_stop()); }
  /** Stores put. */
  static void put(const std::vector<std::uint8_t>& id,
                  const std::vector<std::uint8_t>& key) {
    checked(vault_agent_put(id.data(), id.size(), key.data(), key.size()));
  }
  /** Returns get. */
  static std::vector<std::uint8_t> get(const std::vector<std::uint8_t>& id) {
    return detail::take_bytes(vault_agent_get(id.data(), id.size()));
  }
  /** Removes forget. */
  static void forget(const std::vector<std::uint8_t>& id) {
    checked(vault_agent_forget(id.data(), id.size()));
  }
  /** Lists entries below path, optionally including descendants. */
  static bindings::AgentEntryList list() {
    return detail::take_message<bindings::AgentEntryList>(vault_agent_list());
  }
  /** Reports how the platform handles agent expiry during system sleep. */
  static bindings::SleepSupport sleep_support() {
    return detail::take_message<bindings::SleepSupport>(vault_agent_sleep_support());
  }
  /** Returns the log path. */
  static std::string log_path() { return detail::take_string(vault_agent_log_path()); }
  /** Returns the log destination. */
  static std::string log_destination() { return detail::take_string(vault_agent_log_destination()); }
  /** Stores vault unlock key. */
  static void put_vault_unlock_key(const std::string& profile,
                            const std::vector<std::uint8_t>& key,
                            std::uint64_t ttl_seconds) {
    checked(vault_agent_put_vault_unlock_key(profile.data(), profile.size(), key.data(),
                                      key.size(), ttl_seconds));
  }
  /** Returns vault unlock key. */
  static std::vector<std::uint8_t> get_vault_unlock_key(const std::string& profile) {
    return detail::take_bytes(vault_agent_get_vault_unlock_key(profile.data(), profile.size()));
  }
  /** Removes vault unlock key. */
  static void forget_vault_unlock_key(const std::string& profile) {
    checked(vault_agent_forget_vault_unlock_key(profile.data(), profile.size()));
  }
  /** Caches a profile signing key for the selected session duration. */
  static void cache_profile_signing_key(const std::string& vault_id,
                                        const std::string& profile,
                                        const ProfileSigningKeyPair& key,
                                        std::uint64_t ttl_seconds) {
    checked(vault_agent_put_owner_signing_key(
        vault_id.data(), vault_id.size(), profile.data(), profile.size(),
        key.native_handle(), ttl_seconds));
  }
  /** Retrieves a cached profile signing key, if present. */
  static ProfileSigningKeyPair profile_signing_key(
      const std::string& vault_id, const std::string& profile) {
    return ProfileSigningKeyPair(vault_agent_get_owner_signing_key(
        vault_id.data(), vault_id.size(), profile.data(), profile.size()));
  }
  /** Forgets a cached profile signing key. */
  static void forget_profile_signing_key(const std::string& vault_id,
                                         const std::string& profile) {
    checked(vault_agent_forget_owner_signing_key(
        vault_id.data(), vault_id.size(), profile.data(), profile.size()));
  }
  /** Retains a Lockbox password in the optional Session Agent for a bounded
   * duration. This is independent of any Lockbox handle. */
  static void cache_lockbox_password(const std::string& path,
                                     const std::string& lockbox_password,
                                     std::uint64_t ttl_seconds) {
    detail::VaultIntegrationHandle vault;
    checked(vault_cache_lockbox_password(
        vault.get(), path.data(), path.size(),
        reinterpret_cast<const std::uint8_t*>(lockbox_password.data()),
        lockbox_password.size(), ttl_seconds));
  }
  /** Forgets one lockbox key retained by the Session Agent. */
  static void close_lockbox(const std::string& path) {
    detail::VaultIntegrationHandle vault;
    checked(vault_close_lockbox(vault.get(), path.data(), path.size()));
  }
  /** Forgets all lockbox keys retained by the Session Agent. */
  static void close_all() {
    detail::VaultIntegrationHandle vault;
    checked(vault_close_all(vault.get()));
  }
  /** Starts activity. */
  static AgentActivity begin_activity(const std::string& kind) {
    return AgentActivity(vault_agent_begin_activity(kind.data(), kind.size()));
  }
 private:
  static void checked(bool result) {
    if (!result) throw std::runtime_error(buffer_last_error());
  }
};

/** Access to the platform credential store for a scoped Vault passphrase. */
class PlatformSecretStore {
 public:
  /** Returns availability and user presence guarantees for platform storage. */
  static bindings::PlatformStatus status() {
    return detail::take_message<bindings::PlatformStatus>(vault_platform_status());
  }
  /** Sets scope. */
  static void set_scope(const std::string& scope) {
    checked(vault_platform_set_scope(scope.data(), scope.size()));
  }
  /** Enables storage of the Vault passphrase in platform credentials. */
  static void enable() { checked(vault_platform_enable()); }
  /** Disables platform credential use without deleting the stored value. */
  static void disable() { checked(vault_platform_disable()); }
  /** Reports whether platform credential use is disabled. */
  static bool disabled() { return vault_platform_disabled(); }
  /** Stores password. */
  static void put_password(const std::string& password) {
    checked(vault_platform_put_password(
        reinterpret_cast<const std::uint8_t*>(password.data()), password.size()));
  }
  /** Returns password. */
  static std::string get_password() { return detail::take_string(vault_platform_get_password()); }
  /** Removes password. */
  static void forget_password() { checked(vault_platform_forget_password()); }
 private:
  static void checked(bool result) {
    if (!result) throw std::runtime_error(buffer_last_error());
  }
};

}  // namespace revault
