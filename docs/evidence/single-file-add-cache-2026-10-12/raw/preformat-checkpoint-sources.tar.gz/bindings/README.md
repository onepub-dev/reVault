# reVault language bindings

The native bindings are intentionally based on one C ABI. Build the internal
`revault_bindings` Rust crate from `rust/` and use
`rust/revault_bindings/revault_api.h` with
Dart FFI, Java 22+ Foreign Function & Memory, or Python `ctypes`.

Symbols use descriptive namespaces: `lockbox_*`, `vault_*`, `key_*`, and
`buffer_*`. The Rust crate names remain `revault_lockbox_api` and
`revault_vault_api`.

The ABI covers lockbox data and metadata operations, key management, recovery,
Vault directories, Vault integration, Session Agent controls, platform
credential store controls, key formatting, and explicit buffer and handle
ownership.
Structured responses use the private FlatBuffers schema in
`bindings/flatbuffers`. Each language facade retains the returned buffer and
exposes reVault domain objects; generated transport tables are not public API.
File contents and cryptographic material remain raw bytes.

Every public facade method has a contextual worked example. See
[`API_EXAMPLES.md`](API_EXAMPLES.md) for the shared documentation contract,
the canonical lifecycle, and links to the native-language examples and
executable conformance runners.
The hosted WebAssembly package runs every API call through a real WASM
dispatcher and uses its Node host adapter for filesystem, Vault, platform
credential store, and Session Agent facilities. The standalone browser module
retains portable Lockbox and key operations, but browser execution does not
provide the complete API because browsers cannot provide Vault directories, a
platform credential store, or a Session Agent process.

The optional `revault_lockbox_api` `external-source` feature is a Rust embedding
API, including custom WASM wrappers. It does not add C ABI operations or change
the generated language facades. See [external byte sources](../manual/develop-with-revault/external-sources.md)
for supported modes, transport requirements and retry limits.

## Language targets

The native ABI and private FlatBuffers schema are the common contract for the
selected issue-189 targets:

| Target | Binding location |
| --- | --- |
| JavaScript / TypeScript | `bindings/javascript` (one public package); `bindings/typescript` is its private compile-time conformance consumer |
| Python | `bindings/python` |
| Java / Kotlin | `bindings/java`, `bindings/kotlin` |
| C# | `bindings/csharp` |
| C++ / C | `bindings/cpp`, `bindings/c` |
| PHP | `bindings/php` |
| Go | `bindings/go` |
| Rust | `bindings/rust` |
| Lua | `bindings/lua` |
| Ruby | `bindings/ruby` |
| Dart | `bindings/dart` |
| Swift | `bindings/swift` |
| WebAssembly | `bindings/wasm`, `rust/revault_wasm_bindings` |

The checked-in binding surfaces and private transport models are validated or regenerated
through the Rust tool:

```text
cargo run --locked -p revault_tooling --bin revault-tool -- bindings check
cargo run --locked -p revault_tooling --bin revault-tool -- bindings generate-flatbuffers
```

Full transport regeneration requires `flatc` 25.2.10 on `PATH`. Generated
files live only in internal package locations; Ruby, Lua, and C use small
private readers because the official compiler does not provide a suitable
generator for those targets.

The generated declaration surface covers all 221 exported C ABI functions:
the ABI-version query plus 220 domain functions. C++, C, PHP, Swift, Lua, and Ruby
consume the header or the complete native symbol table directly; Java/Kotlin
use the generated Java FFM method-handle surface and typed facade.
The generated low-level surfaces are intentionally separate from the typed
facades so new ABI additions cannot silently disappear from a target.

Semantic parity is checked separately from symbol parity. The review in
`api/rust-to-abi.tsv` maps public Rust operations to one or more ABI operations;
`api/rust-only-exclusions.tsv` records the small set of Rust ownership,
migration, raw-key security, and language-native value helpers that do not cross an FFI boundary,
with a rationale for each. The binding check scans both public Rust crates and
fails when a newly public function has not been reviewed.

Secret variable and form-field reads use opaque native secret handles and are
exposed by each facade only through a scoped callback. All native result buffers
are wiped by `buffer_free`; callers that request exportable private-key or agent
bytes still own and must clear the resulting language-managed byte array.

The acceptance contract for language-level archive/vault interoperability is
defined in [`e2e/CONFORMANCE.md`](e2e/CONFORMANCE.md). Language runners must
execute that contract; symbol coverage and syntax checks are not substitutes
for e2e coverage.

## Distribution and publication

For a concise language-to-registry reference, see
[`PACKAGE_MANAGERS.md`](PACKAGE_MANAGERS.md).

All foreign-language packages use the same versioned C ABI library. Canonical
native archives contain the dynamic and static libraries, the Windows DLL
import library where applicable, the target-built Ruby ABI adapter, C header,
private FlatBuffers schema, license, target
metadata, SPDX SBOM, and SHA-256 sidecar. Linux requires
the system `libdbus-1` runtime; macOS and Windows use their native platform credential store
implementations. A package must never select an artifact for another operating
system, architecture, C runtime, or ABI. Dynamic-language loaders resolve an
explicit API path, then a non-empty inherited `REVAULT_LIBRARY`, then their
packaged carrier. Package acceptance deliberately unsets the override to prove
the final branch; separate loader tests cover the explicit, environment, and
OS-search-path branches without moving native files. Link-time APIs use their
language's normal linker/package mechanisms and do not emulate a runtime path
argument. The source-native Rust and WebAssembly APIs do not load the C ABI.

| API | Public endpoint | Native delivery |
| --- | --- | --- |
| JavaScript and TypeScript | npm `@onepub-dev/revault-api` | optional `@onepub-dev/revault-api-native-<target>` carrier |
| WebAssembly | npm `@onepub-dev/revault-api-wasm` | bundled WASM and installed native host carrier |
| Python | PyPI `revault-api` | one wheel per platform tag |
| Java | Maven Central `dev.onepub:revault-api` | native resources extracted by the loader |
| Kotlin | Maven Central `dev.onepub:revault-api-kotlin` | Java runtime artifact dependency |
| C# | NuGet `Revault.Api` | `runtimes/<rid>/native` assets |
| Dart | pub.dev `revault_api` | checked native assets selected by `Revault.load()` |
| Ruby | RubyGems `revault_api` | platform-specific gems |
| PHP | Packagist `onepub/revault-api` | Composer package containing checked native assets |
| Lua | LuaRocks `revault_api` | platform rocks containing checked native assets |
| Go | `github.com/onepub-dev/revault-api` | statically linked packaged native libraries |
| Rust | crates.io `revault-api` | native Rust source; no C ABI dependency |
| Swift | `onepub-dev/revault-swift`, product `RevaultAPI` | macOS XCFramework or Linux native package |
| C | GitHub Releases, vcpkg, Homebrew, Debian and RPM | canonical SDK archive and `revault_api.h` |
| C++ | ConanCenter, vcpkg, Homebrew, Debian and RPM | class facade over the canonical C ABI |

The six canonical targets are Linux glibc x86-64/ARM64, macOS x86-64/ARM64,
and Windows MSVC x86-64/ARM64. Registry credentials are release authority and
must use trusted publishing/OIDC where available, otherwise environment-scoped
least-privilege secrets. Credentials are never committed.

### Rust release tooling

All repository-owned generation, validation, packaging, installation, and
publication automation is exposed by the unpublished Rust workspace binary:

```text
cargo run --locked -p revault_tooling --bin revault-tool -- --help
```

Package-manager recipes such as `conanfile.py`, formula templates, gemspecs,
rockspecs, and CMake files remain in their ecosystem-required formats; they are
inputs consumed by the Rust tool rather than release scripts.

### Release acceptance and order

1. Build release-mode native libraries for all six targets and create immutable,
   deterministic native archives with `revault-tool release package-native`.
2. Verify and securely unpack those archives, then stage and assemble every
   ecosystem package exclusively from them.
3. Install every claimed language/target package in a clean GitHub Actions
   consumer with no build tree or native-library override. The test must record
   the installed native path and archive hash before exercising all 220 calls.
   Rust is the explicit source-native exception: its consumer runs the complete
   `public_api_suite` and `vault_api` suites after `cargo package`, securely
   unpacks the `.crate` into a clean consumer, and records that archive's hash;
   it never substitutes the C conformance executable or claims a native-library
   installation.
4. Run the canonical Linux x86-64 all-pairs matrix: each of sixteen consumers
   opens the archive and vault from every other producer (480 directed paths).
5. Attest the accepted artifacts, publish native carriers first, language
   facades second, and hosted WASM last. Registry publication is never used as
   a substitute for pre-publication package installation tests.

The full claimed package matrix contains 94 combinations: every language on
all six native targets except Swift's two unclaimed Windows targets. A missing
runtime or preview runner blocks publication; it is not converted to a skip or
ABI-only smoke test. The detailed operation contract is in
[`e2e/CONFORMANCE.md`](e2e/CONFORMANCE.md).

Registry setup references: [npm](https://docs.npmjs.com/creating-and-publishing-scoped-public-packages/),
[Python wheels](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/),
[Maven Central](https://central.sonatype.org/publish/publish-portal-guide/),
[Dart](https://dart.dev/tools/pub/publishing),
[RubyGems](https://guides.rubygems.org/publishing/),
[Go modules](https://go.dev/doc/modules/publishing),
[crates.io](https://doc.rust-lang.org/cargo/reference/publishing.html), and
[ConanCenter](https://docs.conan.io/2/devops/using_conancenter.html).

### Registry authorization and first release

The public name is `revault-api`, adapted only where a registry requires a
different spelling or namespace (`revault_api`, `Revault.Api`,
`dev.onepub:revault-api`, or `@onepub-dev/revault-api`). Publication runs only for
an accepted `revault-api-vX.Y.Z` tag after the native archives and registry
package layouts have been built. The 94 installed-package checks and the
480-path interoperability suite are hard release gates. Native archives,
registry packages, and promotion jobs are not published until both suites
pass. The release workflow also uses the protected GitHub environment
`release`.

The tag or manual workflow input is the single release-version source. Package
assembly rewrites every staged ecosystem manifest to that version and the
installation versions in every staged package README. Publication commands
reject a payload whose manifest does not match it. Do not edit individual
source manifests or documentation versions while preparing a release.

Create these public companion repositories before tagging a release. Each
language repository receives only its own package tree and therefore renders
its language-specific README and documentation:

| Repository | Registry discovery |
| --- | --- |
| `onepub-dev/revault-api` | Go module proxy |
| `onepub-dev/revault-swift` | Swift Package Manager |
| `onepub-dev/revault-php` | Packagist source for `onepub/revault-api` |
| `onepub-dev/revault-homebrew` | Homebrew tap |

Install a GitHub App with contents write access to those four repositories and
store its narrowly scoped installation token as the `release` environment
secret `REVAULT_BINDING_APIS_RELEASE_TOKEN`. Register
`onepub-dev/revault-php` with Packagist and enable its GitHub integration. The
Rust release tool replaces each repository tree with one package, validates
it, commits it, and creates the immutable `vX.Y.Z` tag. It generates the Swift
binary target and Homebrew formula from the actual GitHub release asset
SHA-256 values; no mutable download URL is used.

Configure trusted publishers with owner `onepub-dev`, repository `reVault`,
workflow file `bindings-native-release.yml`, and environment `release`:

| Registry | Authorization |
| --- | --- |
| npm | Trusted publisher for all eight `@onepub-dev` packages; `NPM_TOKEN` is needed only to bootstrap packages npm requires to exist first |
| PyPI | Pending trusted publisher for `revault-api` |
| NuGet | Trusted publishing policy for `Revault.Api`; set `NUGET_USER` to the nuget.org profile name |
| pub.dev | Automated publishing for `revault_api` after its required first manual release |
| RubyGems | Trusted publisher for `revault_api` (new gems are supported) |
| crates.io | Trusted publishers for the existing `revault_page_api`, `revault_lockbox_api`, and `revault_vault_api` crates, plus `revault-api` after its required first manual release |

Maven Central currently requires a verified `dev.onepub` namespace, a Central
Portal user token, and an in-memory OpenPGP signing key. Store these `release`
environment secrets: `MAVEN_CENTRAL_USERNAME`, `MAVEN_CENTRAL_PASSWORD`,
`MAVEN_SIGNING_KEY`, and `MAVEN_SIGNING_PASSWORD`. Store a least-privilege
LuaRocks key as `LUAROCKS_API_KEY`. The workflow exchanges OIDC for temporary
PyPI, NuGet, npm, pub.dev, RubyGems, and crates.io credentials wherever the
registry supports the package's current lifecycle stage; long-lived bootstrap
credentials should be removed after trusted publishing is active.

ConanCenter and the public vcpkg registry accept recipe changes through their
upstream review processes rather than package-owner uploads. The checked
Conan/vcpkg recipes are generated and acceptance-tested with the same native
archives; after each release their version and archive hashes are submitted to
those upstream indexes. Debian and RPM files are release assets until an APT or
RPM repository is selected. These contribution/repository decisions do not
block the language-native npm, PyPI, Maven, NuGet, pub.dev, RubyGems, Packagist,
LuaRocks, Go, crates.io, SwiftPM, or Homebrew publications.

To release every language package in lockstep, create and push one tag after
all authorizations above exist:

```text
git tag -s revault-api-v0.2.0 -m "Release revault-api 0.2.0"
git push origin revault-api-v0.2.0
```

To publish only the Dart package while its redesigned facade is being
validated, use the Dart-scoped tag instead:

```text
git tag -s revault-dart-v0.3.2 -m "Release revault_api 0.3.2"
git push origin revault-dart-v0.3.2
```

The Dart-scoped tag still builds, attests, and package-tests all six native
targets. It publishes `revault_api` to pub.dev and creates the corresponding
GitHub release, but it does not publish or promote any other language package.

Do not rerun publication by changing an existing tag. Registry versions and
package-repository tags are immutable; correct a failed release with the same
workflow run where safe, or publish a new patch version.

## V4 storage and transaction maintenance

The v4 core adds `Lockbox::compact()`, `LockboxInspector::verify_storage()`, owner
fingerprint/lookup helpers and a migration comparison helper. The existing Rust
`abort()` now restores physical reservations durably. `TransactionRecoveryPhase`
adds `Rollback` and `Truncate` alongside `Cleanup`; exhaustive Rust matches must
handle them. These maintenance APIs remain Rust/CLI-only, as recorded in
[the exclusions](api/rust-only-exclusions.tsv). No new C ABI symbol, FlatBuffers
operation or foreign facade method is introduced by this change.

Foreign writable file opens inherit native recovery. Explicit read-only opens
remain non-mutating and can report recovery required. A commit error may occur
after publication: reopen and inspect persisted state before retrying. Do not
implement archive rollback or replacement using language-owned filesystem I/O.
For explicit maintenance use `lockbox <path> doctor compact` or
`lockbox <path> doctor --deep`, with library handles closed first.

See [the transaction protocol](../manual/develop-with-revault/transactions.md)
and [migration instructions](../manual/maintain-and-recover/migrating-between-versions.md).
Migrate the Vault first, then older Lockboxes. A v3 Vault structure still needs
its container upgraded to v4.

Release all affected packages with a rebuilt native carrier, including WASM;
unchanged facade signatures do not make old binaries v4-compatible. Run
`revault-tool internal check-bindings --repository .` and each target's
[executable conformance tests](e2e/CONFORMANCE.md), including file-backed
lifecycle and read-only checks, before publishing. No transport regeneration
is needed solely for this change; package/runtime versions must still match.
