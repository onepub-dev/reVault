#!/usr/bin/env python3
"""Python execution of the exhaustive reVault binding conformance contract."""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[3]
if os.environ.get("REVAULT_E2E_INSTALLED") != "1":
    sys.path.insert(0, str(ROOT / "bindings/python"))
import revault_api as binding  # noqa: E402
from revault_api._domain import (  # noqa: E402
    FormField, PathMove, decode, encode_form_fields, encode_path_moves,
)

LANGUAGE = "python"


def passed(symbol: str, assertions: int) -> None:
    """Report a successfully exercised ABI symbol and assertion count."""
    print(f"PASS\t{LANGUAGE}\t{symbol}\t{assertions}", flush=True)


def check(condition: bool, message: str) -> None:
    """Raise an assertion failure with context when a conformance check fails."""
    if not condition:
        raise AssertionError(message)


def data(value: bytes) -> ctypes.Array[ctypes.c_char]:
    """Copy bytes into a stable mutable buffer suitable for native calls."""
    return ctypes.create_string_buffer(value, len(value))


class Runtime:
    """Own the loaded native library and decode its ABI return conventions."""

    def __init__(self) -> None:
        # Package acceptance must resolve the carrier from the installed
        # package. Build-tree overrides are deliberately unsupported here.
        self.facade = binding.Revault.load(os.environ.get("REVAULT_E2E_LOAD_PATH"))
        self.lib = self.facade._lib

    def error(self) -> str:
        """Return the most recent native error message."""
        return self.lib.buffer_last_error().decode()

    def raw(self, result, expected: bytes | None = None) -> bytes:
        """Copy and free a native buffer, optionally validating its payload."""
        check(bool(result.ptr), f"expected returned buffer: {self.error()}")
        value = ctypes.string_at(result.ptr, result.len)
        self.lib.buffer_free(result)
        passed("buffer_free", 1)
        if expected is not None:
            check(value == expected, "raw returned value")
        return value

    def frame(self, result) -> bytes:
        """Return a private structured-result buffer."""
        return self.raw(result)

    def bool(self, value: bool, operation: str) -> None:
        """Validate a native Boolean success result for an operation."""
        check(bool(value), f"{operation}: {self.error()}")


def archive_lifecycle(runtime: Runtime) -> None:
    """Exercise native file persistence and the core archive lifecycle."""
    with tempfile.TemporaryDirectory(prefix='revault-file-') as root:
        path = Path(root) / 'archive.lbox'
        with binding.Lockbox.create(path, content_key=b'K' * 32) as box:
            box.add_file('/hello', b'native', False)
            box.commit()
        with binding.Lockbox.open(path, content_key=b'K' * 32) as box:
            check(box.get_file('/hello') == b'native', 'native file persistence')
    passed('lockbox_file', 3)
    lib = runtime.lib
    key = data(b"K" * 32)
    hello = data(b"hello from python conformance")
    replacement = data(b"replacement payload")
    box = lib.lockbox_create(key, 32)
    check(bool(box), runtime.error())
    passed("lockbox_create", 1)

    path = data(b"/hello.txt")
    runtime.bool(lib.lockbox_add_file(box, path, 10, hello, 29, False), "add file")
    check(lib.lockbox_exists(box, path, 10), "file visible after add")
    passed("lockbox_add_file", 2)
    runtime.raw(lib.lockbox_get_file(box, path, 10), b"hello from python conformance")
    passed("lockbox_get_file", 3)

    runtime.bool(
        lib.lockbox_add_file_with_permissions(box, path, 10, replacement, 19, 0o640, True),
        "replace file",
    )
    check(lib.lockbox_permissions(box, path, 10) == 0o640, "initial permissions")
    passed("lockbox_add_file_with_permissions", 2)
    passed("lockbox_permissions", 1)

    tree = data(b"/tree")
    runtime.bool(lib.lockbox_create_dir(box, tree, 5, True), "create directory")
    check(lib.lockbox_is_dir(box, tree, 5), "created path is directory")
    passed("lockbox_create_dir", 2)
    passed("lockbox_is_dir", 1)
    parent_path = data(b"/tree/a/b/file")
    runtime.bool(lib.lockbox_create_parent_dirs(box, parent_path, 14), "create parents")
    parents = data(b"/tree/a/b")
    check(lib.lockbox_is_dir(box, parents, 9), "parents created")
    passed("lockbox_create_parent_dirs", 2)

    renamed = data(b"/renamed.txt")
    runtime.bool(lib.lockbox_rename(box, path, 10, renamed, 12), "rename")
    check(lib.lockbox_exists(box, renamed, 12), "renamed file exists")
    check(not lib.lockbox_exists(box, path, 10), "old file absent")
    passed("lockbox_rename", 3)
    passed("lockbox_exists", 2)
    runtime.bool(lib.lockbox_set_permissions(box, renamed, 12, 0o600), "set permissions")
    check(lib.lockbox_permissions(box, renamed, 12) == 0o600, "permissions changed")
    passed("lockbox_set_permissions", 2)
    runtime.raw(lib.lockbox_read_range(box, renamed, 12, 0, 11), b"replacement")
    passed("lockbox_read_range", 3)

    normal, value = data(b"normal"), data(b"value")
    runtime.bool(lib.lockbox_set_variable(box, normal, 6, value, 5), "set variable")
    check(b"value" in runtime.frame(lib.lockbox_get_variable(box, normal, 6)), "variable value")
    passed("lockbox_set_variable", 1)
    passed("lockbox_get_variable", 3)
    moves = encode_path_moves([PathMove(source="normal", destination="moved")])
    moves_data = data(moves)
    runtime.bool(lib.lockbox_move_variables(box, moves_data, len(moves)), "move variable")
    moved = data(b"moved")
    check(b"value" in runtime.frame(lib.lockbox_get_variable(box, moved, 5)), "moved variable")
    moves = encode_path_moves([PathMove(source="moved", destination="normal")])
    moves_data = data(moves)
    runtime.bool(lib.lockbox_move_variables(box, moves_data, len(moves)), "move variable back")
    passed("lockbox_move_variables", 3)
    secret, hidden = data(b"secret"), data(b"hidden")
    runtime.bool(lib.lockbox_set_secret_variable(box, secret, 6, hidden, 6), "set secret")
    passed("lockbox_set_secret_variable", 1)
    secret_handle = ctypes.c_void_p()
    runtime.bool(lib.lockbox_get_secret_variable(box, secret, 6, ctypes.byref(secret_handle)), "get secret")
    secret_length = ctypes.c_size_t()
    runtime.bool(lib.secret_len(secret_handle, ctypes.byref(secret_length)), "secret length")
    secret_bytes = (ctypes.c_ubyte * secret_length.value)()
    runtime.bool(lib.secret_copy(secret_handle, secret_bytes, secret_length.value), "secret copy")
    check(bytes(secret_bytes) == b"hidden", "secret value")
    ctypes.memset(secret_bytes, 0, secret_length.value)
    lib.secret_free(secret_handle)
    passed("lockbox_get_secret_variable", 1)
    passed("secret_len", 1)
    passed("secret_copy", 1)
    passed("secret_free", 1)
    sensitivity = runtime.frame(lib.lockbox_variable_sensitivity(box, secret, 6))
    check(b"secret" in sensitivity, "secret sensitivity")
    passed("lockbox_variable_sensitivity", 2)
    check(runtime.frame(lib.lockbox_list_variables(box)), "variable list")
    passed("lockbox_list_variables", 1)
    runtime.bool(lib.lockbox_delete_variable(box, normal, 6), "delete variable")
    passed("lockbox_delete_variable", 1)

    link, target = data(b"/link"), data(b"/renamed.txt")
    runtime.bool(lib.lockbox_add_symlink(box, link, 5, target, 12, False), "add symlink")
    runtime.raw(lib.lockbox_get_symlink_target(box, link, 5), b"/renamed.txt")
    passed("lockbox_add_symlink", 1)
    passed("lockbox_get_symlink_target", 3)
    root = data(b"/")
    check(runtime.frame(lib.lockbox_list(box, root, 1, True)), "listing")
    stat = decode("OptionalLockboxEntry", runtime.frame(lib.lockbox_stat(box, renamed, 12)))
    check(stat is not None, "present stat value")
    missing = data(b"/missing")
    missing_stat = decode("OptionalLockboxEntry", runtime.frame(lib.lockbox_stat(box, missing, 8)))
    check(missing_stat is None, "missing stat value")
    passed("lockbox_list", 2)
    passed("lockbox_stat", 2)

    workload, worker = data(b"read-mostly"), data(b"single")
    runtime.bool(lib.lockbox_set_workload_profile(box, workload, 11), "workload")
    runtime.bool(lib.lockbox_set_worker_policy(box, worker, 6, 1), "worker")
    check(runtime.frame(lib.lockbox_runtime_options(box)), "runtime options")
    cache_mode = data(b"bytes")
    runtime.bool(lib.lockbox_set_cache_limit(box, cache_mode, 5, 8192), "cache limit")
    check(decode("CacheStats", runtime.frame(lib.lockbox_cache_stats(box))).limit_bytes == 8192, "cache limit")
    cache_auto = data(b"auto")
    runtime.bool(lib.lockbox_set_cache_limit(box, cache_auto, 4, 0), "restore cache")
    passed("lockbox_set_cache_limit", 2)
    passed("lockbox_set_workload_profile", 1)
    passed("lockbox_set_worker_policy", 1)
    passed("lockbox_runtime_options", 1)
    runtime.bool(lib.lockbox_commit(box), "commit")
    check(lib.lockbox_storage_len(box) > 0, "storage length")
    passed("lockbox_commit", 1)
    passed("lockbox_storage_len", 1)

    archive = runtime.raw(lib.lockbox_to_bytes(box))
    passed("lockbox_to_bytes", 2)
    format_version = lib.lockbox_format_version()
    check(format_version > 0, "lockbox format version")
    archive_probe = data(archive)
    check(lib.lockbox_probe_format_version(archive_probe, len(archive)) == format_version,
          "lockbox format probe")
    passed("lockbox_format_version", 2)
    passed("lockbox_probe_format_version", 2)
    invalid = data(b"bad")
    check(lib.lockbox_probe_format_version(invalid, 3) == 0, "invalid format probe")
    details = decode("ErrorDetails", runtime.frame(lib.buffer_last_error_details()))
    check(bool(details.message), "structured error details")
    passed("buffer_last_error_details", 2)
    artifact_dir = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / LANGUAGE
    artifact_dir.mkdir(parents=True, exist_ok=True)
    archive_path = artifact_dir / "archive.lbox"
    archive_path.write_bytes(archive)
    print(f"ARTIFACT\t{LANGUAGE}\tarchive-created\t{archive_path}", flush=True)
    archive_data = data(archive)
    opened = lib.lockbox_open(archive_data, len(archive), key, 32)
    check(bool(opened), runtime.error())
    runtime.raw(lib.lockbox_get_file(opened, renamed, 12), b"replacement payload")
    passed("lockbox_open", 2)
    print(f"ARTIFACT\t{LANGUAGE}\tarchive-opened\t{archive_path}", flush=True)
    runtime.bool(lib.lockbox_delete(opened, renamed, 12), "delete file")
    check(not lib.lockbox_exists(opened, renamed, 12), "file deleted")
    passed("lockbox_delete", 2)
    runtime.bool(lib.lockbox_remove_dir(opened, tree, 5, True), "remove tree")
    check(not lib.lockbox_exists(opened, tree, 5), "tree removed")
    passed("lockbox_remove_dir", 2)
    lib.lockbox_free(opened)
    lib.lockbox_free(box)
    passed("lockbox_free", 2)


def key_lifecycle(runtime: Runtime) -> None:
    """Exercise contact, signing, wrapping, and key-format operations."""
    lib = runtime.lib
    content = bytes(range(32))
    content_data = data(content)
    contact = lib.key_contact_generate()
    check(bool(contact), runtime.error())
    passed("key_contact_generate", 1)
    private = runtime.raw(lib.key_contact_private(contact))
    check(len(private) > 32, "contact private record")
    passed("key_contact_private", 2)
    private_data = data(private)
    contact_copy = lib.key_contact_from_private(private_data, len(private))
    check(bool(contact_copy), runtime.error())
    passed("key_contact_from_private", 1)
    public = runtime.raw(lib.key_contact_public(contact))
    check(public, "contact public record")
    passed("key_contact_public", 2)
    public_data = data(public)
    public_key = lib.key_contact_public_from_bytes(public_data, len(public))
    check(bool(public_key), runtime.error())
    passed("key_contact_public_from_bytes", 1)
    wrapped = lib.key_contact_encrypt(public_key, content_data, len(content))
    check(bool(wrapped), runtime.error())
    passed("key_contact_encrypt", 1)
    runtime.raw(lib.key_contact_decrypt(contact_copy, wrapped), content)
    passed("key_contact_decrypt", 3)
    check(runtime.raw(lib.key_contact_wrapped_public(wrapped)), "wrapped public")
    check(runtime.raw(lib.key_contact_wrapped_ciphertext(wrapped)), "wrapped ciphertext")
    check(runtime.raw(lib.key_contact_wrapped_encrypted(wrapped)), "wrapped encrypted")
    passed("key_contact_wrapped_public", 2)
    passed("key_contact_wrapped_ciphertext", 2)
    passed("key_contact_wrapped_encrypted", 2)

    raw_hex = data(b"raw-hex")
    exported_private = runtime.raw(lib.vault_key_export_private(contact, raw_hex, 7))
    check(exported_private, "private key export")
    passed("vault_key_export_private", 2)
    exported_private_data = data(exported_private)
    imported_private = lib.vault_key_import_private(exported_private_data, len(exported_private))
    check(bool(imported_private), runtime.error())
    passed("vault_key_import_private", 1)
    pem = data(b"lockbox-pem")
    exported_public = runtime.raw(lib.vault_key_export_public(public_key, pem, 11))
    check(exported_public, "public key export")
    passed("vault_key_export_public", 2)
    exported_public_data = data(exported_public)
    imported_public = lib.vault_key_import_public(exported_public_data, len(exported_public))
    check(bool(imported_public), runtime.error())
    passed("vault_key_import_public", 1)
    fingerprint = runtime.raw(lib.vault_key_fingerprint(imported_public))
    check(len(fingerprint) >= 12, "key fingerprint")
    passed("vault_key_fingerprint", 2)
    fingerprint_data = data(fingerprint)
    formatted_hex = runtime.raw(lib.vault_key_format_hex(fingerprint_data, len(fingerprint)))
    passed("vault_key_format_hex", 2)
    formatted_hex_data = data(formatted_hex)
    runtime.raw(lib.vault_key_decode_hex(formatted_hex_data, len(formatted_hex)), fingerprint)
    passed("vault_key_decode_hex", 2)
    crockford = runtime.raw(lib.vault_key_format_crockford(fingerprint_data, 12))
    check(crockford, "crockford code")
    passed("vault_key_format_crockford", 2)
    crockford_data = data(crockford)
    reading = runtime.raw(lib.vault_key_format_crockford_reading(crockford_data, len(crockford)))
    check(reading, "crockford reading")
    passed("vault_key_format_crockford_reading", 2)
    runtime.raw(lib.vault_key_decode_crockford(crockford_data, len(crockford)), fingerprint[:12])
    passed("vault_key_decode_crockford", 2)
    encoded = runtime.raw(lib.vault_key_hex_encode(content_data, len(content)))
    check(len(encoded) == 64, "hex encoding")
    passed("vault_key_hex_encode", 2)
    encoded_data = data(encoded)
    runtime.raw(lib.vault_key_hex_decode(encoded_data, len(encoded)), content)
    passed("vault_key_hex_decode", 2)

    signing = lib.key_signing_generate()
    check(bool(signing), runtime.error())
    passed("key_signing_generate", 1)
    signing_private = runtime.raw(lib.key_signing_private(signing))
    check(signing_private, "signing private")
    passed("key_signing_private", 2)
    signing_private_data = data(signing_private)
    signing_copy = lib.key_signing_from_private(signing_private_data, len(signing_private))
    check(bool(signing_copy), runtime.error())
    passed("key_signing_from_private", 1)
    signing_public = runtime.raw(lib.key_signing_public(signing))
    check(signing_public, "signing public")
    passed("key_signing_public", 2)
    signing_public_data = data(signing_public)
    signing_public_copy = lib.key_signing_public_from_bytes(signing_public_data, len(signing_public))
    check(bool(signing_public_copy), runtime.error())
    passed("key_signing_public_from_bytes", 1)
    lib.key_signing_public_free(signing_public_copy)
    lib.key_signing_free(signing_copy)
    lib.key_signing_free(signing)
    passed("key_signing_public_free", 1)
    passed("key_signing_free", 2)
    lib.key_contact_wrapped_free(wrapped)
    lib.key_contact_public_free(imported_public)
    lib.key_contact_free(imported_private)
    lib.key_contact_public_free(public_key)
    lib.key_contact_free(contact_copy)
    lib.key_contact_free(contact)
    passed("key_contact_wrapped_free", 1)
    passed("key_contact_public_free", 2)
    passed("key_contact_free", 3)


def advanced_archive(runtime: Runtime) -> None:
    """Exercise forms, recovery, ownership, and advanced lockbox operations."""
    lib = runtime.lib
    key_bytes = b"1" * 32
    key = data(key_bytes)
    cache, workload, worker = data(b"bytes"), data(b"bulk-import"), data(b"single")
    box = lib.lockbox_create_with_options(
        key, 32, cache, 5, 1024 * 1024, workload, 11, worker, 6, 1
    )
    check(bool(box), runtime.error())
    passed("lockbox_create_with_options", 1)
    payload_bytes = b"advanced archive payload"
    payload = data(payload_bytes)
    advanced_path = data(b"/advanced.txt")
    runtime.bool(lib.lockbox_add_file(box, advanced_path, 13, payload, len(payload_bytes), False), "advanced file")
    root, glob = data(b"/"), data(b"*.txt")
    check(runtime.frame(lib.lockbox_list_with_options(box, root, 1, glob, 5, True, True, False, False, 10)), "filtered list")
    passed("lockbox_list_with_options", 2)

    fields = encode_form_fields([
        FormField(id="username", label="Username", kind="text", required=True),
        FormField(id="password", label="Password", kind="secret", required=True),
    ])
    fields_data = data(fields)
    alias, name, description = data(b"account"), data(b"Account"), data(b"Account form")
    definition_payload = runtime.frame(lib.lockbox_define_form(
        box, alias, 7, name, 7, description, 12, fields_data, len(fields)
    ))
    definition = decode("FormDefinition", definition_payload)
    type_id = definition.type_id.encode()
    check(type_id, "form type identifier")
    passed("lockbox_define_form", 2)
    check(runtime.frame(lib.lockbox_list_form_definitions(box)), "form definitions")
    check(runtime.frame(lib.lockbox_resolve_form(box, alias, 7)), "resolve form")
    type_id_data = data(type_id)
    check(runtime.frame(lib.lockbox_list_form_revisions(box, type_id_data, len(type_id))), "form revisions")
    passed("lockbox_list_form_definitions", 1)
    passed("lockbox_resolve_form", 1)
    passed("lockbox_list_form_revisions", 1)
    record_path, record_name = data(b"/account.form"), data(b"Primary account")
    check(runtime.frame(lib.lockbox_create_form_record(box, record_path, 13, alias, 7, record_name, 15)), "form record")
    passed("lockbox_create_form_record", 1)
    field, field_value = data(b"username"), data(b"alice")
    runtime.bool(lib.lockbox_set_form_field(box, record_path, 13, field, 8, field_value, 5), "set form field")
    passed("lockbox_set_form_field", 1)
    password_field, password_value = data(b"password"), data(b"hidden")
    runtime.bool(lib.lockbox_set_secret_form_field(box, record_path, 13, password_field, 8, password_value, 6), "set secret form field")
    passed("lockbox_set_secret_form_field", 1)
    secret_handle = ctypes.c_void_p()
    runtime.bool(lib.lockbox_get_secret_form_field(box, record_path, 13, password_field, 8, ctypes.byref(secret_handle)), "get secret form field")
    secret_length = ctypes.c_size_t()
    runtime.bool(lib.secret_len(secret_handle, ctypes.byref(secret_length)), "secret form length")
    secret_bytes = (ctypes.c_ubyte * secret_length.value)()
    runtime.bool(lib.secret_copy(secret_handle, secret_bytes, secret_length.value), "secret form copy")
    check(bytes(secret_bytes) == b"hidden", "secret form value")
    ctypes.memset(secret_bytes, 0, secret_length.value)
    lib.secret_free(secret_handle)
    passed("lockbox_get_secret_form_field", 1)
    record = decode("OptionalFormRecord", runtime.frame(lib.lockbox_get_form_record(box, record_path, 13)))
    form_value = decode("OptionalFormValue", runtime.frame(lib.lockbox_get_form_field(box, record_path, 13, field, 8)))
    check(record is not None, "present form record")
    check(form_value is not None, "present form field")
    missing_record = data(b"/missing.form")
    absent_record = decode("OptionalFormRecord", runtime.frame(lib.lockbox_get_form_record(box, missing_record, 13)))
    absent_field = decode("OptionalFormValue", runtime.frame(lib.lockbox_get_form_field(box, missing_record, 13, field, 8)))
    check(absent_record is None, "missing form record")
    check(absent_field is None, "missing form field")
    check(runtime.frame(lib.lockbox_list_form_records(box)), "list form records")
    passed("lockbox_get_form_record", 1)
    passed("lockbox_get_form_field", 1)
    passed("lockbox_list_form_records", 1)
    moves = encode_path_moves([PathMove(source="/account.form", destination="/moved.form")])
    moves_data = data(moves)
    runtime.bool(lib.lockbox_move_form_records(box, moves_data, len(moves)), "move form record")
    moved_record = data(b"/moved.form")
    check(runtime.frame(lib.lockbox_get_form_record(box, moved_record, 11)), "moved form record")
    moves = encode_path_moves([PathMove(source="/moved.form", destination="/account.form")])
    moves_data = data(moves)
    runtime.bool(lib.lockbox_move_form_records(box, moves_data, len(moves)), "move form record back")
    passed("lockbox_move_form_records", 3)

    signing = lib.key_signing_generate()
    check(bool(signing), runtime.error())
    runtime.bool(lib.lockbox_set_owner_signing_key(box, signing), "set owner")
    passed("lockbox_set_owner_signing_key", 1)
    password_bytes = b"archive password"
    password = data(password_bytes)
    password_slot = lib.lockbox_add_password(box, password, len(password_bytes))
    check(password_slot != 2**64 - 1, "password slot")
    passed("lockbox_add_password", 1)
    contact = lib.key_contact_generate()
    public_bytes = runtime.raw(lib.key_contact_public(contact))
    public_data = data(public_bytes)
    public = lib.key_contact_public_from_bytes(public_data, len(public_bytes))
    recipient = data(b"recipient")
    contact_slot = lib.lockbox_add_contact(box, public, recipient, 9)
    check(contact_slot != 2**64 - 1, "contact slot")
    passed("lockbox_add_contact", 1)
    check(runtime.frame(lib.lockbox_list_key_slots(box)), "key slots")
    passed("lockbox_list_key_slots", 1)
    runtime.bool(lib.lockbox_delete_key(box, password_slot), "delete key slot")
    passed("lockbox_delete_key", 1)

    runtime.bool(lib.lockbox_commit(box), "advanced commit")
    owner = runtime.frame(lib.lockbox_owner_inspection(box))
    check(decode("OwnerInspection", owner).signed, "signed owner inspection")
    passed("lockbox_owner_inspection", 2)
    check(runtime.frame(lib.lockbox_cache_stats(box)) is not None, "cache stats")
    check(runtime.frame(lib.lockbox_import_stats(box)) is not None, "import stats")
    runtime.bool(lib.lockbox_reset_import_stats(box), "reset import stats")
    check(runtime.frame(lib.lockbox_page_inspection(box)), "page inspection")
    check(runtime.frame(lib.lockbox_recovery_report(box)) is not None, "recovery report")
    rendered = runtime.raw(lib.lockbox_recovery_report_render(box, True, 100))
    check(rendered, "rendered recovery report")
    check(runtime.frame(lib.lockbox_stream_content(box, False)), "content stream")
    passed("lockbox_cache_stats", 1)
    passed("lockbox_import_stats", 1)
    passed("lockbox_reset_import_stats", 1)
    passed("lockbox_page_inspection", 1)
    passed("lockbox_recovery_report", 1)
    passed("lockbox_recovery_report_render", 2)
    passed("lockbox_stream_content", 1)
    lockbox_id = runtime.raw(lib.lockbox_id(box))
    check(len(lockbox_id) == 16, "lockbox id")
    passed("lockbox_id", 2)

    archive = runtime.raw(lib.lockbox_to_bytes(box))
    artifact_dir = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / LANGUAGE
    artifact_dir.mkdir(parents=True, exist_ok=True)
    advanced_file = artifact_dir / "advanced.lbox"
    advanced_file.write_bytes(archive)
    advanced_file_data = data(str(advanced_file).encode())
    check(runtime.frame(lib.lockbox_inspect_file(advanced_file_data, len(str(advanced_file)))), "file inspection")
    check(runtime.frame(lib.lockbox_recovery_scan_path(advanced_file_data, len(str(advanced_file)), key, 32)), "path recovery")
    archive_data = data(archive)
    check(runtime.frame(lib.lockbox_recovery_scan(archive_data, len(archive), key, 32)), "memory recovery")
    passed("lockbox_inspect_file", 1)
    passed("lockbox_recovery_scan_path", 1)
    passed("lockbox_recovery_scan", 1)
    salvaged = lib.lockbox_recovery_salvage(archive_data, len(archive), key, 32, signing)
    check(bool(salvaged), runtime.error())
    runtime.raw(lib.lockbox_get_file(salvaged, advanced_path, 13), payload_bytes)
    passed("lockbox_recovery_salvage", 2)
    lib.lockbox_free(salvaged)
    disabled, read_mostly = data(b"disabled"), data(b"read-mostly")
    opened = lib.lockbox_open_with_options(archive_data, len(archive), key, 32, disabled, 8, 0, read_mostly, 11, worker, 6, 1)
    check(bool(opened), runtime.error())
    passed("lockbox_open_with_options", 1)
    lib.lockbox_free(opened)

    password_box = lib.lockbox_create_password(password, len(password_bytes))
    check(bool(password_box), runtime.error())
    password_path = data(b"/password.txt")
    runtime.bool(lib.lockbox_add_file(password_box, password_path, 13, payload, len(payload_bytes), False), "password file")
    runtime.bool(lib.lockbox_commit(password_box), "password commit")
    password_archive = runtime.raw(lib.lockbox_to_bytes(password_box))
    password_archive_data = data(password_archive)
    opened_password = lib.lockbox_open_password(password_archive_data, len(password_archive), password, len(password_bytes))
    check(bool(opened_password), runtime.error())
    runtime.raw(lib.lockbox_get_file(opened_password, password_path, 13), payload_bytes)
    passed("lockbox_create_password", 1)
    passed("lockbox_open_password", 2)
    lib.lockbox_free(opened_password)
    lib.lockbox_free(password_box)

    contact_box = lib.lockbox_create_contact(public)
    check(bool(contact_box), runtime.error())
    contact_path = data(b"/contact.txt")
    runtime.bool(lib.lockbox_add_file(contact_box, contact_path, 12, payload, len(payload_bytes), False), "contact file")
    runtime.bool(lib.lockbox_commit(contact_box), "contact commit")
    contact_archive = runtime.raw(lib.lockbox_to_bytes(contact_box))
    contact_archive_data = data(contact_archive)
    opened_contact = lib.lockbox_open_contact(contact_archive_data, len(contact_archive), contact)
    check(bool(opened_contact), runtime.error())
    runtime.raw(lib.lockbox_get_file(opened_contact, contact_path, 12), payload_bytes)
    passed("lockbox_create_contact", 1)
    passed("lockbox_open_contact", 2)
    lib.lockbox_free(opened_contact)
    lib.lockbox_free(contact_box)

    signed_password_bytes = b"archive password"
    signed_password_data = data(signed_password_bytes)
    signed_password = lib.lockbox_create_password_with_signing_key(
        signed_password_data, len(signed_password_bytes), signing
    )
    check(bool(signed_password), runtime.error())
    runtime.bool(lib.lockbox_commit(signed_password), "signed password commit")
    passed("lockbox_create_password_with_signing_key", 1)
    lib.lockbox_free(signed_password)

    signed_contact = lib.lockbox_create_contact_with_signing_key(public, signing)
    check(bool(signed_contact), runtime.error())
    runtime.bool(lib.lockbox_commit(signed_contact), "signed contact commit")
    passed("lockbox_create_contact_with_signing_key", 1)
    lib.lockbox_free(signed_contact)

    signed_box = lib.lockbox_create_with_signing_key(key, 32, signing)
    check(bool(signed_box), runtime.error())
    runtime.bool(lib.lockbox_commit(signed_box), "signed commit")
    signed_owner = decode("OwnerInspection", runtime.frame(lib.lockbox_owner_inspection(signed_box)))
    check(signed_owner.signed, "signed box")
    passed("lockbox_create_with_signing_key", 2)
    lib.lockbox_free(signed_box)

    extract_root = artifact_dir / "extract"
    extract_root.mkdir(exist_ok=True)
    extracted_file = extract_root / "file.txt"
    if extracted_file.exists():
        extracted_file.unlink()
    extracted_file_data = data(str(extracted_file).encode())
    runtime.bool(lib.lockbox_extract_file(box, advanced_path, 13, extracted_file_data, len(str(extracted_file)), False), "extract file")
    check(extracted_file.read_bytes() == payload_bytes, "extracted bytes")
    passed("lockbox_extract_file", 2)
    extracted_tree = extract_root / "tree"
    if extracted_tree.exists():
        import shutil
        shutil.rmtree(extracted_tree)
    extracted_tree_data = data(str(extracted_tree).encode())
    runtime.bool(lib.lockbox_extract_directory(box, extracted_tree_data, len(str(extracted_tree)), 1024 * 1024, 4 * 1024 * 1024, 100, False, True, False), "extract directory")
    check(extracted_tree.exists(), "extracted directory")
    passed("lockbox_extract_directory", 2)
    runtime.bool(lib.lockbox_delete_form_record(box, record_path, 13), "delete form record")
    passed("lockbox_delete_form_record", 1)
    lib.key_contact_public_free(public)
    lib.key_contact_free(contact)
    lib.key_signing_free(signing)
    lib.lockbox_free(box)


def vault_lifecycle(runtime: Runtime) -> None:
    """Exercise persistent vault-directory operations."""
    lib = runtime.lib
    artifact_dir = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / LANGUAGE
    artifact_dir.mkdir(parents=True, exist_ok=True)
    root = artifact_dir / "vault"
    root.mkdir(exist_ok=True)
    root_bytes = str(root).encode()
    root_data = data(root_bytes)
    password_bytes = b"vault password"
    password = data(password_bytes)
    new_password_bytes = b"new vault password"
    new_password = data(new_password_bytes)
    identifier_bytes = bytes(range(0xA0, 0xB0))
    identifier = data(identifier_bytes)
    vault = lib.vault_directory_replace(root_data, len(root_bytes), password, len(password_bytes))
    check(bool(vault), runtime.error())
    passed("vault_directory_replace", 1)
    print(f"ARTIFACT\t{LANGUAGE}\tvault-created\t{root}", flush=True)
    runtime.raw(lib.vault_directory_root(vault), root_bytes)
    passed("vault_directory_root", 3)
    check(lib.vault_directory_structure_version(vault) > 0, "vault structure")
    passed("vault_directory_structure_version", 1)
    current_version = lib.vault_structure_version_current()
    check(current_version == lib.vault_directory_structure_version(vault), "current vault version")
    passed("vault_structure_version_current", 2)

    profile = lib.key_contact_generate()
    contact = lib.key_contact_generate()
    signing = lib.key_signing_generate()
    check(profile and contact and signing, "vault fixture keys")
    contact_bytes = runtime.raw(lib.key_contact_public(contact))
    contact_data = data(contact_bytes)
    contact_public = lib.key_contact_public_from_bytes(contact_data, len(contact_bytes))
    signing_bytes = runtime.raw(lib.key_signing_public(signing))
    signing_data = data(signing_bytes)
    signing_public = lib.key_signing_public_from_bytes(signing_data, len(signing_bytes))
    alice, bob = data(b"alice"), data(b"bob")
    runtime.bool(lib.vault_directory_store_private_key(vault, alice, 5, profile), "store profile")
    check(lib.vault_directory_private_key_exists(vault, alice, 5), "profile exists")
    passed("vault_directory_store_private_key", 1)
    passed("vault_directory_private_key_exists", 1)
    loaded_profile = lib.vault_directory_load_private_key(vault, alice, 5)
    generation = lib.vault_directory_load_private_key_generation(vault, alice, 5, 1)
    check(loaded_profile and generation, "load profile generations")
    passed("vault_directory_load_private_key", 1)
    passed("vault_directory_load_private_key_generation", 1)
    email_bytes = b"alice@example.test"
    email = data(email_bytes)
    runtime.bool(lib.vault_directory_store_profile_email(vault, alice, 5, email, len(email_bytes)), "store profile email")
    email_payload = runtime.frame(lib.vault_directory_profile_email(vault, alice, 5))
    check(email_bytes in email_payload, "profile email")
    passed("vault_directory_store_profile_email", 1)
    passed("vault_directory_profile_email", 3)
    check(runtime.frame(lib.vault_directory_list_profile_generations(vault, alice, 5)), "profile history")
    check(runtime.frame(lib.vault_directory_rotate_private_key(vault, alice, 5)), "rotate profile")
    passed("vault_directory_list_profile_generations", 1)
    passed("vault_directory_rotate_private_key", 1)
    owner = lib.vault_directory_load_owner_signing_key(vault, alice, 5)
    owner_generation = lib.vault_directory_load_owner_signing_key_generation(vault, alice, 5, 1)
    check(owner and owner_generation, "owner signing generations")
    passed("vault_directory_load_owner_signing_key", 1)
    passed("vault_directory_load_owner_signing_key_generation", 1)

    runtime.bool(lib.vault_directory_store_contact(vault, bob, 3, contact_public), "store contact")
    check(lib.vault_directory_contact_exists(vault, bob, 3), "contact exists")
    passed("vault_directory_store_contact", 1)
    passed("vault_directory_contact_exists", 1)
    loaded_contact = lib.vault_directory_load_contact(vault, bob, 3)
    check(loaded_contact, "load contact")
    passed("vault_directory_load_contact", 1)
    check(runtime.frame(lib.vault_directory_list_contacts(vault)), "contact list")
    passed("vault_directory_list_contacts", 1)
    runtime.bool(lib.vault_directory_store_contact_signing_key(vault, bob, 3, signing_public), "store contact signing")
    loaded_signing = lib.vault_directory_load_contact_signing_key(vault, bob, 3)
    check(loaded_signing, "load contact signing")
    passed("vault_directory_store_contact_signing_key", 1)
    passed("vault_directory_load_contact_signing_key", 1)
    check(runtime.frame(lib.vault_directory_list_private_keys(vault)), "private keys")
    check(runtime.frame(lib.vault_directory_list_private_key_names(vault)), "private key names")
    check(runtime.frame(lib.vault_directory_list_contact_names(vault)), "contact names")
    passed("vault_directory_list_private_keys", 1)
    passed("vault_directory_list_private_key_names", 1)
    passed("vault_directory_list_contact_names", 1)

    backup_bytes = b"encrypted backup bytes"
    backup = data(backup_bytes)
    runtime.bool(lib.vault_directory_store_backup(vault, identifier, 16, backup, len(backup_bytes)), "store backup")
    check(lib.vault_directory_backup_count(vault) == 1, "backup count")
    runtime.raw(lib.vault_directory_load_backup(vault, identifier, 16), backup_bytes)
    passed("vault_directory_store_backup", 1)
    passed("vault_directory_backup_count", 1)
    passed("vault_directory_load_backup", 3)
    lockbox_path_bytes = b"/tmp/example.lbox"
    lockbox_path = data(lockbox_path_bytes)
    runtime.bool(lib.vault_directory_remember_lockbox(vault, identifier, 16, lockbox_path, len(lockbox_path_bytes)), "remember lockbox")
    check(runtime.frame(lib.vault_directory_list_known_lockboxes(vault)), "known lockboxes")
    passed("vault_directory_remember_lockbox", 1)
    passed("vault_directory_list_known_lockboxes", 1)
    label = data(b"primary")
    runtime.bool(lib.vault_directory_remember_access_slot_label(vault, identifier, 16, 7, label, 7), "remember label")
    check(runtime.frame(lib.vault_directory_list_access_slot_labels(vault, identifier, 16)), "access labels")
    check(runtime.frame(lib.vault_directory_find_access_slot_labels(vault, identifier, 16, label, 7)), "find access labels")
    passed("vault_directory_remember_access_slot_label", 1)
    passed("vault_directory_list_access_slot_labels", 1)
    passed("vault_directory_find_access_slot_labels", 1)
    runtime.bool(lib.vault_directory_remember_password(vault, identifier, 16, password, len(password_bytes)), "remember password")
    runtime.raw(lib.vault_directory_remembered_password(vault, identifier, 16), password_bytes)
    passed("vault_directory_remember_password", 1)
    passed("vault_directory_remembered_password", 3)

    fields = encode_form_fields([
        FormField(id="username", label="Username", kind="text", required=True),
    ])
    fields_data = data(fields)
    alias, form_name, description = data(b"login"), data(b"Login"), data(b"Login form")
    vault_definition_payload = runtime.frame(lib.vault_directory_define_form(vault, alias, 5, form_name, 5, description, 10, fields_data, len(fields)))
    check(vault_definition_payload, "define vault form")
    vault_definition = decode("FormDefinition", vault_definition_payload)
    check(runtime.frame(lib.vault_directory_resolve_form(vault, alias, 5)), "resolve vault form")
    check(runtime.frame(lib.vault_directory_list_forms(vault)), "vault forms")
    passed("vault_directory_define_form", 1)
    passed("vault_directory_resolve_form", 1)
    passed("vault_directory_list_forms", 1)
    vault_type_id = vault_definition.type_id.encode()
    vault_type_id_data = data(vault_type_id)
    check(runtime.frame(lib.vault_directory_list_form_revisions(
        vault, vault_type_id_data, len(vault_type_id)
    )), "vault form revisions")
    passed("vault_directory_list_form_revisions", 2)
    check(lib.vault_directory_seed_forms(vault) > 0, "seed forms")
    passed("vault_directory_seed_forms", 1)
    check(runtime.frame(lib.vault_directory_list_form_aliases(vault)), "form aliases")
    passed("vault_directory_list_form_aliases", 1)
    runtime.bool(lib.vault_directory_forget_access_slot_label(vault, identifier, 16, 7), "forget label")
    runtime.bool(lib.vault_directory_forget_lockbox(vault, lockbox_path, len(lockbox_path_bytes)), "forget lockbox")
    runtime.bool(lib.vault_directory_delete_contact(vault, bob, 3), "delete contact")
    passed("vault_directory_forget_access_slot_label", 1)
    passed("vault_directory_forget_lockbox", 1)
    passed("vault_directory_delete_contact", 1)
    restored = data(b"restored")
    runtime.bool(lib.vault_directory_restore_private_key(vault, restored, 8, generation, owner_generation, False), "restore profile")
    check(lib.vault_directory_private_key_exists(vault, restored, 8), "restored exists")
    passed("vault_directory_restore_private_key", 2)
    runtime.bool(lib.vault_directory_delete_private_key(vault, restored, 8), "delete profile")
    check(not lib.vault_directory_private_key_exists(vault, restored, 8), "deleted profile absent")
    passed("vault_directory_delete_private_key", 2)

    lib.key_contact_free(loaded_profile)
    lib.key_contact_free(generation)
    lib.key_contact_free(profile)
    lib.key_contact_public_free(loaded_contact)
    lib.key_contact_public_free(contact_public)
    lib.key_contact_free(contact)
    lib.key_signing_free(owner)
    lib.key_signing_free(owner_generation)
    lib.key_signing_public_free(loaded_signing)
    lib.key_signing_public_free(signing_public)
    lib.key_signing_free(signing)
    lib.vault_directory_free(vault)
    passed("vault_directory_free", 1)
    # Release the writable vault before an independent path-based probe.
    check(lib.vault_directory_probe_structure_version(
        root_data, len(root_bytes), password, len(password_bytes)
    ) == current_version, "vault structure probe")
    passed("vault_directory_probe_structure_version", 2)
    readonly = lib.vault_read_only_open(root_data, len(root_bytes), password, len(password_bytes))
    check(readonly, runtime.error())
    passed("vault_read_only_open", 1)
    check(runtime.frame(lib.vault_read_only_list_profile_names(readonly)), "read-only profiles")
    runtime.frame(lib.vault_read_only_list_contact_names(readonly))
    check(runtime.frame(lib.vault_read_only_list_form_aliases(readonly)), "read-only forms")
    runtime.frame(lib.vault_read_only_list_known_lockboxes(readonly))
    passed("vault_read_only_list_profile_names", 2)
    passed("vault_read_only_list_contact_names", 1)
    passed("vault_read_only_list_form_aliases", 2)
    passed("vault_read_only_list_known_lockboxes", 1)
    lib.vault_read_only_free(readonly)
    passed("vault_read_only_free", 1)
    runtime.bool(lib.vault_directory_change_password(root_data, len(root_bytes), password, len(password_bytes), new_password, len(new_password_bytes)), "change vault password")
    passed("vault_directory_change_password", 1)
    reopened = lib.vault_directory_open(root_data, len(root_bytes), new_password, len(new_password_bytes))
    check(reopened, runtime.error())
    passed("vault_directory_open", 1)
    print(f"ARTIFACT\t{LANGUAGE}\tvault-opened\t{root}", flush=True)
    lib.vault_directory_free(reopened)
    opened_or_created = lib.vault_directory_open_or_create(root_data, len(root_bytes), new_password, len(new_password_bytes))
    check(opened_or_created, runtime.error())
    passed("vault_directory_open_or_create", 1)
    lib.vault_directory_free(opened_or_created)


def default_vault_lifecycle(runtime: Runtime) -> None:
    """Exercise operations on the platform default vault directory."""
    lib = runtime.lib
    base = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / LANGUAGE
    root = base / "default-vault"
    root.mkdir(parents=True, exist_ok=True)
    os.environ["LOCKBOX_VAULT_DIR"] = str(root)
    password_bytes, changed_bytes = b"default password", b"changed default password"
    password, changed = data(password_bytes), data(changed_bytes)
    vault = lib.vault_directory_replace_default(password, len(password_bytes))
    check(vault, runtime.error())
    passed("vault_directory_replace_default", 1)
    lib.vault_directory_free(vault)
    readonly = lib.vault_read_only_open_default(password, len(password_bytes))
    check(readonly, runtime.error())
    lib.vault_read_only_free(readonly)
    passed("vault_read_only_open_default", 1)
    runtime.raw(lib.vault_default_directory(), str(root).encode())
    passed("vault_default_directory", 3)
    default_path = runtime.raw(lib.vault_default_path())
    check(default_path.startswith(str(root).encode()), "default vault path")
    passed("vault_default_path", 2)
    opened = lib.vault_directory_open_or_create_default(password, len(password_bytes))
    check(opened, runtime.error())
    passed("vault_directory_open_or_create_default", 1)
    lib.vault_directory_free(opened)
    runtime.bool(lib.vault_directory_change_default_password(password, len(password_bytes), changed, len(changed_bytes)), "change default password")
    passed("vault_directory_change_default_password", 1)
    backup = base / "default-vault.backup"
    if backup.exists():
        backup.unlink()
    backup_data = data(str(backup).encode())
    check(runtime.frame(lib.vault_backup_default(backup_data, len(str(backup)), False)), "default backup")
    passed("vault_backup_default", 1)
    check(runtime.frame(lib.vault_restore_default(backup_data, len(str(backup)), True)), "default restore")
    passed("vault_restore_default", 1)


def platform_secret_store(runtime: Runtime) -> None:
    """Exercise the platform-backed vault password store."""
    lib = runtime.lib
    base = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / LANGUAGE / "platform-vault"
    base.mkdir(parents=True, exist_ok=True)
    os.environ["LOCKBOX_VAULT_DIR"] = str(base)
    status = runtime.frame(lib.vault_platform_status())
    check(status is not None, "platform status")
    passed("vault_platform_status", 2)
    scope = data(b"vault")
    runtime.bool(lib.vault_platform_set_scope(scope, 5), "platform scope")
    passed("vault_platform_set_scope", 1)
    runtime.bool(lib.vault_platform_disable(), "platform disable")
    check(lib.vault_platform_disabled(), "platform disabled")
    passed("vault_platform_disable", 1)
    passed("vault_platform_disabled", 1)
    runtime.bool(lib.vault_platform_enable(), "platform enable")
    check(not lib.vault_platform_disabled(), "platform enabled")
    passed("vault_platform_enable", 1)
    password_bytes = b"platform vault password"
    password = data(password_bytes)
    runtime.bool(lib.vault_platform_put_password(password, len(password_bytes)), "platform password put")
    runtime.raw(lib.vault_platform_get_password(), password_bytes)
    passed("vault_platform_put_password", 1)
    passed("vault_platform_get_password", 3)
    runtime.bool(lib.vault_platform_forget_password(), "platform password forget")
    missing = lib.vault_platform_get_password()
    check(not bool(missing.ptr) and missing.len == 0, "platform password absent")
    passed("vault_platform_forget_password", 1)


def interop_open(runtime: Runtime, producer: str) -> None:
    """Open and validate artifacts produced by another language binding."""
    base = Path(os.environ.get("REVAULT_E2E_ARTIFACT_DIR", "/tmp/revault-e2e-artifacts")) / producer
    archive = (base / "archive.lbox").read_bytes()
    archive_data, key = data(archive), data(b"K" * 32)
    box = runtime.lib.lockbox_open(archive_data, len(archive), key, 32)
    check(box, runtime.error())
    path = data(b"/renamed.txt")
    runtime.raw(runtime.lib.lockbox_get_file(box, path, 12), b"replacement payload")
    runtime.lib.lockbox_free(box)
    password_bytes = b"new vault password"
    vault_path_bytes = str(base / "vault").encode()
    vault_path, password = data(vault_path_bytes), data(password_bytes)
    vault = runtime.lib.vault_directory_open(vault_path, len(vault_path_bytes), password, len(password_bytes))
    check(vault, runtime.error())
    check(runtime.lib.vault_directory_structure_version(vault) > 0, "foreign vault structure")
    runtime.lib.vault_directory_free(vault)
    print(f"INTEROP\t{LANGUAGE}\t{producer}\tarchive\t3", flush=True)
    print(f"INTEROP\t{LANGUAGE}\t{producer}\tvault\t2", flush=True)


def agent_and_local_vault(runtime: Runtime) -> None:
    """Exercise the session agent and local-vault convenience API."""
    lib = runtime.lib
    agent_dir = Path(tempfile.mkdtemp(prefix="revault-python-agent-"))
    agent_vault_dir = Path(tempfile.mkdtemp(prefix="revault-python-agent-vault-"))
    os.environ["LOCKBOX_SESSION_AGENT_DIR"] = str(agent_dir)
    os.environ["LOCKBOX_VAULT_DIR"] = str(agent_vault_dir)
    os.environ["LOCKBOX_VAULT_PASSWORD"] = "agent vault password"
    password_bytes = b"agent vault password"
    password = data(password_bytes)
    agent_vault = lib.vault_directory_replace_default(password, len(password_bytes))
    check(agent_vault, runtime.error())
    profile = lib.key_contact_generate()
    check(profile, runtime.error())
    name = data(b"default")
    runtime.bool(lib.vault_directory_store_private_key(agent_vault, name, 7, profile), "store default profile")
    lib.key_contact_free(profile)
    lib.vault_directory_free(agent_vault)
    runtime.bool(lib.vault_forget_all(), "clear agent")
    passed("vault_forget_all", 1)

    child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--serve-agent"], env=os.environ.copy())
    try:
        for _ in range(200):
            if lib.vault_is_running():
                break
            check(child.poll() is None, "agent exited during startup")
            time.sleep(0.05)
        else:
            raise AssertionError("agent did not start")
        passed("vault_agent_serve", 1)
        passed("vault_is_running", 1)
        runtime.bool(lib.vault_agent_start(), "start agent")
        passed("vault_agent_start", 1)
        runtime.bool(lib.vault_agent_verify_transport(), "agent transport")
        passed("vault_agent_verify_transport", 1)

        identifier_bytes = bytes(range(0xC0, 0xD0))
        key_bytes = bytes(range(0x20, 0x40))
        identifier, key = data(identifier_bytes), data(key_bytes)
        runtime.bool(lib.vault_agent_put(identifier, len(identifier_bytes), key, len(key_bytes)), "agent put")
        runtime.raw(lib.vault_agent_get(identifier, len(identifier_bytes)), key_bytes)
        check(runtime.frame(lib.vault_agent_list()), "agent list")
        passed("vault_agent_put", 1)
        passed("vault_agent_get", 3)
        passed("vault_agent_list", 1)

        alice = data(b"alice")
        vault_id = data(b"vault-id")
        runtime.bool(lib.vault_agent_put_vault_unlock_key(vault_id, 8, key, len(key_bytes), 120), "put vault key")
        runtime.raw(lib.vault_agent_get_vault_unlock_key(vault_id, 8), key_bytes)
        passed("vault_agent_put_vault_unlock_key", 1)
        passed("vault_agent_get_vault_unlock_key", 3)
        owner = lib.key_signing_generate()
        check(owner, runtime.error())
        runtime.bool(lib.vault_agent_put_owner_signing_key(vault_id, 8, alice, 5, owner, 120), "put owner key")
        loaded_owner = lib.vault_agent_get_owner_signing_key(vault_id, 8, alice, 5)
        check(loaded_owner, runtime.error())
        passed("vault_agent_put_owner_signing_key", 1)
        passed("vault_agent_get_owner_signing_key", 1)
        lib.key_signing_free(loaded_owner)

        activity_name = data(b"open")
        activity = lib.vault_agent_begin_activity(activity_name, 4)
        check(activity, runtime.error())
        passed("vault_agent_begin_activity", 1)
        lib.vault_agent_end_activity(activity)
        passed("vault_agent_end_activity", 1)
        check(runtime.frame(lib.vault_agent_sleep_support()), "sleep support")
        passed("vault_agent_sleep_support", 1)
        check(runtime.raw(lib.vault_agent_log_path()), "agent log path")
        check(runtime.raw(lib.vault_agent_log_destination()), "agent log destination")
        passed("vault_agent_log_path", 2)
        passed("vault_agent_log_destination", 2)

        local = lib.vault_local()
        check(local, runtime.error())
        passed("vault_local", 1)
        local_root = Path(tempfile.mkdtemp(prefix="revault-python-local-"))
        local_password_bytes, payload_bytes = b"local password", b"local vault data"
        local_password, payload = data(local_password_bytes), data(payload_bytes)
        entry = data(b"/data.txt")

        password_path_bytes = str(local_root / "password.lbox").encode()
        password_path = data(password_path_bytes)
        password_box = lib.vault_create_lockbox_password(local, password_path, len(password_path_bytes), local_password, len(local_password_bytes))
        check(password_box, runtime.error())
        runtime.bool(lib.lockbox_add_file(password_box, entry, 9, payload, len(payload_bytes), False), "local password add")
        runtime.bool(lib.lockbox_commit(password_box), "local password commit")
        lib.lockbox_free(password_box)
        passed("vault_create_lockbox_password", 3)
        runtime.bool(lib.vault_cache_lockbox_password(local, password_path, len(password_path_bytes), local_password, len(local_password_bytes), 120), "cache password")
        passed("vault_cache_lockbox_password", 1)
        opened = lib.vault_open_lockbox_password(local, password_path, len(password_path_bytes), local_password, len(local_password_bytes))
        check(opened, runtime.error())
        runtime.raw(lib.lockbox_get_file(opened, entry, 9), payload_bytes)
        lib.lockbox_free(opened)
        passed("vault_open_lockbox_password", 3)
        runtime.bool(lib.vault_close_lockbox(local, password_path, len(password_path_bytes)), "close password lockbox")
        passed("vault_close_lockbox", 1)

        content_path_bytes = str(local_root / "content.lbox").encode()
        content_path = data(content_path_bytes)
        content_box = lib.vault_create_lockbox_content_key(local, content_path, len(content_path_bytes), key, len(key_bytes), owner)
        check(content_box, runtime.error())
        runtime.bool(lib.lockbox_add_file(content_box, entry, 9, payload, len(payload_bytes), False), "local content add")
        runtime.bool(lib.lockbox_commit(content_box), "local content commit")
        lib.lockbox_free(content_box)
        passed("vault_create_lockbox_content_key", 3)
        opened = lib.vault_open_lockbox_content_key(local, content_path, len(content_path_bytes), key, len(key_bytes), owner)
        check(opened, runtime.error())
        runtime.raw(lib.lockbox_get_file(opened, entry, 9), payload_bytes)
        lib.lockbox_free(opened)
        passed("vault_open_lockbox_content_key", 3)

        contact = lib.key_contact_generate()
        public_bytes = runtime.raw(lib.key_contact_public(contact))
        public_data = data(public_bytes)
        contact_public = lib.key_contact_public_from_bytes(public_data, len(public_bytes))
        check(contact_public, runtime.error())
        contact_path_bytes = str(local_root / "contact.lbox").encode()
        contact_path, recipient = data(contact_path_bytes), data(b"recipient")
        contact_box = lib.vault_create_lockbox_contact(local, contact_path, len(contact_path_bytes), contact_public, recipient, 9, owner)
        check(contact_box, runtime.error())
        runtime.bool(lib.lockbox_add_file(contact_box, entry, 9, payload, len(payload_bytes), False), "local contact add")
        runtime.bool(lib.lockbox_commit(contact_box), "local contact commit")
        lib.lockbox_free(contact_box)
        passed("vault_create_lockbox_contact", 3)
        runtime.bool(lib.vault_close_all(local), "close all")
        passed("vault_close_all", 1)
        lib.vault_free(local)
        passed("vault_free", 1)

        runtime.bool(lib.vault_agent_forget_owner_signing_key(vault_id, 8, alice, 5), "forget owner key")
        runtime.bool(lib.vault_agent_forget_vault_unlock_key(vault_id, 8), "forget vault key")
        runtime.bool(lib.vault_agent_forget(identifier, len(identifier_bytes)), "forget generic key")
        passed("vault_agent_forget_owner_signing_key", 1)
        passed("vault_agent_forget_vault_unlock_key", 1)
        passed("vault_agent_forget", 1)
        lib.key_contact_public_free(contact_public)
        lib.key_contact_free(contact)
        lib.key_signing_free(owner)
        runtime.bool(lib.vault_agent_stop(), "stop agent")
        passed("vault_agent_stop", 1)
        check(child.wait(timeout=10) == 0, "agent exit status")
    finally:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=10)


def main() -> None:
    """Run the requested Python ABI conformance scenario."""
    runtime = Runtime()
    if mode := os.environ.get("REVAULT_E2E_LOADER_SMOKE"):
        version = runtime.lib.lockbox_format_version()
        check(version > 0, "loader native round trip")
        with tempfile.TemporaryDirectory(prefix='revault-loader-') as root:
            path = Path(root) / 'archive.lbox'
            payload = bytes([0, 255, 128, 10, 64])
            with runtime.facade.generate_profile_signing_key_pair() as signer:
                with binding.Lockbox.create(path, content_key=b'K' * 32, signing_key=signer) as box:
                    box.add_file('/payload', payload, False)
                    box.commit()
                    box.commit()
                with binding.Lockbox.open(path, content_key=b'K' * 32) as box:
                    check(box.get_file('/payload') == payload, 'loader persisted content')
        print(f"LOADER\tpython\t{mode}\t{version}\tpersisted")
        return
    if len(sys.argv) >= 3 and sys.argv[1] == "--interop":
        for producer in sys.argv[2:]:
            interop_open(runtime, producer)
        return
    if len(sys.argv) == 2 and sys.argv[1] == "--serve-agent":
        raise SystemExit(0 if runtime.lib.vault_agent_serve() else 1)
    if len(sys.argv) == 2 and sys.argv[1] == "--platform":
        platform_secret_store(runtime)
        return
    if len(sys.argv) == 2 and sys.argv[1] == "--core":
        check(
            not hasattr(binding, "SigningKeyPair")
            and not hasattr(binding, "SigningPublicKey"),
            "legacy signing classes remain exported",
        )
        signing = runtime.facade.generate_profile_signing_key_pair()
        check(
            isinstance(signing, binding.ProfileSigningKeyPair),
            "profile signing facade type",
        )
        public = runtime.facade.profile_signing_public_key_from_bytes(
            signing.public_bytes()
        )
        check(
            isinstance(public, binding.ProfileSigningPublicKey),
            "profile signing public facade type",
        )
        public.free()
        derived_public = signing.public_key()
        check(
            isinstance(derived_public, binding.ProfileSigningPublicKey),
            "derived profile signing public facade type",
        )
        derived_public.free()
        signing.free()
        archive_lifecycle(runtime)
        key_lifecycle(runtime)
        advanced_archive(runtime)
        vault_lifecycle(runtime)
        default_vault_lifecycle(runtime)
        return
    if len(sys.argv) == 2 and sys.argv[1] == "--agent":
        agent_and_local_vault(runtime)
        return
    archive_lifecycle(runtime)
    key_lifecycle(runtime)
    advanced_archive(runtime)
    vault_lifecycle(runtime)
    default_vault_lifecycle(runtime)
    agent_and_local_vault(runtime)
    check(runtime.lib.buffer_last_error() is not None, "last error pointer")
    passed("buffer_last_error", 1)


if __name__ == "__main__":
    main()
