//! Shared payload packing for the file-only candidate. All inputs currently use
//! the same archive-private access domain; public/access-domain mixing is forbidden.
use super::*;
use crate::file_format::allocation_map::Extent;
use crate::page_buffer::{zeroize_bytes, ZeroizingBytes};
use std::ops::Range;

const SLICE_MAGIC: &[u8; 8] = b"RV4SLC01";
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Slice {
    pub descriptor: Descriptor,
    pub start: u32,
    pub len: u32,
}
impl Slice {
    pub fn encode(&self) -> [u8; 80] {
        let mut bytes = [0; 80];
        bytes[..8].copy_from_slice(SLICE_MAGIC);
        bytes[8..72].copy_from_slice(&self.descriptor.encode());
        bytes[72..76].copy_from_slice(&self.start.to_le_bytes());
        bytes[76..].copy_from_slice(&self.len.to_le_bytes());
        bytes
    }
    pub fn decode(bytes: &[u8]) -> Result<Self> {
        if bytes.len() != 80 || &bytes[..8] != SLICE_MAGIC {
            return Err(Error::CorruptRecord);
        }
        let value = Self {
            descriptor: Descriptor::decode(&bytes[8..72])?,
            start: u32::from_le_bytes(bytes[72..76].try_into().unwrap()),
            len: u32::from_le_bytes(bytes[76..].try_into().unwrap()),
        };
        if value.len == 0
            || value.descriptor.ordinal != 0
            || value.descriptor.offset != 0
            || value.start.checked_add(value.len).is_none_or(|end| end > value.descriptor.logical_len)
        {
            return Err(Error::CorruptRecord);
        }
        Ok(value)
    }
    pub fn range(&self) -> Range<usize> {
        self.start as usize..(self.start + self.len) as usize
    }
}

struct PackCoverage {
    extent: Extent,
    descriptor: Descriptor,
    slices: BTreeMap<u32, u32>,
}
#[derive(Default)]
pub(super) struct Coverage(BTreeMap<u64, PackCoverage>);
impl Coverage {
    pub fn add(&mut self, extent: Extent, slice: &Slice) -> Result<()> {
        let pack = self.0.entry(extent.start).or_insert_with(|| PackCoverage {
            extent,
            descriptor: slice.descriptor.clone(),
            slices: BTreeMap::new(),
        });
        let end = slice.start.checked_add(slice.len).ok_or(Error::CorruptRecord)?;
        if pack.extent != extent || pack.descriptor != slice.descriptor
            || pack.slices.range(..=slice.start).next_back().is_some_and(|(_, end)| *end > slice.start)
            || pack.slices.range(slice.start..end).next().is_some()
        {
            return Err(Error::CorruptRecord);
        }
        pack.slices.insert(slice.start, end);
        Ok(())
    }
    pub fn finish(self) -> Result<()> {
        for pack in self.0.into_values() {
            let mut position = 0;
            for (start, end) in pack.slices {
                if start != position { return Err(Error::CorruptRecord); }
                position = end;
            }
            if position != pack.descriptor.logical_len { return Err(Error::CorruptRecord); }
        }
        Ok(())
    }
}

struct Member { id: [u8; 16], ordinal: u64, start: u32, len: u32 }
pub(super) struct Builder<'a> {
    codec: &'a Codec,
    unit: usize,
    bytes: ZeroizingBytes,
    members: Vec<Member>,
}
impl<'a> Builder<'a> {
    pub fn new(codec: &'a Codec, unit: usize) -> Self {
        Self { codec, unit, bytes: ZeroizingBytes::new(Vec::with_capacity(unit)), members: Vec::new() }
    }
    pub fn pending(&self) -> usize { self.members.len() }
    pub fn push<S: Storage>(&mut self, id: [u8; 16], ordinal: u64, bytes: &[u8], tx: &mut Transaction<S>, entries: &mut Vec<Entry>) -> Result<()> {
        if bytes.is_empty() || bytes.len() > self.unit { return Err(Error::CorruptRecord); }
        if self.bytes.len() + bytes.len() > self.unit { self.flush(tx, entries)?; }
        self.members.push(Member { id, ordinal, start: self.bytes.len() as u32, len: bytes.len() as u32 });
        self.bytes.extend_from_slice(bytes);
        if self.bytes.len() == self.unit { self.flush(tx, entries)?; }
        Ok(())
    }
    pub fn flush<S: Storage>(&mut self, tx: &mut Transaction<S>, entries: &mut Vec<Entry>) -> Result<()> {
        if self.bytes.is_empty() { return Ok(()); }
        let mut id = [0; 16];
        getrandom::fill(&mut id).map_err(|e| Error::Io(e.to_string()))?;
        if id == [0; 16] { return Err(Error::CorruptRecord); }
        let (descriptor, stored) = self.codec.encode(id, 0, 0, &self.bytes)?;
        let extent = tx.append_encoded_extent(&stored)?;
        for member in self.members.drain(..) {
            let slice = Slice { descriptor: descriptor.clone(), start: member.start, len: member.len };
            entries.push(Entry::new(CHUNK, &chunk_key(member.id, member.ordinal), &OwnedRecord::encode(&slice.encode(), &[extent])?)?);
        }
        zeroize_bytes(&mut self.bytes);
        self.bytes.clear();
        Ok(())
    }
}
