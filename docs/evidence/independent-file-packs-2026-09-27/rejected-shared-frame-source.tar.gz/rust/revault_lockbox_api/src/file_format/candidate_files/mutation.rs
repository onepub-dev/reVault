//! Whole-pack retirement for logical file deletion. No public CLI emits C yet.
use super::*;
use crate::file_format::allocation_map::Extent;
use std::collections::BTreeSet;

struct Affected {
    extent: Extent,
    descriptor: Descriptor,
    survivors: Vec<(Entry, Slice)>,
}
impl<S: Storage> Files<S> {
    /// Delete files as one transaction. Shared packs are rewritten from only
    /// surviving slices; their complete old allocations are then reclaimed.
    /// Missing paths are a no-change repeat, with no publication or allocation.
    pub(crate) fn remove(
        storage: S,
        archive: LockboxId,
        mode: FormatMode,
        authority: &Authority<'_>,
        signer: Option<&OwnerSigningKeyPair>,
        key: Option<&[u8]>,
        paths: impl IntoIterator<Item = Vec<u8>>,
    ) -> Result<S> {
        let files = Self::open(storage, archive, mode, authority, key)?;
        let mut removed = BTreeSet::new();
        for (count, path) in paths.into_iter().enumerate() {
            let path = Zeroizing::new(path);
            if count >= MAX_FILES || !valid_path(&path) {
                return Err(Error::InvalidInput("invalid or excessive removal paths".into()));
            }
            if let Some(info) = files.info(&path)? { removed.insert(info.id); }
        }
        if removed.is_empty() { return Ok(files.into_storage()); }
        let Self { storage, anchor, index, mut codec } = files;
        let mut tx = Transaction::begin(storage, archive, mode, authority, key)?;
        let result = (|| {
            let mut affected = BTreeMap::<u64, Affected>::new();
            index.visit_range(tx.read_storage(), anchor.index, anchor.sealed_len,
                Some((CHUNK, &[])), Some((CHUNK + 1, &[])), |entry| {
                if entry.key.len() != 24 { return Err(Error::CorruptRecord); }
                let id: [u8;16] = entry.key[..16].try_into().unwrap();
                if removed.contains(&id) {
                    let record = OwnedRecord::decode(&entry.value)?;
                    if record.extents.len() != 1 { return Err(Error::CorruptRecord); }
                    let slice = Slice::decode(&record.metadata)?;
                    let extent = record.extents[0];
                    affected.entry(extent.start).or_insert(Affected {
                        extent, descriptor: slice.descriptor, survivors: Vec::new(),
                    });
                }
                Ok(())
            })?;
            let mut entries = Vec::new();
            index.visit(tx.read_storage(), anchor.index, anchor.sealed_len, |entry| {
                let record = OwnedRecord::decode(&entry.value)?;
                match entry.namespace {
                    FILE => {
                        if !removed.contains(&FileInfo::decode(&record.metadata, &codec)?.id) {
                            entries.push(entry);
                        }
                    }
                    CHUNK => {
                        if entry.key.len() != 24 || record.extents.len() != 1 { return Err(Error::CorruptRecord); }
                        let id: [u8;16] = entry.key[..16].try_into().unwrap();
                        if !removed.contains(&id) {
                            if let Some(pack) = affected.get_mut(&record.extents[0].start) {
                                let slice = Slice::decode(&record.metadata)?;
                                if pack.extent != record.extents[0] || pack.descriptor != slice.descriptor {
                                    return Err(Error::CorruptRecord);
                                }
                                pack.survivors.push((entry, slice));
                            } else { entries.push(entry); }
                        }
                    }
                    _ => return Err(Error::CorruptRecord),
                }
                Ok(())
            })?;
            // Decode/repack one bounded allocation at a time, not all affected
            // payloads. Removing every member requires no payload decode.
            for mut pack in affected.into_values() {
                if pack.survivors.is_empty() { continue; }
                let decoded = codec.load(tx.read_storage(), pack.extent, anchor.sealed_len, &pack.descriptor)?;
                pack.survivors.sort_by_key(|(_, slice)| slice.start);
                let mut builder = Builder::new(&codec, pack.descriptor.logical_len as usize);
                for (entry, slice) in pack.survivors {
                    let id = entry.key[..16].try_into().unwrap();
                    let ordinal = u64::from_be_bytes(entry.key[16..].try_into().unwrap());
                    builder.push(id, ordinal, &decoded[slice.range()], &mut tx, &mut entries)?;
                }
                builder.flush(&mut tx, &mut entries)?;
            }
            entries.sort_by(|a,b| (a.namespace, a.key.as_slice()).cmp(&(b.namespace, b.key.as_slice())));
            tx.replace_all_sorted(entries.into_iter().map(Ok))?;
            Ok(())
        })();
        if let Err(error) = result { tx.abort(authority)?; return Err(error); }
        tx.commit(authority, signer).map(|(storage, _)| storage)
    }
}
